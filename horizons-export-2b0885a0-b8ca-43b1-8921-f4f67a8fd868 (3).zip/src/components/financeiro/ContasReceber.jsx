
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format, isPast, differenceInDays } from 'date-fns';

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const getStatus = (transaction) => {
  if (transaction.status === 'paid') {
    return { label: 'Pago', color: 'bg-green-500' };
  }
  if (isPast(new Date(transaction.due_date))) {
    return { label: `Atrasado ${differenceInDays(new Date(), new Date(transaction.due_date))}d`, color: 'bg-red-500' };
  }
  return { label: 'Pendente', color: 'bg-yellow-500' };
};

const ContasReceber = () => {
  const { toast } = useToast();
  const [receivables, setReceivables] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchReceivables = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*, customer:customers(name)')
        .eq('type', 'income')
        .order('due_date', { ascending: true });
      if (error) throw error;
      setReceivables(data);
    } catch (error) {
      toast({ title: 'Erro ao carregar contas a receber', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchReceivables();
  }, [fetchReceivables]);

  const handleMarkAsPaid = async (id) => {
    try {
        const { error } = await supabase.from('transactions').update({ status: 'paid', transaction_date: new Date() }).eq('id', id);
        if (error) throw error;
        toast({ title: 'Sucesso!', description: 'Conta marcada como paga.'});
        fetchReceivables();
    } catch (error) {
         toast({ title: 'Erro', description: error.message, variant: 'destructive' });
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mt-4">
       <h3 className="text-lg font-semibold text-gray-700 mb-4">Contas a Receber</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-500">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3">Vencimento</th>
              <th scope="col" className="px-6 py-3">Descrição</th>
              <th scope="col" className="px-6 py-3">Valor</th>
              <th scope="col" className="px-6 py-3">Status</th>
              <th scope="col" className="px-6 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan="5" className="text-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div></td></tr>
            ) : receivables.length > 0 ? (
              receivables.map(r => {
                const status = getStatus(r);
                return (
                  <tr key={r.id} className="bg-white border-b hover:bg-gray-50">
                    <td className="px-6 py-4">{r.due_date ? format(new Date(r.due_date), 'dd/MM/yyyy') : '-'}</td>
                    <td className="px-6 py-4 font-medium text-gray-900">{r.description}</td>
                    <td className="px-6 py-4 font-semibold text-green-600">{formatCurrency(r.amount)}</td>
                    <td className="px-6 py-4"><Badge className={`${status.color} text-white`}>{status.label}</Badge></td>
                    <td className="px-6 py-4 text-right">
                        {r.status === 'pending' && <Button size="sm" onClick={() => handleMarkAsPaid(r.id)}>Marcar como Pago</Button>}
                    </td>
                  </tr>
                )
            })
            ) : (
              <tr><td colSpan="5" className="text-center py-12 text-gray-500">Nenhuma conta a receber encontrada.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ContasReceber;
