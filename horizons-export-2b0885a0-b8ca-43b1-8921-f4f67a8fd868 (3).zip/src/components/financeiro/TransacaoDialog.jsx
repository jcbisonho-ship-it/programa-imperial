
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarPlus as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';

const TransacaoDialog = ({ isOpen, onClose, onSaveSuccess, transaction }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [accounts, setAccounts] = useState([]);
  const [categories, setCategories] = useState([]);
  
  const getInitialState = () => ({
    description: '', type: 'expense', amount: '', account_id: '',
    category_id: '', status: 'paid', notes: '',
    transaction_date: new Date(), due_date: null,
  });
  
  const [formData, setFormData] = useState(getInitialState());

  const fetchDropdownData = useCallback(async () => {
    try {
      const [accRes, catRes] = await Promise.all([
        supabase.from('accounts').select('id, name'),
        supabase.from('financial_categories').select('id, name, type')
      ]);
      if (accRes.error) throw accRes.error;
      if (catRes.error) throw catRes.error;
      setAccounts(accRes.data);
      setCategories(catRes.data);
    } catch (error) {
      toast({ title: "Erro ao carregar dados", description: error.message, variant: "destructive" });
    }
  }, [toast]);

  useEffect(() => {
    if(isOpen) {
      fetchDropdownData();
      if (transaction) {
        setFormData({
          description: transaction.description || '',
          type: transaction.type || 'expense',
          amount: transaction.amount || '',
          account_id: transaction.account_id || '',
          category_id: transaction.category_id || '',
          status: transaction.status || 'paid',
          notes: transaction.notes || '',
          transaction_date: transaction.transaction_date ? new Date(transaction.transaction_date) : new Date(),
          due_date: transaction.due_date ? new Date(transaction.due_date) : null,
        });
      } else {
        setFormData(getInitialState());
      }
    }
  }, [transaction, isOpen, fetchDropdownData]);

  const handleSelectChange = (id, value) => {
    const changes = { [id]: value };
    if (id === 'type') {
      changes.category_id = ''; // Reset category when type changes
    }
    setFormData(prev => ({ ...prev, ...changes }));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
        const payload = { ...formData, amount: parseFloat(formData.amount) };
        let result;
        if(transaction) {
            result = await supabase.from('transactions').update(payload).eq('id', transaction.id);
        } else {
            result = await supabase.from('transactions').insert(payload);
        }
        if (result.error) throw result.error;
        toast({ title: `Transação ${transaction ? 'atualizada' : 'criada'} com sucesso!` });
        onSaveSuccess();
        onClose();
    } catch (error) {
        toast({ title: 'Erro ao salvar transação', description: error.message, variant: 'destructive' });
    } finally {
        setLoading(false);
    }
  };

  const filteredCategories = categories.filter(c => c.type === formData.type);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{transaction ? 'Editar' : 'Nova'} Transação</DialogTitle>
          <DialogDescription>Preencha os detalhes da movimentação financeira.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto space-y-4 pr-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label>Descrição *</Label><Input id="description" value={formData.description} onChange={e => setFormData(p => ({...p, description: e.target.value}))} required /></div>
            <div><Label>Valor *</Label><Input id="amount" type="number" step="0.01" value={formData.amount} onChange={e => setFormData(p => ({...p, amount: e.target.value}))} required /></div>
            
            <div><Label>Tipo</Label><Select value={formData.type} onValueChange={v => handleSelectChange('type', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="income">Entrada</SelectItem><SelectItem value="expense">Saída</SelectItem></SelectContent></Select></div>
            <div><Label>Categoria</Label><Select value={formData.category_id} onValueChange={v => handleSelectChange('category_id', v)}><SelectTrigger><SelectValue placeholder="Selecione uma categoria"/></SelectTrigger><SelectContent>{filteredCategories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
            
            <div><Label>Conta</Label><Select value={formData.account_id} onValueChange={v => handleSelectChange('account_id', v)}><SelectTrigger><SelectValue placeholder="Selecione uma conta"/></SelectTrigger><SelectContent>{accounts.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Status</Label><Select value={formData.status} onValueChange={v => handleSelectChange('status', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="paid">Pago</SelectItem><SelectItem value="pending">Pendente</SelectItem></SelectContent></Select></div>

             <div className="space-y-1">
                <Label>Data da Transação</Label>
                <Popover><PopoverTrigger asChild><Button variant="outline" className="w-full justify-start text-left font-normal">{formData.transaction_date ? format(formData.transaction_date, "PPP") : <span>Selecione uma data</span>}<CalendarIcon className="ml-auto h-4 w-4 opacity-50" /></Button></PopoverTrigger><PopoverContent className="w-auto p-0"><Calendar mode="single" selected={formData.transaction_date} onSelect={d => setFormData(p => ({...p, transaction_date: d}))} initialFocus /></PopoverContent></Popover>
             </div>
             {formData.status === 'pending' && (
             <div className="space-y-1">
                <Label>Data de Vencimento</Label>
                <Popover><PopoverTrigger asChild><Button variant="outline" className="w-full justify-start text-left font-normal">{formData.due_date ? format(formData.due_date, "PPP") : <span>Selecione uma data</span>}<CalendarIcon className="ml-auto h-4 w-4 opacity-50" /></Button></PopoverTrigger><PopoverContent className="w-auto p-0"><Calendar mode="single" selected={formData.due_date} onSelect={d => setFormData(p => ({...p, due_date: d}))} initialFocus /></PopoverContent></Popover>
             </div>
             )}
            <div className="md:col-span-2"><Label>Observações</Label><Textarea value={formData.notes} onChange={e => setFormData(p => ({...p, notes: e.target.value}))}/></div>
          </div>
          <DialogFooter className="pt-4 border-t mt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TransacaoDialog;
