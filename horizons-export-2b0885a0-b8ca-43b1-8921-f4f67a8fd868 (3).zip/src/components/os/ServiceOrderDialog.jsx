
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { format, parseISO } from 'date-fns';
import { PlusCircle, Trash2, Upload } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { logAuditEvent } from '@/lib/audit';

const getInitialFormData = () => ({
    customer_id: '', vehicle_id: '', technician_id: '', title: '', description: '',
    status: 'pending', priority: 'medium', order_date: format(new Date(), 'yyyy-MM-dd'),
    scheduled_date: '', completed_date: '', notes: '',
});

const ServiceOrderDialog = ({ isOpen, onClose, onSaveSuccess, serviceOrder, user }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState(getInitialFormData());
  const [items, setItems] = useState([]);
  const [checklists, setChecklists] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [photoFiles, setPhotoFiles] = useState([]);
  const [photoStage, setPhotoStage] = useState('diagnosis');
  
  const [customers, setCustomers] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [collaborators, setCollaborators] = useState([]);
  const [products, setProducts] = useState([]);
  const [budgets, setBudgets] = useState([]);
  const [selectedBudgetId, setSelectedBudgetId] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchDropdownData = useCallback(async () => {
    try {
      const [customersRes, vehiclesRes, collaboratorsRes, productsRes, budgetsRes] = await Promise.all([
        supabase.from('customers').select('id, name').order('name'),
        supabase.from('vehicles').select('id, model, plate, customer_id'),
        supabase.from('collaborators').select('id, name').order('name'),
        supabase.from('products').select('id, name, sale_price, cost_price, stock'),
        supabase.from('budgets').select('id, customer_name, vehicle_description').eq('status', 'approved'),
      ]);
      setCustomers(customersRes.data || []);
      setVehicles(vehiclesRes.data || []);
      setCollaborators(collaboratorsRes.data || []);
      setProducts(productsRes.data || []);
      setBudgets(budgetsRes.data || []);
    } catch(error) {
      toast({ title: "Erro ao carregar dados de apoio", description: error.message, variant: "destructive" });
    }
  }, [toast]);

  useEffect(() => {
    if (isOpen) fetchDropdownData();
  }, [isOpen, fetchDropdownData]);

  useEffect(() => {
    const setup = async () => {
      if (serviceOrder) {
        setFormData({
            id: serviceOrder.id,
            customer_id: serviceOrder.customer_id || '', vehicle_id: serviceOrder.vehicle_id || '',
            technician_id: serviceOrder.technician_id || '', title: serviceOrder.title || '',
            description: serviceOrder.description || '', status: serviceOrder.status || 'pending',
            priority: serviceOrder.priority || 'medium',
            order_date: serviceOrder.order_date ? format(parseISO(serviceOrder.order_date), 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
            scheduled_date: serviceOrder.scheduled_date ? format(parseISO(serviceOrder.scheduled_date), 'yyyy-MM-dd') : '',
            completed_date: serviceOrder.completed_date ? format(parseISO(serviceOrder.completed_date), 'yyyy-MM-dd') : '',
            notes: serviceOrder.notes || '',
        });
        const { data: itemsData } = await supabase.from('work_order_items').select('*').eq('work_order_id', serviceOrder.id);
        setItems(itemsData || []);
        const { data: checklistsData } = await supabase.from('work_order_checklists').select('*').eq('work_order_id', serviceOrder.id);
        setChecklists(checklistsData || []);
        const { data: photosData } = await supabase.from('work_order_photos').select('*').eq('work_order_id', serviceOrder.id);
        setPhotos(photosData || []);
      } else {
        setFormData(getInitialFormData());
        setItems([]);
        setChecklists([]);
        setPhotos([]);
      }
      setSelectedBudgetId('');
    };
    if (isOpen) setup();
  }, [isOpen, serviceOrder]);

  const customerVehicles = useMemo(() => vehicles.filter(v => v.customer_id === formData.customer_id), [formData.customer_id, vehicles]);

  const handleBudgetImport = async () => {
    if (!selectedBudgetId) return;
    const { data: budget } = await supabase.from('budgets').select('*').eq('id', selectedBudgetId).single();
    const { data: budgetItems } = await supabase.from('budget_items').select('*').eq('budget_id', selectedBudgetId);
    
    setFormData(prev => ({
        ...prev,
        customer_id: budget.customer_id,
        vehicle_id: budget.vehicle_id,
        title: `OS do Orçamento #${budget.id.substring(0, 5)}`,
    }));
    
    const newItems = budgetItems.map(item => ({
        item_type: 'product', // Assuming all budget items are products for now
        product_id: item.product_id,
        description: item.description,
        quantity: item.quantity,
        unit_price: item.unit_price,
        cost_price: item.cost_price,
        total_price: item.total_price,
        collaborator_id: item.collaborator_id,
    }));
    setItems(newItems);
    toast({ title: 'Itens importados do orçamento!' });
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      // 1. Upsert OS
      const { id, ...dataToSave } = formData;
      let osId = id;
      if (osId) {
        const { error } = await supabase.from('work_orders').update(dataToSave).eq('id', osId);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from('work_orders').insert(dataToSave).select().single();
        if (error) throw error;
        osId = data.id;
      }

      // 2. Upsert Items
      await supabase.from('work_order_items').delete().eq('work_order_id', osId);
      if (items.length > 0) {
        const itemsToInsert = items.map(item => ({ ...item, work_order_id: osId }));
        const { error: itemsError } = await supabase.from('work_order_items').insert(itemsToInsert);
        if (itemsError) throw itemsError;
      }

      // 3. Upsert Checklists
      await supabase.from('work_order_checklists').delete().eq('work_order_id', osId);
      if (checklists.length > 0) {
        const checklistsToInsert = checklists.map(c => ({ ...c, work_order_id: osId }));
        const { error: checklistsError } = await supabase.from('work_order_checklists').insert(checklistsToInsert);
        if (checklistsError) throw checklistsError;
      }
      
      // 4. Upload Photos
      for (const file of photoFiles) {
        const filePath = `os-photos/${osId}/${uuidv4()}-${file.name}`;
        const { error: uploadError } = await supabase.storage.from('vehicles').upload(filePath, file);
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage.from('vehicles').getPublicUrl(filePath);
        await supabase.from('work_order_photos').insert({ work_order_id: osId, photo_url: urlData.publicUrl, photo_type: photoStage });
      }

      // 5. Log and close
      await logAuditEvent(user.id, id ? 'update_work_order' : 'create_work_order', { orderId: osId });
      toast({ title: `Ordem de Serviço salva com sucesso!` });
      onSaveSuccess();
      onClose();
    } catch (error) {
      toast({ title: "Erro ao salvar Ordem de Serviço", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  // Item, Checklist, and Photo handlers
  const addItem = (type) => setItems([...items, { item_type: type, description: '', quantity: 1, unit_price: 0, total_price: 0 }]);
  const removeItem = (index) => setItems(items.filter((_, i) => i !== index));
  const handleItemChange = (index, field, value) => {
    const newItems = [...items];
    newItems[index][field] = value;
    if (field === 'product_id') {
        const product = products.find(p => p.id === value);
        if (product) {
            newItems[index].description = product.name;
            newItems[index].unit_price = product.sale_price;
            newItems[index].cost_price = product.cost_price;
        }
    }
    newItems[index].total_price = (newItems[index].quantity || 0) * (newItems[index].unit_price || 0);
    setItems(newItems);
  };
  
  const addChecklistItem = () => setChecklists([...checklists, { task: '', is_completed: false }]);
  const removeChecklistItem = (index) => setChecklists(checklists.filter((_, i) => i !== index));
  const handleChecklistChange = (index, field, value) => {
    const newChecklists = [...checklists];
    newChecklists[index][field] = value;
    setChecklists(newChecklists);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader><DialogTitle>{serviceOrder ? 'Editar' : 'Nova'} Ordem de Serviço</DialogTitle></DialogHeader>
        <div className="flex-grow overflow-y-auto space-y-4 pr-2">
            {!serviceOrder && (
                <div className="flex gap-2 items-end">
                    <div className="flex-grow"><Label>Importar de Orçamento Aprovado</Label><Select value={selectedBudgetId} onValueChange={setSelectedBudgetId}><SelectTrigger><SelectValue placeholder="Selecione um orçamento..." /></SelectTrigger><SelectContent>{budgets.map(b => <SelectItem key={b.id} value={b.id}>{`#${b.id.substring(0,5)} - ${b.customer_name}`}</SelectItem>)}</SelectContent></Select></div>
                    <Button type="button" onClick={handleBudgetImport} disabled={!selectedBudgetId}>Importar</Button>
                </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><Label>Cliente *</Label><Select value={formData.customer_id} onValueChange={v => setFormData({...formData, customer_id: v, vehicle_id: ''})}><SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger><SelectContent>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
                <div><Label>Veículo *</Label><Select value={formData.vehicle_id} onValueChange={v => setFormData({...formData, vehicle_id: v})} disabled={!formData.customer_id}><SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger><SelectContent>{customerVehicles.map(v => <SelectItem key={v.id} value={v.id}>{`${v.model} (${v.plate})`}</SelectItem>)}</SelectContent></Select></div>
            </div>
            <div><Label>Título do Serviço *</Label><Input value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} /></div>
            
            {/* Items */}
            <div className="space-y-2"><Label>Itens e Serviços</Label>
                {items.map((item, index) => (
                    <div key={index} className="flex gap-2 items-center">
                        {item.item_type === 'product' ? (
                            <Select value={item.product_id || ''} onValueChange={v => handleItemChange(index, 'product_id', v)}><SelectTrigger className="flex-grow"><SelectValue placeholder="Selecione um produto..." /></SelectTrigger><SelectContent>{products.map(p => <SelectItem key={p.id} value={p.id}>{p.name} (Est: {p.stock})</SelectItem>)}</SelectContent></Select>
                        ) : (
                            <Input className="flex-grow" placeholder="Descrição do serviço" value={item.description} onChange={e => handleItemChange(index, 'description', e.target.value)} />
                        )}
                        <Input type="number" value={item.quantity} onChange={e => handleItemChange(index, 'quantity', e.target.value)} className="w-20" placeholder="Qtd" />
                        <Input type="number" value={item.unit_price} onChange={e => handleItemChange(index, 'unit_price', e.target.value)} className="w-24" placeholder="Preço" />
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(index)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                    </div>
                ))}
                <div className="flex gap-2"><Button type="button" variant="outline" size="sm" onClick={() => addItem('product')}>+ Peça</Button><Button type="button" variant="outline" size="sm" onClick={() => addItem('service')}>+ Serviço</Button></div>
            </div>

            {/* Checklist */}
            <div className="space-y-2"><Label>Checklist Interno</Label>
                {checklists.map((item, index) => (
                    <div key={index} className="flex gap-2 items-center">
                        <Checkbox checked={item.is_completed} onCheckedChange={c => handleChecklistChange(index, 'is_completed', c)} />
                        <Input className="flex-grow" value={item.task} onChange={e => handleChecklistChange(index, 'task', e.target.value)} placeholder="Descrição da tarefa" />
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeChecklistItem(index)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                    </div>
                ))}
                <Button type="button" variant="outline" size="sm" onClick={addChecklistItem}>+ Tarefa</Button>
            </div>

            {/* Photos */}
            <div className="space-y-2"><Label>Fotos</Label>
                <div className="flex gap-2 items-center">
                    <Select value={photoStage} onValueChange={setPhotoStage}><SelectTrigger className="w-48"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="diagnosis">Diagnóstico</SelectItem><SelectItem value="in_progress">Em Andamento</SelectItem><SelectItem value="completed">Finalizado</SelectItem></SelectContent></Select>
                    <Input type="file" multiple onChange={e => setPhotoFiles(Array.from(e.target.files))} />
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                    {photos.map(p => <a key={p.id} href={p.photo_url} target="_blank" rel="noreferrer"><img src={p.photo_url} className="w-20 h-20 object-cover rounded-md" alt={p.photo_type}/></a>)}
                </div>
            </div>
        </div>
        <DialogFooter className="pt-4">
          <DialogClose asChild><Button type="button" variant="outline" disabled={loading}>Cancelar</Button></DialogClose>
          <Button onClick={handleSave} disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ServiceOrderDialog;
