
import React, { useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { logAuditEvent } from '@/lib/audit';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const statusColumns = [
  { id: 'pending', title: 'Pendente' },
  { id: 'in_progress', title: 'Em Andamento' },
  { id: 'completed', title: 'Finalizada' },
  { id: 'delivered', title: 'Entregue' },
];

const OSKanban = ({ serviceOrders, loading, onRefresh, onEdit }) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [draggedOrder, setDraggedOrder] = useState(null);

  const handleDragStart = (e, order) => {
    setDraggedOrder(order);
  };

  const handleDrop = async (e, newStatus) => {
    e.preventDefault();
    if (!draggedOrder || draggedOrder.status === newStatus) return;

    try {
      const { error } = await supabase.from('work_orders').update({ status: newStatus }).eq('id', draggedOrder.id);
      if (error) throw error;
      await logAuditEvent(user.id, 'update_os_status_kanban', { orderId: draggedOrder.id, from: draggedOrder.status, to: newStatus });
      toast({ title: 'Status atualizado!' });
      onRefresh();
    } catch (error) {
      toast({ title: 'Erro ao atualizar status', description: error.message, variant: 'destructive' });
    }
    setDraggedOrder(null);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {statusColumns.map(column => (
        <div key={column.id} onDrop={(e) => handleDrop(e, column.id)} onDragOver={handleDragOver} className="bg-gray-100 rounded-lg p-2">
          <h3 className="font-semibold text-center p-2 text-gray-700">{column.title}</h3>
          <div className="space-y-2 min-h-[200px]">
            {loading ? (
              <div className="p-2 bg-white rounded-md shadow-sm animate-pulse h-24"></div>
            ) : (
              serviceOrders
                .filter(order => order.status === column.id)
                .map(order => (
                  <Card 
                    key={order.id} 
                    draggable 
                    onDragStart={(e) => handleDragStart(e, order)}
                    onClick={() => onEdit(order)}
                    className="cursor-pointer hover:shadow-md"
                  >
                    <CardHeader className="p-3">
                      <CardTitle className="text-sm font-semibold">{order.title}</CardTitle>
                      <p className="text-xs text-gray-500">{order.customer_name}</p>
                    </CardHeader>
                    <CardContent className="p-3 text-xs space-y-1">
                      <p className="font-mono"><Badge variant="secondary">{order.vehicle_plate}</Badge></p>
                      <p>Técnico: {order.technician_name || 'N/A'}</p>
                      <p>Data: {format(new Date(order.order_date), "dd/MM/yy", { locale: ptBR })}</p>
                      <p className="font-bold text-sm">{formatCurrency(order.total_cost)}</p>
                    </CardContent>
                  </Card>
                ))
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default OSKanban;
