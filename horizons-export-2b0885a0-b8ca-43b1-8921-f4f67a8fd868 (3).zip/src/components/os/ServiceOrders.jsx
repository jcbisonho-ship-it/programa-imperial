
import React, { useState, useEffect, useCallback } from 'react';
import { useDebounce } from '@/hooks/useDebounce';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Search, Calendar as CalendarIcon, LayoutList, KanbanSquare } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import ServiceOrderDialog from '@/components/os/ServiceOrderDialog';
import OSList from '@/components/os/OSList';
import OSKanban from '@/components/os/OSKanban';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const ServiceOrders = () => {
  const [serviceOrders, setServiceOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({ status: '', customer_id: '', technician_id: '', dateRange: { from: null, to: null } });
  
  const [customers, setCustomers] = useState([]);
  const [collaborators, setCollaborators] = useState([]);

  const { toast } = useToast();
  const { user } = useAuth();
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const loadDropdownData = useCallback(async () => {
    try {
      const [customersRes, collaboratorsRes] = await Promise.all([
        supabase.from('customers').select('id, name').order('name'),
        supabase.from('collaborators').select('id, name').order('name'),
      ]);
      if (customersRes.error) throw customersRes.error;
      if (collaboratorsRes.error) throw collaboratorsRes.error;
      setCustomers(customersRes.data || []);
      setCollaborators(collaboratorsRes.data || []);
    } catch(error) {
      toast({ title: "Erro ao carregar dados de apoio", description: error.message, variant: "destructive" });
    }
  }, [toast]);
  
  const loadServiceOrders = useCallback(async () => {
    setLoading(true);
    try {
      let query = supabase.rpc('get_work_order_summary');

      if (filters.status) query = query.eq('status', filters.status);
      if (filters.customer_id) query = query.eq('customer_id', filters.customer_id);
      if (filters.technician_id) query = query.eq('technician_id', filters.technician_id);
      if (filters.dateRange.from) query = query.gte('order_date', format(filters.dateRange.from, 'yyyy-MM-dd'));
      if (filters.dateRange.to) query = query.lte('order_date', format(filters.dateRange.to, 'yyyy-MM-dd'));
      
      if (debouncedSearchTerm) {
        query = query.or(`customer_name.ilike.%${debouncedSearchTerm}%,vehicle_plate.ilike.%${debouncedSearchTerm}%,title.ilike.%${debouncedSearchTerm}%`);
      }

      const { data, error } = await query.order('order_date', { ascending: false });

      if (error) throw error;
      setServiceOrders(data || []);
    } catch (error) {
      toast({ title: "Erro ao carregar Ordens de Serviço", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast, filters, debouncedSearchTerm]);
  
  useEffect(() => {
    loadDropdownData();
  }, [loadDropdownData]);

  useEffect(() => {
    loadServiceOrders();
  }, [loadServiceOrders]);

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({ ...prev, [filterName]: value }));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Ordens de Serviço</h2>
          <p className="text-gray-600">Gerencie todas as ordens de serviço da oficina. As OS são criadas a partir de orçamentos aprovados.</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-6">
            <div className="relative xl:col-span-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input placeholder="Buscar cliente, placa, título..." className="pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
            <Select value={filters.status || ''} onValueChange={(value) => handleFilterChange('status', value === 'all' ? '' : value)}>
                <SelectTrigger><SelectValue placeholder="Filtrar por Status" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todos Status</SelectItem>
                    <SelectItem value="pending">Pendente</SelectItem>
                    <SelectItem value="in_progress">Em Andamento</SelectItem>
                    <SelectItem value="completed">Finalizada</SelectItem>
                    <SelectItem value="delivered">Entregue</SelectItem>
                    <SelectItem value="canceled">Cancelada</SelectItem>
                </SelectContent>
            </Select>
            <Select value={filters.customer_id || ''} onValueChange={(value) => handleFilterChange('customer_id', value === 'all' ? '' : value)}>
                <SelectTrigger><SelectValue placeholder="Filtrar por Cliente" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todos Clientes</SelectItem>
                    {customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
            </Select>
             <Select value={filters.technician_id || ''} onValueChange={(value) => handleFilterChange('technician_id', value === 'all' ? '' : value)}>
                <SelectTrigger><SelectValue placeholder="Filtrar por Técnico" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todos Técnicos</SelectItem>
                    {collaborators.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
            </Select>
            <Popover>
                <PopoverTrigger asChild>
                    <Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !filters.dateRange.from && "text-muted-foreground")}>
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {filters.dateRange.from ? (
                            filters.dateRange.to ? (
                                `${format(filters.dateRange.from, "dd/MM/y")} - ${format(filters.dateRange.to, "dd/MM/y")}`
                            ) : (
                                format(filters.dateRange.from, "dd/MM/y")
                            )
                        ) : (
                            <span>Selecione um período</span>
                        )}
                    </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="range" selected={filters.dateRange} onSelect={(range) => handleFilterChange('dateRange', range || { from: null, to: null })} numberOfMonths={2} locale={ptBR} />
                </PopoverContent>
            </Popover>
        </div>
        
        <Tabs defaultValue="list">
            <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="list"><LayoutList className="w-4 h-4 mr-2"/>Lista</TabsTrigger>
                <TabsTrigger value="kanban"><KanbanSquare className="w-4 h-4 mr-2"/>Kanban</TabsTrigger>
            </TabsList>
            <TabsContent value="list">
                <OSList 
                    serviceOrders={serviceOrders} 
                    loading={loading} 
                    onEdit={(order) => { setEditingOrder(order); setIsDialogOpen(true); }}
                    onRefresh={loadServiceOrders}
                />
            </TabsContent>
            <TabsContent value="kanban">
                <OSKanban 
                    serviceOrders={serviceOrders} 
                    loading={loading} 
                    onRefresh={loadServiceOrders}
                    onEdit={(order) => { setEditingOrder(order); setIsDialogOpen(true); }}
                />
            </TabsContent>
        </Tabs>
      </div>

      {isDialogOpen && (
        <ServiceOrderDialog
          isOpen={isDialogOpen}
          onClose={() => { setIsDialogOpen(false); setEditingOrder(null); }}
          onSaveSuccess={loadServiceOrders}
          serviceOrder={editingOrder}
          user={user}
        />
      )}
    </div>
  );
};

export default ServiceOrders;
