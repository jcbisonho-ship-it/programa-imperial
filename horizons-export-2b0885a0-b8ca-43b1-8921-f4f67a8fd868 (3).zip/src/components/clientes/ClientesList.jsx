
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { PlusCircle, Search, MoreHorizontal, Edit, Trash2, Car, MessageSquare as MessageSquareWarning, FileText, History } from 'lucide-react';
import ClienteDialog from './ClienteDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { logAuditEvent } from '@/lib/audit';
import ClientHistoryDialog from '@/components/dialogs/ClientHistoryDialog';
import { useDebounce } from '@/hooks/useDebounce';

const ClientesList = () => {
  const { toast } = useToast();
  const { user } = useAuth();

  const [clientes, setClientes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({ page: 0, pageSize: 10, total: 0 });

  const [isClienteDialogOpen, setIsClienteDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  
  const [selectedCliente, setSelectedCliente] = useState(null);

  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const fetchClientes = useCallback(async () => {
    setLoading(true);
    const { page, pageSize } = pagination;
    const from = page * pageSize;
    const to = from + pageSize - 1;

    let query = supabase.rpc('get_customer_summary', {}, { count: 'exact' });

    if (debouncedSearchTerm) {
      query = query.or(`name.ilike.%${debouncedSearchTerm}%,cpf.ilike.%${debouncedSearchTerm}%,email.ilike.%${debouncedSearchTerm}%`);
    }

    query = query.order('name', { ascending: true }).range(from, to);

    const { data, error, count } = await query;

    if (error) {
      toast({ title: 'Erro ao carregar clientes', description: error.message, variant: 'destructive' });
      setClientes([]);
    } else {
      setClientes(data);
      setPagination(prev => ({ ...prev, total: count }));
    }
    setLoading(false);
  }, [pagination.page, pagination.pageSize, debouncedSearchTerm, toast]);

  useEffect(() => {
    fetchClientes();
  }, [fetchClientes]);

  const openClienteDialog = (cliente = null) => {
    setSelectedCliente(cliente);
    setIsClienteDialogOpen(true);
  };
  
  const openDeleteDialog = (cliente) => {
    setSelectedCliente(cliente);
    setIsDeleteDialogOpen(true);
  };

  const openHistoryDialog = (cliente) => {
    setSelectedCliente(cliente);
    setIsHistoryDialogOpen(true);
  };

  const handleDeleteCliente = async () => {
    if (!selectedCliente) return;

    // First delete related vehicles
    const { error: vehicleError } = await supabase.from('vehicles').delete().eq('customer_id', selectedCliente.id);
    if (vehicleError) {
      toast({ title: 'Erro ao deletar veículos do cliente', description: vehicleError.message, variant: 'destructive' });
      setIsDeleteDialogOpen(false);
      return;
    }
    
    // Then delete customer
    const { error: customerError } = await supabase.from('customers').delete().eq('id', selectedCliente.id);
    if (customerError) {
      toast({ title: 'Erro ao deletar cliente', description: customerError.message, variant: 'destructive' });
    } else {
      toast({ title: 'Cliente deletado com sucesso!' });
      await logAuditEvent(user.id, 'delete_customer', { customerId: selectedCliente.id, name: selectedCliente.name });
      fetchClientes();
    }
    setIsDeleteDialogOpen(false);
    setSelectedCliente(null);
  };
  
  const totalPages = Math.ceil(pagination.total / pagination.pageSize);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Clientes</h2>
          <p className="text-gray-600">Gerencie seus clientes e seus veículos.</p>
        </div>
        <Button onClick={() => openClienteDialog()} className="bg-blue-600 hover:bg-blue-700">
          <PlusCircle className="w-4 h-4 mr-2" /> Novo Cliente
        </Button>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input placeholder="Buscar por nome, CPF ou email..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3">Nome</th>
                <th scope="col" className="px-6 py-3 hidden md:table-cell">CPF</th>
                <th scope="col" className="px-6 py-3 hidden lg:table-cell">Email</th>
                <th scope="col" className="px-6 py-3 hidden sm:table-cell">Telefone</th>
                <th scope="col" className="px-6 py-3 text-center">Veículos</th>
                <th scope="col" className="px-6 py-3 text-center">Status</th>
                <th scope="col" className="px-6 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="7" className="text-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div></td></tr>
              ) : clientes.length > 0 ? (
                clientes.map(cliente => (
                  <tr key={cliente.id} className="bg-white border-b hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{cliente.name}</td>
                    <td className="px-6 py-4 hidden md:table-cell">{cliente.cpf || '-'}</td>
                    <td className="px-6 py-4 hidden lg:table-cell">{cliente.email || '-'}</td>
                    <td className="px-6 py-4 hidden sm:table-cell">{cliente.phone || '-'}</td>
                    <td className="px-6 py-4 text-center">{cliente.vehicle_count}</td>
                    <td className="px-6 py-4 text-center">
                      {cliente.has_pending_os ? <Badge variant="secondary" className="bg-yellow-400 text-yellow-900">OS Pendente</Badge> : <Badge variant="default" className="bg-green-100 text-green-800">Ativo</Badge>}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreHorizontal className="w-5 h-5" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => openClienteDialog(cliente)}><Edit className="w-4 h-4 mr-2" /> Editar Cliente</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast({ title: "🚧 Em breve!", description: "Gerenciar veículos do cliente." })}><Car className="w-4 h-4 mr-2" /> Gerenciar Veículos</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast({ title: "🚧 Em breve!", description: "Visualizar orçamentos do cliente." })}><FileText className="w-4 h-4 mr-2" /> Ver Orçamentos</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openHistoryDialog(cliente)}><History className="w-4 h-4 mr-2" /> Ver Histórico</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600" onClick={() => openDeleteDialog(cliente)}><Trash2 className="w-4 h-4 mr-2" /> Excluir Cliente</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="7" className="text-center py-12 text-gray-500">Nenhum cliente encontrado.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between pt-4">
            <span className="text-sm text-gray-700">Página {pagination.page + 1} de {totalPages || 1}</span>
            <div className="flex gap-2">
                <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))} disabled={pagination.page === 0}>Anterior</Button>
                <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))} disabled={pagination.page >= totalPages - 1}>Próximo</Button>
            </div>
        </div>
      </div>
      
      {isClienteDialogOpen && <ClienteDialog isOpen={isClienteDialogOpen} onClose={() => setIsClienteDialogOpen(false)} onSaveSuccess={fetchClientes} cliente={selectedCliente} user={user} />}
      {isHistoryDialogOpen && <ClientHistoryDialog isOpen={isHistoryDialogOpen} onClose={() => setIsHistoryDialogOpen(false)} clientId={selectedCliente?.id} />}

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. Isso excluirá permanentemente o cliente e todos os seus veículos e ordens de serviço associadas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteCliente} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ClientesList;
