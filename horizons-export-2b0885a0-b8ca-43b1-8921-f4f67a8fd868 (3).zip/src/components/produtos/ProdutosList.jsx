
import React, { useState, useEffect, useCallback } from 'react';
import { useDebounce } from '@/hooks/useDebounce';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { PlusCircle, Search, MoreHorizontal, Edit, Trash2, History, AlertTriangle, CheckCircle, Package, ShoppingCart } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import ProdutoDialog from './ProdutoDialog';
import ProdutoHistorico from './ProdutoHistorico';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useAuth } from '@/contexts/SupabaseAuthContext';

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const ProdutosList = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [purchaseSuggestions, setPurchaseSuggestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({ page: 0, pageSize: 10, total: 0 });
  
  const [isProdutoDialogOpen, setIsProdutoDialogOpen] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  const [selectedProduct, setSelectedProduct] = useState(null);

  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    const { page, pageSize } = pagination;
    const from = page * pageSize;
    const to = from + pageSize - 1;

    let query = supabase.rpc('get_product_summary', {}, { count: 'exact' });

    if (debouncedSearchTerm) {
      query = query.or(`name.ilike.%${debouncedSearchTerm}%,sku.ilike.%${debouncedSearchTerm}%`);
    }

    query = query.order('name', { ascending: true }).range(from, to);

    const { data, error, count } = await query;
    
    if (error) {
      toast({ title: 'Erro ao carregar produtos', description: error.message, variant: 'destructive' });
      setProducts([]);
    } else {
      setProducts(data);
      setPagination(prev => ({ ...prev, total: count }));

      const suggestions = data.filter(p => p.stock <= p.min_stock);
      setPurchaseSuggestions(suggestions);
    }
    setLoading(false);
  }, [pagination.page, pagination.pageSize, debouncedSearchTerm, toast]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const openProdutoDialog = (product = null) => {
    setSelectedProduct(product);
    setIsProdutoDialogOpen(true);
  };

  const openHistoryDialog = (product) => {
    setSelectedProduct(product);
    setIsHistoryDialogOpen(true);
  };

  const openDeleteDialog = (product) => {
    setSelectedProduct(product);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteProduct = async () => {
    if (!selectedProduct) return;
    
    const { error } = await supabase.from('products').delete().eq('id', selectedProduct.id);

    if (error) {
      toast({ title: 'Erro ao deletar produto', description: 'Verifique se este produto está vinculado a ordens de serviço.', variant: 'destructive' });
    } else {
      toast({ title: 'Produto deletado com sucesso!' });
      fetchProducts();
    }
    setIsDeleteDialogOpen(false);
    setSelectedProduct(null);
  };
  
  const totalPages = Math.ceil(pagination.total / pagination.pageSize);

  const StatusBadge = ({ product }) => {
    if (product.stock <= 0) {
      return <Badge variant="destructive" className="flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Sem Estoque</Badge>;
    }
    if (product.stock <= product.min_stock) {
      return <Badge variant="secondary" className="bg-yellow-500 text-white flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Estoque Baixo</Badge>;
    }
    return <Badge variant="default" className="bg-green-600 flex items-center gap-1"><CheckCircle className="w-3 h-3" /> Em Estoque</Badge>;
  };
  
  const renderTable = (data, isSuggestionList = false) => (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left text-gray-500">
        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3">SKU</th>
            <th scope="col" className="px-6 py-3">Nome</th>
            <th scope="col" className="px-6 py-3 hidden md:table-cell">Preço Venda</th>
            <th scope="col" className="px-6 py-3 text-center">Estoque</th>
            <th scope="col" className="px-6 py-3 text-center hidden sm:table-cell">Estoque Mín.</th>
            <th scope="col" className="px-6 py-3 text-center">Status</th>
            {!isSuggestionList && <th scope="col" className="px-6 py-3 text-right">Ações</th>}
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr><td colSpan={isSuggestionList ? 6 : 7} className="text-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div></td></tr>
          ) : data.length > 0 ? (
            data.map(product => (
              <tr key={product.id} className="bg-white border-b hover:bg-gray-50">
                <td className="px-6 py-4 font-mono text-gray-700">{product.sku || '-'}</td>
                <td className="px-6 py-4 font-medium text-gray-900">{product.name}</td>
                <td className="px-6 py-4 hidden md:table-cell">{formatCurrency(product.sale_price)}</td>
                <td className="px-6 py-4 text-center font-bold">{product.stock}</td>
                <td className="px-6 py-4 text-center hidden sm:table-cell">{product.min_stock}</td>
                <td className="px-6 py-4 text-center"><StatusBadge product={product} /></td>
                {!isSuggestionList && <td className="px-6 py-4 text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="w-5 h-5" /></Button></DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onClick={() => openProdutoDialog(product)}><Edit className="w-4 h-4 mr-2" /> Editar Produto</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => openHistoryDialog(product)}><History className="w-4 h-4 mr-2" /> Ver Histórico</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-red-600" onClick={() => openDeleteDialog(product)}><Trash2 className="w-4 h-4 mr-2" /> Excluir Produto</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>}
              </tr>
            ))
          ) : (
             <tr><td colSpan={isSuggestionList ? 6 : 7} className="text-center py-12 text-gray-500">
                <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                Nenhum produto encontrado.
            </td></tr>
          )}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Produtos e Estoque</h2>
          <p className="text-gray-600">Gerencie seu inventário de produtos.</p>
        </div>
        <Button onClick={() => openProdutoDialog()} className="bg-blue-600 hover:bg-blue-700">
          <PlusCircle className="w-4 h-4 mr-2" /> Novo Produto
        </Button>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <Tabs defaultValue="all">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="all">
              <Package className="w-4 h-4 mr-2" /> Todos os Produtos
            </TabsTrigger>
            <TabsTrigger value="suggestions">
              <ShoppingCart className="w-4 h-4 mr-2" /> Sugestão de Compra ({purchaseSuggestions.length})
            </TabsTrigger>
          </TabsList>
          <TabsContent value="all">
            <div className="flex flex-col md:flex-row gap-4 my-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input placeholder="Buscar por nome ou SKU..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
              </div>
            </div>
            {renderTable(products)}
            <div className="flex items-center justify-between pt-4">
                <span className="text-sm text-gray-700">Página {pagination.page + 1} de {totalPages || 1}</span>
                <div className="flex gap-2">
                    <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))} disabled={pagination.page === 0}>Anterior</Button>
                    <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))} disabled={pagination.page >= totalPages - 1}>Próximo</Button>
                </div>
            </div>
          </TabsContent>
          <TabsContent value="suggestions">
             <div className="pt-4">
                {renderTable(purchaseSuggestions, true)}
             </div>
          </TabsContent>
        </Tabs>
      </div>

      {isProdutoDialogOpen && <ProdutoDialog isOpen={isProdutoDialogOpen} onClose={() => setIsProdutoDialogOpen(false)} onSaveSuccess={fetchProducts} product={selectedProduct} user={user} />}
      {isHistoryDialogOpen && <ProdutoHistorico isOpen={isHistoryDialogOpen} onClose={() => setIsHistoryDialogOpen(false)} productId={selectedProduct?.id} />}

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. Isso excluirá permanentemente o produto.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteProduct} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ProdutosList;
