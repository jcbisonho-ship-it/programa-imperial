
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { ArrowUp, ArrowDown, Wrench, Edit } from 'lucide-react';
import { format } from 'date-fns';

const ProdutoHistorico = ({ isOpen, onClose, productId }) => {
  const [history, setHistory] = useState([]);
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchHistory = useCallback(async () => {
    if (!productId) return;
    setLoading(true);
    try {
      const { data: productData, error: productError } = await supabase
        .from('products')
        .select('*')
        .eq('id', productId)
        .single();
      if (productError) throw productError;
      setProduct(productData);

      const { data: historyData, error: historyError } = await supabase
        .from('product_history')
        .select('*')
        .eq('product_id', productId)
        .order('created_at', { ascending: false });
      if (historyError) throw historyError;
      setHistory(historyData);
    } catch (error) {
      toast({ title: 'Erro ao carregar histórico', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [productId, toast]);

  useEffect(() => {
    if (isOpen) {
      fetchHistory();
    }
  }, [isOpen, fetchHistory]);
  
  const getReasonIcon = (reason) => {
    if (reason.includes('Ordem de Serviço')) return <Wrench className="w-4 h-4 text-blue-500" />;
    if (reason.includes('Ajuste') || reason.includes('Inicial')) return <Edit className="w-4 h-4 text-yellow-500" />;
    return <ArrowUp className="w-4 h-4 text-gray-500" />;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Histórico de Estoque</DialogTitle>
          {product && <DialogDescription>Produto: {product.name} (SKU: {product.sku})</DialogDescription>}
        </DialogHeader>
        <div className="py-4">
          {loading ? (
             <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-600"></div>
             </div>
          ) : history.length > 0 ? (
            <div className="space-y-4">
                {history.map(log => (
                    <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg bg-gray-50">
                        <div className="flex items-center gap-3">
                           {log.quantity_change > 0 
                                ? <ArrowUp className="w-5 h-5 text-green-500" />
                                : <ArrowDown className="w-5 h-5 text-red-500" />
                           }
                           <div>
                                <p className="font-semibold">
                                    {log.quantity_change > 0 ? `+${log.quantity_change}` : log.quantity_change} unidades
                                </p>
                                <p className="text-sm text-gray-500 flex items-center gap-1">
                                    {getReasonIcon(log.reason)}
                                    {log.reason}
                                    {log.reference_id && ` (#${log.reference_id.substring(0, 8)})`}
                                </p>
                           </div>
                        </div>
                        <p className="text-xs text-gray-400">{format(new Date(log.created_at), 'dd/MM/yyyy HH:mm')}</p>
                    </div>
                ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-10">Nenhum histórico encontrado para este produto.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProdutoHistorico;
