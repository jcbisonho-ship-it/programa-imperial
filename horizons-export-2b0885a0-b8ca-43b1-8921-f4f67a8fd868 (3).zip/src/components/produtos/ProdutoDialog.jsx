
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { logAuditEvent } from '@/lib/audit';

const getInitialState = (product) => ({
  sku: product?.sku || '',
  name: product?.name || '',
  category: product?.category || '',
  cost_price: product?.cost_price || '',
  sale_price: product?.sale_price || '',
  stock: product?.stock || 0,
  min_stock: product?.min_stock || 0,
  observations: product?.observations || '',
});

const ProdutoDialog = ({ isOpen, onClose, onSaveSuccess, product, user }) => {
  const [formData, setFormData] = useState(getInitialState(product));
  const [initialStock, setInitialStock] = useState(0);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const initialState = getInitialState(product);
    setFormData(initialState);
    setInitialStock(product?.stock || 0);
  }, [product, isOpen]);

  const validateSKU = async (sku) => {
    if (!sku) return true;
    const query = supabase.from('products').select('id').eq('sku', sku);
    if (product?.id) {
      query.neq('id', product.id);
    }
    const { data, error } = await query;
    if (error) {
      toast({ title: 'Erro ao validar SKU', description: error.message, variant: 'destructive' });
      return false;
    }
    if (data.length > 0) {
      toast({ title: 'SKU duplicado', description: 'Este SKU já está cadastrado.', variant: 'destructive' });
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (formData.sku && !(await validateSKU(formData.sku))) {
      setLoading(false);
      return;
    }

    try {
      const payload = { ...formData, cost_price: Number(formData.cost_price), sale_price: Number(formData.sale_price), stock: Number(formData.stock), min_stock: Number(formData.min_stock) };
      let result;
      let action;
      let stockChange = 0;

      if (product?.id) {
        result = await supabase.from('products').update(payload).eq('id', product.id).select().single();
        action = 'update_product';
        stockChange = Number(formData.stock) - initialStock;
      } else {
        result = await supabase.from('products').insert(payload).select().single();
        action = 'create_product';
        stockChange = Number(formData.stock); // Initial stock
      }

      if (result.error) throw result.error;
      const newProduct = result.data;
      
      await logAuditEvent(user.id, action, { productId: newProduct.id, name: newProduct.name });
      
      // Log stock change in product_history
      if (stockChange !== 0) {
        const reason = product?.id ? 'Ajuste de Estoque (Manual)' : 'Estoque Inicial';
        const { error: historyError } = await supabase.from('product_history').insert({
            product_id: newProduct.id,
            quantity_change: stockChange,
            reason: reason,
        });
        if (historyError) throw historyError;
      }

      toast({ title: `Produto ${product?.id ? 'atualizado' : 'cadastrado'}!` });
      onSaveSuccess();
      onClose();
    } catch (error) {
      toast({ title: 'Erro ao salvar produto', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };
  
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{product ? 'Editar Produto' : 'Novo Produto'}</DialogTitle>
          <DialogDescription>Preencha os dados do produto abaixo.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1"><Label htmlFor="name">Nome do Produto *</Label><Input id="name" required value={formData.name} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="sku">SKU (Código)</Label><Input id="sku" value={formData.sku} onChange={handleChange} /></div>
            <div className="space-y-1 md:col-span-2"><Label htmlFor="category">Categoria</Label><Input id="category" value={formData.category} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="cost_price">Preço de Custo *</Label><Input id="cost_price" type="number" step="0.01" required value={formData.cost_price} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="sale_price">Preço de Venda *</Label><Input id="sale_price" type="number" step="0.01" required value={formData.sale_price} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="stock">Estoque Atual *</Label><Input id="stock" type="number" required value={formData.stock} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="min_stock">Estoque Mínimo *</Label><Input id="min_stock" type="number" required value={formData.min_stock} onChange={handleChange} /></div>
            <div className="md:col-span-2 space-y-1"><Label htmlFor="observations">Descrição / Observações</Label><Textarea id="observations" value={formData.observations} onChange={handleChange} /></div>
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ProdutoDialog;
