
import React, { useState, useEffect, useCallback } from 'react';
import { useDebounce } from '@/hooks/useDebounce';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Edit, Trash2, Eye, PlusCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import OrcamentoDialog from '@/components/orcamentos/OrcamentoDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { v4 as uuidv4 } from 'uuid';

const sampleBudgets = [
    { id: 'b1', customer_name: 'João Silva', vehicle_description: 'Corolla (BRA2E19)', created_at: '2025-11-15T10:00:00Z', total_cost: 1200.50, status: 'approved' },
    { id: 'b2', customer_name: 'Maria Oliveira', vehicle_description: 'Civic (ABC1D23)', created_at: '2025-11-14T14:30:00Z', total_cost: 850.00, status: 'pending' },
    { id: 'b3', customer_name: 'Ana Costa', vehicle_description: 'Mustang (DEF4E56)', created_at: '2025-11-13T09:00:00Z', total_cost: 3500.75, status: 'rejected' },
    { id: 'b4', customer_name: 'Rafael Souza', vehicle_description: 'Golf (GHI7J89)', created_at: '2025-11-16T11:00:00Z', total_cost: 450.00, status: 'pending' },
];

const OrcamentosList = () => {
  const { toast } = useToast();
  const [allBudgets, setAllBudgets] = useState(sampleBudgets);
  const [filteredBudgets, setFilteredBudgets] = useState(sampleBudgets);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({ page: 0, pageSize: 10 });
  
  const [isBudgetDialogOpen, setIsBudgetDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedBudget, setSelectedBudget] = useState(null);

  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const filterAndPaginateBudgets = useCallback(() => {
    setLoading(true);
    let filtered = allBudgets;
    if (debouncedSearchTerm) {
        filtered = allBudgets.filter(b =>
            b.customer_name.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
            b.vehicle_description.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
        );
    }
    
    const { page, pageSize } = pagination;
    const start = page * pageSize;
    const end = start + pageSize;
    
    setFilteredBudgets(filtered.slice(start, end));
    setLoading(false);
  }, [allBudgets, debouncedSearchTerm, pagination]);

  useEffect(() => {
    filterAndPaginateBudgets();
  }, [filterAndPaginateBudgets]);

  const openBudgetDialog = (budget = null) => {
    setSelectedBudget(budget);
    setIsBudgetDialogOpen(true);
  };

  const openDeleteDialog = (budget) => {
    setSelectedBudget(budget);
    setIsDeleteDialogOpen(true);
  };
  
  const handleNotImplemented = () => {
    toast({ title: 'Funcionalidade não implementada', description: 'A visualização de orçamento será adicionada em breve.' });
  };
  
  const handleSaveBudget = (budgetData) => {
    if (budgetData.id) { // Edit
        setAllBudgets(prev => prev.map(b => b.id === budgetData.id ? { ...b, ...budgetData } : b));
        toast({ title: 'Orçamento atualizado com sucesso!' });
    } else { // Create
        const newBudget = { ...budgetData, id: uuidv4(), created_at: new Date().toISOString() };
        setAllBudgets(prev => [newBudget, ...prev]);
        toast({ title: 'Orçamento criado com sucesso!' });
    }
    setIsBudgetDialogOpen(false);
    setSelectedBudget(null);
  };

  const handleDeleteBudget = async () => {
    if (!selectedBudget) return;

    setAllBudgets(prev => prev.filter(b => b.id !== selectedBudget.id));
    toast({ title: 'Orçamento deletado com sucesso!' });

    setIsDeleteDialogOpen(false);
    setSelectedBudget(null);
  };

  const totalPages = Math.ceil(allBudgets.filter(b => debouncedSearchTerm ? (b.customer_name.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) || b.vehicle_description.toLowerCase().includes(debouncedSearchTerm.toLowerCase())) : true).length / pagination.pageSize);

  const statusMap = {
    pending: { label: 'Pendente', variant: 'warning' },
    approved: { label: 'Aprovado', variant: 'success' },
    rejected: { label: 'Rejeitado', variant: 'destructive' },
  };
  
  const handleDialogClose = () => {
      setIsBudgetDialogOpen(false);
      setSelectedBudget(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Orçamentos</h1>
        <Button onClick={() => openBudgetDialog()}>
          <PlusCircle className="w-4 h-4 mr-2" /> Novo Orçamento
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow p-4">
        <div className="mb-4">
          <Input placeholder="Buscar por cliente ou veículo..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Cliente</TableHead>
              <TableHead className="hidden md:table-cell">Veículo</TableHead>
              <TableHead>Valor</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan="5" className="text-center">Carregando...</TableCell></TableRow>
            ) : filteredBudgets.length > 0 ? (
              filteredBudgets.map(budget => {
                const statusInfo = statusMap[budget.status] || { label: budget.status, variant: 'default' };
                return (
                  <TableRow key={budget.id}>
                    <TableCell>{budget.customer_name}</TableCell>
                    <TableCell className="hidden md:table-cell">{budget.vehicle_description}</TableCell>
                    <TableCell>{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(budget.total_cost)}</TableCell>
                    <TableCell><Badge variant={statusInfo.variant} className="capitalize">{statusInfo.label}</Badge></TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="w-4 h-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleNotImplemented()}><Eye className="w-4 h-4 mr-2" /> Visualizar</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openBudgetDialog(budget)}><Edit className="w-4 h-4 mr-2" /> Editar</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={() => openDeleteDialog(budget)}><Trash2 className="w-4 h-4 mr-2" /> Excluir</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow><TableCell colSpan="5" className="text-center">Nenhum orçamento encontrado.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
        
        <div className="flex items-center justify-between pt-4">
          <span className="text-sm text-muted-foreground">Página {pagination.page + 1} de {totalPages || 1}</span>
          <div className="flex gap-2">
            <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))} disabled={pagination.page === 0}>Anterior</Button>
            <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))} disabled={pagination.page >= totalPages - 1}>Próximo</Button>
          </div>
        </div>
      </div>
      
      {isBudgetDialogOpen && <OrcamentoDialog isOpen={isBudgetDialogOpen} onClose={handleDialogClose} onSaveSuccess={handleSaveBudget} budget={selectedBudget} />}

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita. Isso excluirá permanentemente o orçamento.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteBudget}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default OrcamentosList;
