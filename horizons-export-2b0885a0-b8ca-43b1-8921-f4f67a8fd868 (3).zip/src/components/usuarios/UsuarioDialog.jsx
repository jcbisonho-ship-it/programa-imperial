
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { adminCreateUser, adminUpdateUser } from '@/services/authService';

const roles = ['admin', 'manager', 'mechanic', 'receptionist'];

const UsuarioDialog = ({ isOpen, onClose, onSaveSuccess, user }) => {
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        full_name: '',
        role: 'receptionist',
    });

    useEffect(() => {
        if (user) {
            setFormData({
                email: user.email || '',
                password: '',
                full_name: user.full_name || '',
                role: user.role || 'receptionist',
            });
        } else {
            setFormData({ email: '', password: '', full_name: '', role: 'receptionist' });
        }
    }, [user]);

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleRoleChange = (value) => {
        setFormData(prev => ({ ...prev, role: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            if (user) { // Editing existing user
                const updates = {
                    user_metadata: { full_name: formData.full_name, role: formData.role },
                };
                if (formData.email !== user.email) {
                    updates.email = formData.email;
                }
                if (formData.password) {
                    updates.password = formData.password;
                }
                const { error } = await adminUpdateUser(user.id, updates);
                if (error) throw error;
                toast({ title: 'Usuário atualizado com sucesso!' });
            } else { // Creating new user
                const { error } = await adminCreateUser(formData.email, formData.password, formData.full_name, formData.role);
                if (error) throw error;
                toast({ title: 'Usuário criado com sucesso!' });
            }
            onSaveSuccess();
            onClose();
        } catch (error) {
            toast({ title: `Erro ao ${user ? 'atualizar' : 'criar'} usuário`, description: error.message, variant: 'destructive' });
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{user ? 'Editar' : 'Novo'} Usuário</DialogTitle>
                    <DialogDescription>Preencha os dados do usuário.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <Label htmlFor="full_name">Nome Completo</Label>
                        <Input id="full_name" value={formData.full_name} onChange={handleChange} required />
                    </div>
                    <div>
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" value={formData.email} onChange={handleChange} required />
                    </div>
                    <div>
                        <Label htmlFor="password">Senha</Label>
                        <Input id="password" type="password" placeholder={user ? 'Deixe em branco para não alterar' : ''} onChange={handleChange} required={!user} />
                    </div>
                    <div>
                        <Label htmlFor="role">Perfil de Acesso</Label>
                        <Select value={formData.role} onValueChange={handleRoleChange}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                                {roles.map(role => (
                                    <SelectItem key={role} value={role} className="capitalize">{role}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
                        <Button type="submit" disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default UsuarioDialog;
