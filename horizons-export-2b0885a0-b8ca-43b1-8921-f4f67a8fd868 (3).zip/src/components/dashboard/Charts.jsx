
import React, { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const ChartContainer = ({ title, children, loading }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-base font-semibold">{title}</CardTitle>
    </CardHeader>
    <CardContent className="h-[300px] w-full">
      {loading ? (
        <div className="flex items-center justify-center h-full">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          {children}
        </ResponsiveContainer>
      )}
    </CardContent>
  </Card>
);

const Charts = ({ dateRange }) => {
  const [revenueData, setRevenueData] = useState([]);
  const [osStatusData, setOsStatusData] = useState([]);
  const [dailyRevenueData, setDailyRevenueData] = useState([]);
  const [loading, setLoading] = useState(true);

  const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  const fetchChartData = useCallback(async () => {
    setLoading(true);
    try {
      const from = dateRange.from.toISOString();
      const to = dateRange.to.toISOString();

      const { data: reportData, error: reportError } = await supabase.rpc('get_financial_report', { p_start_date: from, p_end_date: to });
      if (reportError) throw reportError;
      
      const revenueTrend = reportData.revenue_trend || [];
      const barData = revenueTrend.map(d => ({ date: new Date(d.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit'}), receita: d.revenue, lucro: d.profit }));
      setRevenueData(barData);
      setDailyRevenueData(barData);

      const { data: osData, error: osError } = await supabase.from('work_orders').select('status');
      if (osError) throw osError;
      
      const statusCounts = osData.reduce((acc, { status }) => {
        const statusKey = status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ');
        acc[statusKey] = (acc[statusKey] || 0) + 1;
        return acc;
      }, {});
      const pieData = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));
      setOsStatusData(pieData);

    } catch (error) {
      console.error("Error fetching chart data:", error);
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    fetchChartData();
  }, [fetchChartData]);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];
  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    if (percent < 0.05) return null;
    return (
      <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" className="text-xs font-bold">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };
  
  return (
    <div className="space-y-6">
        <Tabs defaultValue="revenue" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="revenue">Receita e Lucro</TabsTrigger>
                <TabsTrigger value="os">Status das OS</TabsTrigger>
            </TabsList>
            <TabsContent value="revenue">
                <ChartContainer title="Receita vs. Lucro (Período)" loading={loading}>
                    <BarChart data={revenueData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `R$${value/1000}k`} />
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                        <Legend wrapperStyle={{fontSize: "12px"}}/>
                        <Bar dataKey="receita" fill="hsl(var(--primary))" name="Receita" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="lucro" fill="hsl(var(--primary) / 0.5)" name="Lucro" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ChartContainer>
            </TabsContent>
            <TabsContent value="os">
                <ChartContainer title="Distribuição de Status de OS" loading={loading}>
                    <PieChart>
                        <Pie data={osStatusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" labelLine={false} label={renderCustomizedLabel}>
                            {osStatusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                        <Legend wrapperStyle={{fontSize: "12px"}}/>
                    </PieChart>
                </ChartContainer>
            </TabsContent>
        </Tabs>
        
        <ChartContainer title="Tendência de Receita Diária (Período)" loading={loading}>
            <LineChart data={dailyRevenueData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `R$${value/1000}k`} />
                <Tooltip formatter={(value) => formatCurrency(value)} />
                <Legend wrapperStyle={{fontSize: "12px"}}/>
                <Line type="monotone" dataKey="receita" stroke="hsl(var(--primary))" strokeWidth={2} name="Receita" dot={false}/>
            </LineChart>
        </ChartContainer>
    </div>
  );
};

export default Charts;
