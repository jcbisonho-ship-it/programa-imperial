
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Wrench, User, FileText, CheckCircle, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/components/ui/use-toast';

const ICONS = {
  create_work_order: <Wrench className="h-4 w-4 text-white" />,
  update_work_order: <Wrench className="h-4 w-4 text-white" />,
  create_customer: <User className="h-4 w-4 text-white" />,
  update_customer: <User className="h-4 w-4 text-white" />,
  create_budget: <FileText className="h-4 w-4 text-white" />,
  update_budget: <FileText className="h-4 w-4 text-white" />,
  default: <CheckCircle className="h-4 w-4 text-white" />,
};

const COLORS = {
    create: 'bg-green-500',
    update: 'bg-blue-500',
    delete: 'bg-red-500',
    default: 'bg-gray-500',
}

const RecentActivities = () => {
    const [activities, setActivities] = useState([]);
    const [users, setUsers] = useState({});
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();

    const fetchUsers = useCallback(async (userIds) => {
        const { data, error } = await supabase
            .from('users_data')
            .select('id, full_name')
            .in('id', userIds);
        
        if (error) {
            toast({ title: 'Erro ao buscar usuários', description: error.message, variant: 'destructive' });
            return {};
        }

        return data.reduce((acc, user) => {
            acc[user.id] = user.full_name;
            return acc;
        }, {});
    }, [toast]);

    const fetchActivities = useCallback(async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from('audit_log')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(10);
        
        if (error) {
            toast({ title: "Erro ao buscar atividades", description: error.message, variant: 'destructive' });
        } else {
            setActivities(data);
            const userIds = [...new Set(data.map(log => log.user_id).filter(Boolean))];
            if (userIds.length > 0) {
                const usersData = await fetchUsers(userIds);
                setUsers(usersData);
            }
        }
        setLoading(false);
    }, [toast, fetchUsers]);

    useEffect(() => {
        fetchActivities();
    }, [fetchActivities]);

    const activitiesWithUserNames = useMemo(() => {
        return activities.map(activity => ({
            ...activity,
            user_name: users[activity.user_id]
        }));
    }, [activities, users]);
    
    const formatDescription = (action, details) => {
        switch(action) {
            case 'create_work_order':
                return `Nova OS criada: #${details?.orderId?.substring(0, 5)}`;
            case 'update_work_order':
                 return `OS #${details?.orderId?.substring(0, 5)} atualizada`;
            case 'create_customer':
                return `Novo cliente cadastrado`;
            default:
                return action.replace(/_/g, ' ');
        }
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Atividade Recente</CardTitle>
            </CardHeader>
            <CardContent>
                {loading ? (
                    <div className="space-y-4">
                        {[...Array(5)].map((_, i) => (
                            <div key={i} className="flex items-center space-x-4">
                                <div className="h-8 w-8 rounded-full bg-gray-200 animate-pulse"></div>
                                <div className="space-y-2 flex-1">
                                    <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-3 bg-gray-200 rounded w-1/2 animate-pulse"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : activities.length > 0 ? (
                    <ScrollArea className="h-[260px] pr-4">
                        <div className="space-y-6">
                            {activitiesWithUserNames.map(activity => (
                                <div key={activity.id} className="flex items-center">
                                    <div className={`mr-4 p-2 rounded-full ${COLORS[activity.action.split('_')[0]] || COLORS.default}`}>
                                        {ICONS[activity.action] || ICONS.default}
                                    </div>
                                    <div className="flex-grow">
                                        <p className="text-sm">{formatDescription(activity.action, activity.details)}</p>
                                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                                            <Clock className="h-3 w-3" />
                                            {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true, locale: ptBR })}
                                            {activity.user_name && ` por ${activity.user_name}`}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </ScrollArea>
                ) : (
                    <p className="text-sm text-muted-foreground text-center py-10">Nenhuma atividade recente.</p>
                )}
                 <Button variant="outline" size="sm" className="w-full mt-4" onClick={fetchActivities}>Atualizar</Button>
            </CardContent>
        </Card>
    );
};

export default RecentActivities;
