
import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, Search, Check, X, FileText, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import BudgetDialog from '@/components/dialogs/BudgetDialog';
import { sendBudgetNotification } from '@/lib/whatsapp';

const Budgets = ({ setActiveTab }) => {
  const [budgets, setBudgets] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const loadBudgets = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .rpc('get_budget_summary')
        .order('created_at', { ascending: false });
      if (error) throw error;
      setBudgets(data || []);
    } catch (error) {
      toast({ title: "Erro ao carregar orçamentos", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadBudgets();
  }, [loadBudgets]);

  const handleDeleteBudget = async (id) => {
    try {
      // First, delete related budget items
      await supabase.from('budget_items').delete().eq('budget_id', id);
      // Then, delete the budget itself
      const { error } = await supabase.from('budgets').delete().eq('id', id);
      if (error) throw error;
      loadBudgets();
      toast({ title: "Orçamento removido!", description: "O orçamento foi removido do sistema." });
    } catch (error) {
      toast({ title: "Erro ao remover orçamento", description: error.message, variant: "destructive" });
    }
  };
  
  const handleStatusChange = async (budget, newStatus) => {
    try {
      const { error } = await supabase.from('budgets').update({ status: newStatus }).eq('id', budget.id);
      if (error) throw error;
      
      if (newStatus === 'approved') {
        await convertToWorkOrder(budget);
        // This is a placeholder for a notification system
        // sendBudgetNotification(budget.id, 'approved'); 
      } else if (newStatus === 'rejected') {
        // sendBudgetNotification(budget.id, 'rejected');
      }
      
      loadBudgets();
      toast({ title: `Orçamento ${newStatus === 'approved' ? 'aprovado' : 'rejeitado'}!`, description: "O status foi atualizado." });
    } catch (error) {
      toast({ title: "Erro ao atualizar status", description: error.message, variant: "destructive" });
    }
  };

  const convertToWorkOrder = async (budget) => {
      // Fetch the full budget details including items and services
      const { data: fullBudget, error: budgetError } = await supabase
        .from('budgets')
        .select(`*, budget_items(*)`)
        .eq('id', budget.id)
        .single();
      
      if (budgetError || !fullBudget) {
        throw new Error(budgetError?.message || "Orçamento não encontrado para conversão.");
      }

    const { data: existingOS, error: existingOSError } = await supabase
      .from('work_orders')
      .select('id')
      .eq('title', `OS do Orçamento #${fullBudget.id.substring(0, 5)}`);

    if (existingOSError && existingOSError.code !== 'PGRST116') { // PGRST116 is "exact number of rows not found"
        toast({ title: "Erro ao verificar OS", description: existingOSError.message, variant: "destructive" });
        return;
    }

    if (existingOS && existingOS.length > 0) {
        toast({ title: "OS já existe", description: "Uma OS para este orçamento já foi criada.", variant: "destructive" });
        return;
    }

    const { data: workOrder, error: osError } = await supabase.from('work_orders').insert({
        customer_id: fullBudget.customer_id,
        vehicle_id: fullBudget.vehicle_id,
        title: `OS do Orçamento #${fullBudget.id.substring(0, 5)}`,
        description: `Serviços e peças conforme orçamento #${fullBudget.id}. Status inicial: pendente.`,
        status: 'pending',
        order_date: new Date().toISOString().split('T')[0]
    }).select().single();

    if (osError) throw osError;

    const itemsToInsert = (fullBudget.budget_items || []).map(item => {
        const { id, budget_id, created_at, ...rest } = item;
        return { ...rest, work_order_id: workOrder.id };
    });

    if (itemsToInsert.length > 0) {
      const { error: itemsError } = await supabase.from('work_order_items').insert(itemsToInsert);
      if (itemsError) {
          // Rollback OS creation if items fail
          await supabase.from('work_orders').delete().eq('id', workOrder.id);
          throw itemsError;
      }
    }

    toast({ title: "Ordem de Serviço Criada!", description: "O orçamento foi convertido em OS." });
    if(setActiveTab) setActiveTab('os');
  };

  const getStatusChip = (status) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      approved: 'bg-green-100 text-green-800 border-green-200',
      rejected: 'bg-red-100 text-red-800 border-red-200',
    };
    return `px-3 py-1 text-xs font-medium rounded-full border ${styles[status] || 'bg-gray-100 text-gray-800'}`;
  };

  const filteredBudgets = budgets.filter(b => 
    (b.customer_name && b.customer_name.toLowerCase().includes(searchTerm.toLowerCase())) || 
    (b.vehicle_description && b.vehicle_description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6 relative h-full">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Orçamentos</h2>
          <p className="text-gray-600">Crie e gerencie os orçamentos para seus clientes.</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input type="text" placeholder="Buscar por cliente ou veículo..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg" />
        </div>

        {loading ? <div className="flex justify-center items-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div> : filteredBudgets.length === 0 ? (
          <div className="text-center py-12"><FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" /><p className="text-gray-500">Nenhum orçamento encontrado.</p></div>
        ) : (
          <div className="space-y-4">
            {filteredBudgets.map((budget, index) => (
              <motion.div key={budget.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }} className="border rounded-lg p-5 hover:shadow-md transition-all">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-lg">{budget.customer_name}</h3>
                    <p className="text-sm text-gray-600">{budget.vehicle_description}</p>
                    <p className="text-xl font-bold text-blue-600 mt-2">R$ {Number(budget.total_cost).toFixed(2)}</p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                     <span className={getStatusChip(budget.status)}>{budget.status}</span>
                     <div className="flex gap-2">
                        {budget.status === 'pending' && (
                            <>
                                <Button size="sm" variant="outline" className="text-green-600 border-green-600 hover:bg-green-50" onClick={() => handleStatusChange(budget, 'approved')}><Check className="w-4 h-4 mr-1"/> Aprovar</Button>
                                <Button size="sm" variant="outline" className="text-red-600 border-red-600 hover:bg-red-50" onClick={() => handleStatusChange(budget, 'rejected')}><X className="w-4 h-4 mr-1"/> Rejeitar</Button>
                            </>
                        )}
                        {budget.status === 'rejected' && (
                            <Button size="sm" variant="outline" onClick={() => handleStatusChange(budget, 'pending')}><RefreshCw className="w-4 h-4 mr-1"/> Reabrir</Button>
                        )}
                        <Button size="icon" variant="ghost" onClick={() => { setEditingBudget(budget); setIsDialogOpen(true); }}><Edit className="w-4 h-4" /></Button>
                        <Button size="icon" variant="ghost" className="text-red-600" onClick={() => handleDeleteBudget(budget.id)}><Trash2 className="w-4 h-4" /></Button>
                     </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

       <Button
        onClick={() => { setEditingBudget(null); setIsDialogOpen(true); }}
        className="absolute bottom-6 right-6 rounded-full w-16 h-16 bg-blue-600 hover:bg-blue-700 shadow-lg"
      >
        <Plus className="w-8 h-8" />
      </Button>

      <BudgetDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} onSave={loadBudgets} budget={editingBudget} />
    </div>
  );
};

export default Budgets;
