
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Camera } from 'lucide-react';

const TemplateCustomizer = () => {
    const { toast } = useToast();
    const [loading, setLoading] = useState(true);
    const [template, setTemplate] = useState({
        company_logo_url: '',
        primary_color: '#3b82f6',
        company_info: { name: '', address: '', phone: '', email: '' },
        footer_text: '',
        terms_and_conditions: '',
    });
    const fileInputRef = useRef(null);

    useEffect(() => {
        const fetchTemplate = async () => {
            setLoading(true);
            const { data, error } = await supabase.from('document_templates').select('*').eq('id', 1).single();
            if (error && error.code !== 'PGRST116') { // Ignore 'no rows found'
                toast({ title: 'Erro ao carregar template', description: error.message, variant: 'destructive' });
            } else if (data) {
                setTemplate(data);
            }
            setLoading(false);
        };
        fetchTemplate();
    }, [toast]);

    const handleInfoChange = (e) => {
        const { id, value } = e.target;
        setTemplate(prev => ({ ...prev, company_info: { ...prev.company_info, [id]: value } }));
    };

    const handleFieldChange = (e) => {
        const { id, value } = e.target;
        setTemplate(prev => ({ ...prev, [id]: value }));
    };

    const handleLogoUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        setLoading(true);
        const filePath = `public/logo-${Date.now()}`;
        const { error: uploadError } = await supabase.storage.from('documents').upload(filePath, file);
        
        if (uploadError) {
            toast({ title: 'Erro no upload', description: uploadError.message, variant: 'destructive' });
            setLoading(false);
            return;
        }

        const { data: urlData } = supabase.storage.from('documents').getPublicUrl(filePath);
        setTemplate(prev => ({ ...prev, company_logo_url: urlData.publicUrl }));
        setLoading(false);
        toast({ title: 'Logo carregado com sucesso!' });
    };

    const handleSave = async () => {
        setLoading(true);
        const { error } = await supabase.from('document_templates').update(template).eq('id', 1);
        if (error) {
            toast({ title: 'Erro ao salvar', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Template salvo com sucesso!' });
        }
        setLoading(false);
    };

    if (loading && !template.company_info) {
        return <div className="text-center p-12">Carregando...</div>;
    }

    return (
        <div className="bg-white rounded-xl shadow-lg p-6 mt-4 space-y-8">
            <div>
                <h3 className="text-lg font-semibold">Identidade Visual</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                    <div className="flex items-center gap-4">
                        <img src={template.company_logo_url || 'https://via.placeholder.com/100'} alt="Logo" className="w-24 h-24 object-contain border rounded-md" />
                        <Button type="button" onClick={() => fileInputRef.current.click()}>
                            <Camera className="w-4 h-4 mr-2" /> Alterar Logo
                        </Button>
                        <Input type="file" ref={fileInputRef} onChange={handleLogoUpload} accept="image/*" className="hidden" />
                    </div>
                    <div>
                        <Label htmlFor="primary_color">Cor Primária</Label>
                        <Input id="primary_color" type="color" value={template.primary_color} onChange={handleFieldChange} className="w-24 h-12 p-1" />
                    </div>
                </div>
            </div>

            <div>
                <h3 className="text-lg font-semibold">Informações da Empresa</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div><Label>Nome da Empresa</Label><Input id="name" value={template.company_info.name} onChange={handleInfoChange} /></div>
                    <div><Label>Endereço</Label><Input id="address" value={template.company_info.address} onChange={handleInfoChange} /></div>
                    <div><Label>Telefone</Label><Input id="phone" value={template.company_info.phone} onChange={handleInfoChange} /></div>
                    <div><Label>Email</Label><Input id="email" value={template.company_info.email} onChange={handleInfoChange} /></div>
                </div>
            </div>

            <div>
                <h3 className="text-lg font-semibold">Textos Padrão</h3>
                <div className="space-y-4 mt-4">
                    <div><Label>Texto do Rodapé</Label><Input id="footer_text" value={template.footer_text} onChange={handleFieldChange} /></div>
                    <div><Label>Termos e Condições</Label><Textarea id="terms_and_conditions" value={template.terms_and_conditions} onChange={handleFieldChange} rows={5} /></div>
                </div>
            </div>

            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={loading}>{loading ? 'Salvando...' : 'Salvar Alterações'}</Button>
            </div>
        </div>
    );
};

export default TemplateCustomizer;
