
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Search, MoreHorizontal, Eye, Download, Mail } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import PDFPreview from './PDFPreview';
import { resendEmail } from '@/services/emailService';

const DocumentosList = () => {
    const { toast } = useToast();
    const [documents, setDocuments] = useState([]);
    const [filteredDocuments, setFilteredDocuments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isPreviewOpen, setIsPreviewOpen] = useState(false);
    const [selectedDocumentUrl, setSelectedDocumentUrl] = useState('');

    const fetchDocuments = useCallback(async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from('documents')
            .select('*, customer:customers(name)')
            .order('generated_at', { ascending: false });
        
        if (error) {
            toast({ title: 'Erro ao carregar documentos', description: error.message, variant: 'destructive' });
        } else {
            setDocuments(data);
            setFilteredDocuments(data);
        }
        setLoading(false);
    }, [toast]);

    useEffect(() => {
        fetchDocuments();
    }, [fetchDocuments]);

    useEffect(() => {
        const results = documents.filter(doc =>
            doc.customer?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            doc.document_type?.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredDocuments(results);
    }, [searchTerm, documents]);

    const openPreview = (url) => {
        setSelectedDocumentUrl(url);
        setIsPreviewOpen(true);
    };

    const handleResend = async (doc) => {
        toast({ title: 'Reenviando e-mail...' });
        const { error } = await resendEmail(doc);
        if (error) {
            toast({ title: 'Erro ao reenviar', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'E-mail reenviado com sucesso!' });
            fetchDocuments(); // Refresh to show updated sent_at
        }
    };

    return (
        <div className="bg-white rounded-xl shadow-lg p-6 mt-4">
            <div className="flex justify-between items-center mb-4">
                <div className="relative w-72">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input placeholder="Buscar por cliente ou tipo..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3">Tipo</th>
                            <th scope="col" className="px-6 py-3">Cliente</th>
                            <th scope="col" className="px-6 py-3">Data Geração</th>
                            <th scope="col" className="px-6 py-3">Enviado em</th>
                            <th scope="col" className="px-6 py-3 text-right">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan="5" className="text-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div></td></tr>
                        ) : filteredDocuments.map(doc => (
                            <tr key={doc.id} className="bg-white border-b hover:bg-gray-50">
                                <td className="px-6 py-4"><Badge className="capitalize">{doc.document_type.replace('_', ' ')}</Badge></td>
                                <td className="px-6 py-4 font-medium text-gray-900">{doc.customer?.name || 'N/A'}</td>
                                <td className="px-6 py-4">{format(new Date(doc.generated_at), 'dd/MM/yyyy HH:mm')}</td>
                                <td className="px-6 py-4">{doc.sent_at ? format(new Date(doc.sent_at), 'dd/MM/yyyy HH:mm') : 'Não enviado'}</td>
                                <td className="px-6 py-4 text-right">
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="w-5 h-5" /></Button></DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                            <DropdownMenuItem onClick={() => openPreview(doc.file_url)}><Eye className="w-4 h-4 mr-2" /> Visualizar</DropdownMenuItem>
                                            <DropdownMenuItem asChild><a href={doc.file_url} target="_blank" rel="noopener noreferrer"><Download className="w-4 h-4 mr-2" /> Baixar</a></DropdownMenuItem>
                                            {doc.recipient_email && <DropdownMenuItem onClick={() => handleResend(doc)}><Mail className="w-4 h-4 mr-2" /> Reenviar E-mail</DropdownMenuItem>}
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {isPreviewOpen && <PDFPreview isOpen={isPreviewOpen} onClose={() => setIsPreviewOpen(false)} fileUrl={selectedDocumentUrl} />}
        </div>
    );
};

export default DocumentosList;
