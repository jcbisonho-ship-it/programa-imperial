
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/customSupabaseClient';
import { PlusCircle, Trash2, Search } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const BudgetDialog = ({ isOpen, onClose, onSave, budget }) => {
  const emptyForm = {
    customer_id: '',
    vehicle_id: '',
    customer_name: '',
    vehicle_description: '',
    status: 'pending',
  };
  const [formData, setFormData] = useState(emptyForm);
  const [items, setItems] = useState([]);
  const [plate, setPlate] = useState('');
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [collaborators, setCollaborators] = useState([]);
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);

  const loadInitialData = useCallback(async () => {
    const { data: customersData } = await supabase.from('customers').select('id, name').order('name');
    setCustomers(customersData || []);
    const { data: productsData } = await supabase.from('products').select('*').order('name');
    setProducts(productsData || []);
    const { data: collaboratorsData } = await supabase.from('collaborators').select('id, name').eq('role', 'Mecânico').order('name');
    setCollaborators(collaboratorsData || []);
  }, []);

  const loadBudgetItems = useCallback(async (budgetId) => {
    if (!budgetId) {
        setItems([]);
        return;
    }
    const { data, error } = await supabase
      .from('budget_items')
      .select('*, products(id, name), collaborators(id, name)')
      .eq('budget_id', budgetId);

    if (error) {
      toast({ title: 'Erro ao carregar itens do orçamento', description: error.message, variant: 'destructive' });
      setItems([]);
    } else {
        const formattedItems = data.map(item => ({
            ...item,
            description: item.description || (item.item_type === 'product' && item.products ? item.products.name : ''),
        }));
      setItems(formattedItems || []);
    }
  }, [toast]);

  useEffect(() => {
    if (isOpen) {
      loadInitialData();
      if (budget) {
        setFormData({
            id: budget.id,
            customer_id: budget.customer_id || '',
            vehicle_id: budget.vehicle_id || '',
            customer_name: budget.customer_name || '',
            vehicle_description: budget.vehicle_description || '',
            status: budget.status || 'pending',
        });
        if (budget.vehicle_id) {
          supabase.from('vehicles').select('plate').eq('id', budget.vehicle_id).single().then(({data}) => setPlate(data?.plate || ''));
        }
        loadBudgetItems(budget.id);
      } else {
        setFormData(emptyForm);
        setItems([]);
        setPlate('');
      }
    }
  }, [budget, isOpen, loadInitialData, loadBudgetItems]);
  
  const handlePlateLookup = async () => {
    if (!plate) return;
    const { data, error } = await supabase.rpc('get_vehicle_summary').eq('plate', plate.toUpperCase()).single();
    
    if (error || !data) {
      toast({ title: "Veículo não encontrado", description: "Verifique a placa ou cadastre o veículo primeiro.", variant: "destructive" });
      setFormData(prev => ({ ...prev, vehicle_id: '', customer_id: '', customer_name: '', vehicle_description: '' }));
      return;
    }
    
    const vehicle = data;
    setFormData(prev => ({
      ...prev,
      customer_id: vehicle.customer_id,
      vehicle_id: vehicle.id,
      customer_name: vehicle.customer_name,
      vehicle_description: `${vehicle.brand} ${vehicle.model} (${vehicle.year})`,
    }));
    toast({ title: "Veículo encontrado!" });
  };
  
  const handleItemChange = (index, field, value, itemType) => {
    const newItems = [...items];
    const currentItem = { ...newItems[index] };
    
    if (itemType === 'product' && field === 'product_id') {
      const product = products.find(p => p.id === value);
      if (product) {
        currentItem.product_id = value;
        currentItem.description = product.name;
        currentItem.unit_price = product.sale_price;
        currentItem.cost_price = product.cost_price;
        currentItem.quantity = 1;
        currentItem.total_price = product.sale_price * 1;
      }
    } else if (itemType === 'service' && field === 'collaborator_id') {
      currentItem.collaborator_id = value;
    } else {
      currentItem[field] = value;
    }
    
    if (field === 'quantity' || field === 'unit_price') {
      currentItem.total_price = (Number(currentItem.quantity) || 0) * (Number(currentItem.unit_price) || 0);
    }
    
    newItems[index] = currentItem;
    setItems(newItems);
  };
  
  const addItem = (itemType) => {
    const newItem = {
      budget_id: formData.id || null,
      item_type: itemType,
      description: '',
      quantity: itemType === 'product' ? 1 : 0,
      unit_price: 0,
      cost_price: 0,
      total_price: 0,
      product_id: null,
      collaborator_id: null,
    };

    if(itemType === 'service') {
        newItem.quantity = 1; // Services are usually counted as 1 unit
    }
    setItems([...items, newItem]);
  };

  const removeItem = (index) => setItems(items.filter((_, i) => i !== index));

  const calculateTotal = () => items.reduce((acc, item) => acc + (Number(item.total_price) || 0), 0);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.vehicle_id || formData.vehicle_id.length !== 36) {
      toast({ title: 'Veículo não selecionado', description: 'Por favor, busque e selecione um veículo válido.', variant: 'destructive' });
      return;
    }

    if (!formData.customer_name) {
      toast({ title: 'Cliente não encontrado', description: 'O veículo selecionado não possui um cliente associado.', variant: 'destructive' });
      return;
    }

    setIsSaving(true);
    const total_cost = calculateTotal();
    
    let budgetResponse;
    const dbPayload = {
        customer_id: formData.customer_id,
        vehicle_id: formData.vehicle_id,
        status: formData.status,
        total_cost: total_cost,
        customer_name: formData.customer_name,
        vehicle_description: formData.vehicle_description,
    };
    
    if (formData.id) {
        budgetResponse = await supabase.from('budgets').update(dbPayload).eq('id', formData.id).select().single();
    } else {
        budgetResponse = await supabase.from('budgets').insert(dbPayload).select().single();
    }
    
    if (budgetResponse.error) {
        toast({ title: 'Erro ao salvar orçamento', description: budgetResponse.error.message, variant: 'destructive' });
        setIsSaving(false);
        return;
    }
    
    const budgetId = budgetResponse.data.id;

    const { data: existingItems } = await supabase.from('budget_items').select('id').eq('budget_id', budgetId);
    const existingItemIds = existingItems?.map(i => i.id) || [];
    
    const itemsToUpsert = items.map(item => {
        const { products, collaborators, total_price, ...rest } = item;
        const itemPayload = { ...rest, budget_id: budgetId };
        
        if(itemPayload.item_type === 'service') {
            delete itemPayload.product_id;
        }

        if(!itemPayload.description){
            const product = products.find(p => p.id === itemPayload.product_id);
            if(product) itemPayload.description = product.name;
            else itemPayload.description = 'Item sem descrição';
        }
        
        return itemPayload;
    });
    const currentItemIds = itemsToUpsert.map(i => i.id).filter(Boolean);
    const itemsToDelete = existingItemIds.filter(id => !currentItemIds.includes(id));

    if(itemsToDelete.length > 0) {
        await supabase.from('budget_items').delete().in('id', itemsToDelete);
    }
    
    if(itemsToUpsert.length > 0) {
      const { error: itemsError } = await supabase.from('budget_items').upsert(itemsToUpsert);
      if (itemsError) {
          toast({ title: 'Erro ao salvar itens do orçamento', description: itemsError.message, variant: 'destructive' });
          setIsSaving(false);
          return;
      }
    }
    
    onSave();
    onClose();
    toast({ title: `Orçamento ${formData.id ? 'atualizado' : 'criado'}!`, description: "A operação foi concluída com sucesso." });
    setIsSaving(false);
  };
  
  const productItems = items.filter(item => item.item_type === 'product');
  const serviceItems = items.filter(item => item.item_type === 'service');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
            <DialogTitle>{budget ? 'Editar Orçamento' : 'Novo Orçamento'}</DialogTitle>
            <DialogDescription>Preencha os dados para criar ou editar um orçamento.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 flex-grow overflow-hidden flex flex-col">
            <div>
              <Label htmlFor="plate">Placa do Veículo</Label>
              <div className="flex gap-2">
                <Input id="plate" value={plate} onChange={e => setPlate(e.target.value)} placeholder="ABC1234" className="uppercase" />
                <Button type="button" onClick={handlePlateLookup}><Search className="w-4 h-4 mr-2" /> Buscar</Button>
              </div>
            </div>
            {formData.vehicle_id && (
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p><strong>Cliente:</strong> {formData.customer_name}</p>
                <p><strong>Veículo:</strong> {formData.vehicle_description}</p>
              </div>
            )}
            
            <Tabs defaultValue="products" className="flex-grow flex flex-col overflow-hidden">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="products">Peças/Produtos</TabsTrigger>
                    <TabsTrigger value="services">Serviços/Mão de Obra</TabsTrigger>
                </TabsList>
                <TabsContent value="products" className="flex-grow overflow-y-auto p-1 pr-3">
                    <div className="space-y-2">
                        {productItems.map((item, index) => {
                            const originalIndex = items.findIndex(i => i === item);
                            return (
                              <div key={item.id || `new-prod-${originalIndex}`} className="grid grid-cols-[1fr,90px,120px,auto] items-center gap-2 p-2 border rounded-md">
                                <Select value={item.product_id || ''} onValueChange={v => handleItemChange(originalIndex, 'product_id', v, 'product')}>
                                  <SelectTrigger><SelectValue placeholder="Selecione um produto..." /></SelectTrigger>
                                  <SelectContent>
                                    {products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                                  </SelectContent>
                                </Select>
                                <Input type="number" placeholder="Qtd" value={item.quantity} onChange={e => handleItemChange(originalIndex, 'quantity', e.target.value, 'product')} className="w-full" min="1" />
                                <Input type="number" placeholder="Preço" value={item.unit_price} onChange={e => handleItemChange(originalIndex, 'unit_price', e.target.value, 'product')} className="w-full" step="0.01" />
                                <Button type="button" size="icon" variant="ghost" onClick={() => removeItem(originalIndex)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                              </div>
                            );
                        })}
                        <Button type="button" size="sm" variant="outline" onClick={() => addItem('product')}><PlusCircle className="w-4 h-4 mr-2" /> Adicionar Peça</Button>
                    </div>
                </TabsContent>
                <TabsContent value="services" className="flex-grow overflow-y-auto p-1 pr-3">
                    <div className="space-y-2">
                        {serviceItems.map((item, index) => {
                             const originalIndex = items.findIndex(i => i === item);
                            return (
                               <div key={item.id || `new-serv-${originalIndex}`} className="grid grid-cols-[1fr,1fr,120px,auto] items-center gap-2 p-2 border rounded-md">
                                <Input placeholder="Nome do serviço" value={item.description} onChange={e => handleItemChange(originalIndex, 'description', e.target.value, 'service')} />
                                <Select value={item.collaborator_id || ''} onValueChange={v => handleItemChange(originalIndex, 'collaborator_id', v, 'service')}>
                                  <SelectTrigger><SelectValue placeholder="Selecione um mecânico..."/></SelectTrigger>
                                  <SelectContent>
                                    {collaborators.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                                  </SelectContent>
                                </Select>
                                <Input type="number" placeholder="Preço" value={item.unit_price} onChange={e => handleItemChange(originalIndex, 'unit_price', e.target.value, 'service')} className="w-full" step="0.01" />
                                <Button type="button" size="icon" variant="ghost" onClick={() => removeItem(originalIndex)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                              </div>
                            )
                        })}
                        <Button type="button" size="sm" variant="outline" onClick={() => addItem('service')}><PlusCircle className="w-4 h-4 mr-2" /> Adicionar Serviço</Button>
                    </div>
                </TabsContent>
            </Tabs>

            <div className="pt-4 border-t">
              <div className="text-right font-bold text-xl">Total: R$ {calculateTotal().toFixed(2)}</div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
              <Button type="submit" disabled={!formData.vehicle_id || !formData.customer_name || isSaving}>
                {isSaving ? 'Salvando...' : 'Salvar Orçamento'}
              </Button>
            </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default BudgetDialog;
