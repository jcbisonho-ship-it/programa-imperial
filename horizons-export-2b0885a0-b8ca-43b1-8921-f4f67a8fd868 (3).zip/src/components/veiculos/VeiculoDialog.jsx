
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { logAuditEvent } from '@/lib/audit';
import { v4 as uuidv4 } from 'uuid';
import { Car } from 'lucide-react';

const getInitialState = (vehicle) => ({
  plate: vehicle?.plate || '',
  model: vehicle?.model || '',
  brand: vehicle?.brand || '',
  year: vehicle?.year || '',
  color: vehicle?.color || '',
  observations: vehicle?.observations || '',
  customer_id: vehicle?.customer_id || '',
});

const VeiculoDialog = ({ isOpen, onClose, onSaveSuccess, vehicle, customer, customers = [], user }) => {
  const [formData, setFormData] = useState(getInitialState(vehicle));
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
        const initialData = getInitialState(vehicle);
        if (customer) {
            initialData.customer_id = customer.id;
        }
        setFormData(initialData);
        setPhotoPreview(vehicle?.photo_url || null);
        setPhotoFile(null);
    }
  }, [vehicle, customer, isOpen]);

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setPhotoPreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const uploadPhoto = async (file, plate) => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${plate.replace(/[^a-zA-Z0-9]/g, '')}-${uuidv4()}.${fileExt}`;
    const filePath = `vehicle-photos/${fileName}`;
    
    // Check if a file with a similar name exists and remove it to avoid clutter
    if (vehicle?.photo_url) {
        const oldFileName = vehicle.photo_url.split('/').pop();
        if (oldFileName) {
            await supabase.storage.from('vehicles').remove([`vehicle-photos/${oldFileName}`]);
        }
    }

    const { error: uploadError } = await supabase.storage.from('vehicles').upload(filePath, file, {
        cacheControl: '3600',
        upsert: true
    });
    if (uploadError) throw uploadError;
    
    const { data } = supabase.storage.from('vehicles').getPublicUrl(filePath);
    return data.publicUrl;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!formData.customer_id) {
        throw new Error("Cliente é obrigatório.");
      }

      const plateQuery = supabase.from('vehicles').select('id').eq('plate', formData.plate.toUpperCase());
      if (vehicle?.id) {
          plateQuery.neq('id', vehicle.id);
      }
      const { data: plateCheck, error: plateError } = await plateQuery;
      if (plateError) throw plateError;
      if (plateCheck && plateCheck.length > 0) {
        toast({ title: 'Placa já cadastrada', description: 'A placa informada já pertence a outro veículo.', variant: 'destructive' });
        setLoading(false);
        return;
      }

      let photo_url = vehicle?.photo_url || null;
      if (photoFile) {
        photo_url = await uploadPhoto(photoFile, formData.plate);
      }

      const payload = { ...formData, plate: formData.plate.toUpperCase(), photo_url };
      
      let result;
      if (vehicle?.id) {
        result = await supabase.from('vehicles').update(payload).eq('id', vehicle.id).select().single();
        if (result.error) throw result.error;
        await logAuditEvent(user?.id, 'update_vehicle', { vehicleId: result.data.id, changes: payload });
        toast({ title: 'Veículo atualizado!' });
      } else {
        result = await supabase.from('vehicles').insert(payload).select().single();
        if (result.error) throw result.error;
        await logAuditEvent(user?.id, 'create_vehicle', { vehicleId: result.data.id, plate: result.data.plate, customerId: result.data.customer_id });
        toast({ title: 'Veículo cadastrado!' });
      }

      onSaveSuccess();
      onClose();
    } catch (error) {
      toast({ title: 'Erro ao salvar veículo', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{vehicle ? 'Editar Veículo' : 'Novo Veículo'}</DialogTitle>
          <DialogDescription>
            {customer ? `Para o cliente: ${customer.name}` : 'Preencha os dados do veículo.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} id="vehicle-form" className="space-y-4">
          {(!customer && customers.length > 0) && (
            <div className="space-y-1">
                <Label htmlFor="customer_id">Cliente *</Label>
                <Select required value={formData.customer_id} onValueChange={(value) => setFormData({...formData, customer_id: value})}>
                    <SelectTrigger><SelectValue placeholder="Selecione um cliente" /></SelectTrigger>
                    <SelectContent>
                        {customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1"><Label htmlFor="plate">Placa *</Label><Input id="plate" required value={formData.plate} onChange={e => setFormData({...formData, plate: e.target.value.toUpperCase()})} /></div>
            <div className="space-y-1"><Label htmlFor="model">Modelo *</Label><Input id="model" required value={formData.model} onChange={e => setFormData({...formData, model: e.target.value})} /></div>
            <div className="space-y-1"><Label htmlFor="brand">Marca</Label><Input id="brand" value={formData.brand} onChange={e => setFormData({...formData, brand: e.target.value})} /></div>
            <div className="space-y-1"><Label htmlFor="year">Ano</Label><Input id="year" type="number" value={formData.year} onChange={e => setFormData({...formData, year: e.target.value})} /></div>
            <div className="col-span-2 space-y-1"><Label htmlFor="color">Cor</Label><Input id="color" value={formData.color} onChange={e => setFormData({...formData, color: e.target.value})} /></div>
            <div className="col-span-2 space-y-1"><Label htmlFor="observations">Observações</Label><Textarea id="observations" value={formData.observations} onChange={e => setFormData({...formData, observations: e.target.value})} /></div>
            <div className="col-span-2 space-y-1">
              <Label htmlFor="photo">Foto do Veículo</Label>
              <Input id="photo" type="file" onChange={handlePhotoChange} accept="image/*" />
              {photoPreview ? (
                <img src={photoPreview} alt="Pré-visualização do veículo" className="mt-2 rounded-lg max-h-40 object-cover w-full" />
              ) : (
                <div className="mt-2 rounded-lg h-40 w-full bg-gray-100 flex items-center justify-center">
                    <Car className="w-16 h-16 text-gray-300"/>
                </div>
              )}
            </div>
          </div>
        </form>
        <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" form="vehicle-form" disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default VeiculoDialog;
