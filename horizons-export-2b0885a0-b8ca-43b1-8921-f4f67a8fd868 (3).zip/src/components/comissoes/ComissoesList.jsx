
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MoreHorizontal, FileText, CheckCircle } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';
import ComissaoDialog from './ComissaoDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const statusMap = {
  paid: { label: 'Pago', color: 'bg-green-500' },
  pending: { label: 'Pendente', color: 'bg-yellow-500' },
};

const ComissoesList = ({ dateRange }) => {
  const { toast } = useToast();
  const [commissions, setCommissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCommission, setSelectedCommission] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  
  const fetchData = useCallback(async () => {
    if (!dateRange.from || !dateRange.to) return;
    setLoading(true);
    try {
      const from = format(dateRange.from, 'yyyy-MM-dd');
      const to = format(dateRange.to, 'yyyy-MM-dd');
      
      const { data, error } = await supabase.rpc('get_commissions_summary', { period_start: from, period_end: to });
      if (error) throw error;
      setCommissions(data);
    } catch (error) {
      toast({ title: "Erro ao carregar lista de comissões", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [dateRange, toast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleViewDetails = (commission) => {
    setSelectedCommission(commission);
    setIsDetailOpen(true);
  };
  
  const handleConfirmPayment = (commission) => {
    setSelectedCommission(commission);
    setIsConfirmOpen(true);
  };

  const handleMarkAsPaid = async () => {
    if(!selectedCommission) return;

    try {
      const from = format(dateRange.from, 'yyyy-MM-dd');
      const to = format(dateRange.to, 'yyyy-MM-dd');

      const { error } = await supabase.from('commissions')
        .update({ status: 'paid', paid_at: new Date().toISOString() })
        .eq('collaborator_id', selectedCommission.collaborator_id)
        .eq('calculation_period_start', from)
        .eq('calculation_period_end', to)
        .eq('status', 'pending');

      if (error) throw error;
      
      toast({ title: "Sucesso!", description: `Comissão para ${selectedCommission.collaborator_name} marcada como paga.` });
      fetchData();
      setIsConfirmOpen(false);
      setSelectedCommission(null);

    } catch (error) {
       toast({ title: 'Erro ao marcar como pago', description: error.message, variant: 'destructive' });
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mt-4">
      <h3 className="text-lg font-semibold text-gray-700 mb-4">Comissões por Mecânico</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-500">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3">Mecânico</th>
              <th scope="col" className="px-6 py-3">Comissão M.O.</th>
              <th scope="col" className="px-6 py-3">Comissão Peças</th>
              <th scope="col" className="px-6 py-3">Total</th>
              <th scope="col" className="px-6 py-3">Status</th>
              <th scope="col" className="px-6 py-3">Data Pagamento</th>
              <th scope="col" className="px-6 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan="7" className="text-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div></td></tr>
            ) : commissions.length > 0 ? (
              commissions.map(c => (
                <tr key={`${c.collaborator_id}-${c.status}`} className="bg-white border-b hover:bg-gray-50">
                  <td className="px-6 py-4 font-medium text-gray-900">{c.collaborator_name}</td>
                  <td className="px-6 py-4">{formatCurrency(c.mo_commission)}</td>
                  <td className="px-6 py-4">{formatCurrency(c.parts_commission)}</td>
                  <td className="px-6 py-4 font-semibold">{formatCurrency(c.total_commission)}</td>
                  <td className="px-6 py-4"><Badge className={`${statusMap[c.status]?.color} text-white capitalize`}>{statusMap[c.status]?.label}</Badge></td>
                   <td className="px-6 py-4">{c.paid_at ? format(new Date(c.paid_at), 'dd/MM/yyyy HH:mm') : 'N/A'}</td>
                  <td className="px-6 py-4 text-right">
                     <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="w-5 h-5" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => handleViewDetails(c)}><FileText className="w-4 h-4 mr-2" /> Ver Detalhes</DropdownMenuItem>
                        {c.status === 'pending' && <DropdownMenuItem onClick={() => handleConfirmPayment(c)}><CheckCircle className="w-4 h-4 mr-2 text-green-600" /> Marcar como Pago</DropdownMenuItem>}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan="7" className="text-center py-12 text-gray-500">Nenhuma comissão encontrada para este período. Tente calcular na aba "Dashboard".</td></tr>
            )}
          </tbody>
        </table>
      </div>
      {isDetailOpen && <ComissaoDialog isOpen={isDetailOpen} onClose={() => setIsDetailOpen(false)} commissionData={selectedCommission} dateRange={dateRange} />}
      
      <AlertDialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Pagamento</AlertDialogTitle>
            <AlertDialogDescription>
              Você confirma o pagamento de <span className="font-bold">{formatCurrency(selectedCommission?.total_commission)}</span> para <span className="font-bold">{selectedCommission?.collaborator_name}</span>? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleMarkAsPaid} className="bg-green-600 hover:bg-green-700">Confirmar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ComissoesList;
