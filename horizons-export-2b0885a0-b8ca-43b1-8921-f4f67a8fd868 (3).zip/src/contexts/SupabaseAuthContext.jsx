
import React, { createContext, useState, useEffect, useContext, useMemo, useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();
  const [session, setSession] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const storedSession = localStorage.getItem('session');
      if (storedSession) {
        const parsedSession = JSON.parse(storedSession);
        setSession(parsedSession);
        setUser(parsedSession.user);
      }
    } catch (error) {
      console.error("Failed to parse session from localStorage", error);
      localStorage.removeItem('session');
    } finally {
      setLoading(false);
    }
  }, []);

  const signIn = useCallback((email, password) => {
    // This is a mock sign-in for local development
    if (email === 'demo@example.com' && password === 'demo123') {
      const mockSession = {
        user: { id: 'local-user-id', email: 'demo@example.com', role: 'admin' },
        token: 'local-demo-token',
        expires_at: Date.now() / 1000 + 3600, // Expires in 1 hour
      };
      
      localStorage.setItem('session', JSON.stringify(mockSession));
      setSession(mockSession);
      setUser(mockSession.user);
      
      toast({
        title: 'Login bem-sucedido!',
        description: 'Redirecionando para o dashboard.',
      });
      return { error: null };
    } else {
      const error = { message: 'Credenciais inválidas. Use demo@example.com e demo123.' };
      toast({
        variant: 'destructive',
        title: 'Erro de Login',
        description: error.message,
      });
      return { error };
    }
  }, [toast]);

  const signOut = useCallback(() => {
    localStorage.removeItem('session');
    setSession(null);
    setUser(null);
    toast({
      title: 'Sign out bem-sucedido',
    });
    return { error: null };
  }, [toast]);
  
  // Mock signUp for compatibility
  const signUp = useCallback(async () => {
     toast({
        variant: "default",
        title: "Funcionalidade não implementada",
        description: "🚧 O cadastro de usuários está desabilitado no modo local.",
      });
    return { error: { message: 'Not implemented in local auth mode.' } };
  }, [toast]);

  const value = useMemo(() => ({
    user,
    session,
    loading,
    signIn,
    signOut,
    signUp, // Keep for compatibility
  }), [user, session, loading, signIn, signOut, signUp]);

  // Render children only when not in the initial loading state.
  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
