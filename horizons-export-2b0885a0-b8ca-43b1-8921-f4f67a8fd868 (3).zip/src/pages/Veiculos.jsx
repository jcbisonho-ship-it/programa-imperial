
import React from 'react';
import VehicleRegistration from '@/components/dashboard/VehicleRegistration';

const Veiculos = () => {
  return (
    <VehicleRegistration />
  );
};

export default Veiculos;
