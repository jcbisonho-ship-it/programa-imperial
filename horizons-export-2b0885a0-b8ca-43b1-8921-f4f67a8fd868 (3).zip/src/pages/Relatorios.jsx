
import React from 'react';
import Reports from '@/components/dashboard/Reports';

const Relatorios = () => {
  return (
    <Reports />
  );
};

export default Relatorios;
