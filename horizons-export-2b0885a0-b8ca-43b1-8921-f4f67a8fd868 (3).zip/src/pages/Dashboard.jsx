
import React, { useState } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { endOfToday, startOfToday, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';
import KPICards from '@/components/dashboard/KPICards';
import PeriodFilter from '@/components/dashboard/PeriodFilter';
import Charts from '@/components/dashboard/Charts';
import QuickActions from '@/components/dashboard/QuickActions';
import RecentActivities from '@/components/dashboard/RecentActivities';

const Dashboard = () => {
  const { user } = useAuth();
  const [dateRange, setDateRange] = useState({ from: startOfToday(), to: endOfToday() });

  const presets = [
    { label: 'Hoje', range: { from: startOfToday(), to: endOfToday() } },
    { label: 'Esta Semana', range: { from: startOfWeek(new Date(), { weekStartsOn: 1 }), to: endOfWeek(new Date(), { weekStartsOn: 1 }) } },
    { label: 'Este Mês', range: { from: startOfMonth(new Date()), to: endOfMonth(new Date()) } },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Seja bem-vindo, {user?.user_metadata?.full_name?.split(' ')[0] || 'Admin'}!</h1>
            <p className="text-muted-foreground">Aqui está um resumo da sua oficina.</p>
        </div>
        <PeriodFilter dateRange={dateRange} setDateRange={setDateRange} presets={presets} />
      </div>

      <KPICards dateRange={dateRange} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Charts dateRange={dateRange} />
        </div>
        <div className="space-y-6">
          <QuickActions />
          <RecentActivities />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
