
import React from 'react';
import CommissionTracking from '@/components/dashboard/CommissionTracking';

const Comissoes = () => {
  return (
    <CommissionTracking />
  );
};

export default Comissoes;
