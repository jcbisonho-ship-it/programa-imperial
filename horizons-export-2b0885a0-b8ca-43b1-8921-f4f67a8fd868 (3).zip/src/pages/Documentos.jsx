
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DocumentosList from '@/components/documentos/DocumentosList';
import TemplateCustomizer from '@/components/documentos/TemplateCustomizer';

const Documentos = () => {
    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-bold text-gray-800">Documentos</h2>
                <p className="text-gray-600">Gerencie, visualize e personalize os documentos gerados pelo sistema.</p>
            </div>
            <Tabs defaultValue="history" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="history">Histórico de Documentos</TabsTrigger>
                    <TabsTrigger value="templates">Personalizar Templates</TabsTrigger>
                </TabsList>
                <TabsContent value="history">
                    <DocumentosList />
                </TabsContent>
                <TabsContent value="templates">
                    <TemplateCustomizer />
                </TabsContent>
            </Tabs>
        </div>
    );
};

export default Documentos;
