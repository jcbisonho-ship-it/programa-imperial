
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useDebounce } from '@/hooks/useDebounce';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { PlusCircle, Search, MoreHorizontal, Edit, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import TransacaoDialog from './TransacaoDialog';
import { format } from 'date-fns';

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const statusMap = {
  paid: { label: 'Pago', color: 'bg-green-500' },
  pending: { label: 'Pendente', color: 'bg-yellow-500' },
};
const typeMap = {
    income: { label: 'Entrada', color: 'text-green-600' },
    expense: { label: 'Saída', color: 'text-red-600' },
};

const TransacoesList = () => {
  const { toast } = useToast();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({ page: 0, pageSize: 15, total: 0 });

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const fetchTransactions = useCallback(async () => {
    setLoading(true);
    const { page, pageSize } = pagination;
    const from = page * pageSize;
    const to = from + pageSize - 1;

    let query = supabase.from('transactions')
        .select('*, account:accounts(name), category:financial_categories(name)', { count: 'exact' });

    if (debouncedSearchTerm) {
      query = query.ilike('description', `%${debouncedSearchTerm}%`);
    }

    query = query.order('transaction_date', { ascending: false }).range(from, to);

    const { data, error, count } = await query;
    
    if (error) {
      toast({ title: 'Erro ao carregar transações', description: error.message, variant: 'destructive' });
    } else {
      setTransactions(data);
      setPagination(prev => ({ ...prev, total: count }));
    }
    setLoading(false);
  }, [pagination.page, pagination.pageSize, debouncedSearchTerm, toast]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  const openDialog = (transaction = null) => {
    setSelectedTransaction(transaction);
    setIsDialogOpen(true);
  };
  
  const openDeleteDialog = (transaction) => {
    setSelectedTransaction(transaction);
    setIsDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedTransaction) return;
    const { error } = await supabase.from('transactions').delete().eq('id', selectedTransaction.id);
    if (error) {
      toast({ title: 'Erro ao deletar transação', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Transação deletada com sucesso!' });
      fetchTransactions();
    }
    setIsDeleteDialogOpen(false);
  };

  const totalPages = Math.ceil(pagination.total / pagination.pageSize);

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mt-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input placeholder="Buscar por descrição..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
        </div>
        <Button onClick={() => openDialog()} className="bg-blue-600 hover:bg-blue-700">
          <PlusCircle className="w-4 h-4 mr-2" /> Nova Transação
        </Button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-500">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3">Data</th>
              <th scope="col" className="px-6 py-3">Descrição</th>
              <th scope="col" className="px-6 py-3">Tipo</th>
              <th scope="col" className="px-6 py-3">Valor</th>
              <th scope="col" className="px-6 py-3 hidden md:table-cell">Conta</th>
              <th scope="col" className="px-6 py-3">Status</th>
              <th scope="col" className="px-6 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan="7" className="text-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div></td></tr>
            ) : transactions.length > 0 ? (
              transactions.map(t => (
                <tr key={t.id} className="bg-white border-b hover:bg-gray-50">
                  <td className="px-6 py-4">{format(new Date(t.transaction_date), 'dd/MM/yyyy')}</td>
                  <td className="px-6 py-4 font-medium text-gray-900">{t.description}</td>
                  <td className={`px-6 py-4 font-semibold ${typeMap[t.type]?.color}`}>{typeMap[t.type]?.label}</td>
                  <td className={`px-6 py-4 font-semibold ${typeMap[t.type]?.color}`}>{formatCurrency(t.amount)}</td>
                  <td className="px-6 py-4 hidden md:table-cell">{t.account?.name}</td>
                  <td className="px-6 py-4"><Badge className={`${statusMap[t.status]?.color} text-white`}>{statusMap[t.status]?.label}</Badge></td>
                  <td className="px-6 py-4 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="w-5 h-5" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => openDialog(t)}><Edit className="w-4 h-4 mr-2" /> Editar</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => openDeleteDialog(t)}><Trash2 className="w-4 h-4 mr-2" /> Excluir</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan="7" className="text-center py-12 text-gray-500">Nenhuma transação encontrada.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between pt-4">
        <span className="text-sm text-gray-700">Página {pagination.page + 1} de {totalPages || 1}</span>
        <div className="flex gap-2">
          <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))} disabled={pagination.page === 0}>Anterior</Button>
          <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))} disabled={pagination.page >= totalPages - 1}>Próximo</Button>
        </div>
      </div>
      {isDialogOpen && <TransacaoDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} onSaveSuccess={fetchTransactions} transaction={selectedTransaction} />}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle><AlertDialogDescription>Tem certeza que deseja excluir esta transação? Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default TransacoesList;
