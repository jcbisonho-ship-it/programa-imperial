
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Download, History } from 'lucide-react';
import { format } from 'date-fns';

const ConfigBackup = () => {
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);
    const [backups, setBackups] = useState([]);

    const fetchBackups = useCallback(async () => {
        setLoading(true);
        const { data, error } = await supabase.from('backups').select('*, user:users(email)').order('created_at', { ascending: false });
        if (error) {
            toast({ title: 'Erro ao buscar histórico', description: error.message, variant: 'destructive' });
        } else {
            setBackups(data);
        }
        setLoading(false);
    }, [toast]);

    useEffect(() => {
        fetchBackups();
    }, [fetchBackups]);

    const handleTriggerBackup = () => {
        toast({ title: 'Funcionalidade em desenvolvimento', description: 'A geração de backup manual será implementada em breve.' });
    };
    
    const handleRestore = () => {
        toast({ title: 'Funcionalidade em desenvolvimento', description: 'A restauração de backup é uma operação crítica e será implementada em uma futura versão segura.' });
    };

    return (
        <div className="bg-white rounded-xl shadow-lg p-6 space-y-6">
            <div>
                <h3 className="text-lg font-semibold">Backup e Restauração</h3>
                <p className="text-sm text-gray-500">Gerencie os backups dos dados da sua aplicação.</p>
            </div>
            <div className="flex gap-4">
                <Button onClick={handleTriggerBackup}>Gerar Backup Manual</Button>
                <Button variant="destructive" onClick={handleRestore}>Restaurar Backup</Button>
            </div>
            <div>
                <h4 className="text-md font-semibold flex items-center gap-2"><History className="w-5 h-5" /> Histórico de Backups</h4>
                <div className="mt-4 border rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-4 py-2 text-left">Data</th>
                                <th className="px-4 py-2 text-left">Status</th>
                                <th className="px-4 py-2 text-left">Iniciado por</th>
                                <th className="px-4 py-2 text-right">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? <tr><td colSpan="4" className="text-center p-4">Carregando...</td></tr> :
                            backups.map(backup => (
                                <tr key={backup.id} className="border-t">
                                    <td className="px-4 py-2">{format(new Date(backup.created_at), 'dd/MM/yyyy HH:mm')}</td>
                                    <td className="px-4 py-2">{backup.status}</td>
                                    <td className="px-4 py-2">{backup.user?.email || 'Automático'}</td>
                                    <td className="px-4 py-2 text-right">
                                        <Button variant="ghost" size="icon" disabled={!backup.file_url}>
                                            <Download className="w-4 h-4" />
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default ConfigBackup;
