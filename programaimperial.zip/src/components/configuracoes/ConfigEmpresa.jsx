
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Camera } from 'lucide-react';

const ConfigEmpresa = () => {
    const { toast } = useToast();
    const [loading, setLoading] = useState(true);
    const [template, setTemplate] = useState({
        company_logo_url: '',
        company_info: { name: '', cnpj: '', address: '', phone: '', email: '', website: '' },
    });
    const fileInputRef = useRef(null);

    useEffect(() => {
        const fetchTemplate = async () => {
            setLoading(true);
            const { data, error } = await supabase.from('document_templates').select('*').eq('id', 1).single();
            if (data) {
                setTemplate(prev => ({ ...prev, ...data }));
            } else if (error && error.code !== 'PGRST116') {
                toast({ title: 'Erro ao carregar dados da empresa', description: error.message, variant: 'destructive' });
            }
            setLoading(false);
        };
        fetchTemplate();
    }, [toast]);

    const handleInfoChange = (e) => {
        const { id, value } = e.target;
        setTemplate(prev => ({ ...prev, company_info: { ...prev.company_info, [id]: value } }));
    };

    const handleLogoUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        setLoading(true);
        const filePath = `public/logo-${Date.now()}`;
        const { error: uploadError } = await supabase.storage.from('documents').upload(filePath, file, { upsert: true });
        
        if (uploadError) {
            toast({ title: 'Erro no upload', description: uploadError.message, variant: 'destructive' });
            setLoading(false);
            return;
        }

        const { data: urlData } = supabase.storage.from('documents').getPublicUrl(filePath);
        setTemplate(prev => ({ ...prev, company_logo_url: urlData.publicUrl }));
        setLoading(false);
        toast({ title: 'Logo carregado com sucesso!' });
    };

    const handleSave = async () => {
        setLoading(true);
        const { company_logo_url, company_info } = template;
        const { error } = await supabase.from('document_templates').update({ company_logo_url, company_info }).eq('id', 1);
        if (error) {
            toast({ title: 'Erro ao salvar', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Dados da empresa salvos com sucesso!' });
        }
        setLoading(false);
    };

    return (
        <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Dados da Empresa</h3>
            {loading ? <p>Carregando...</p> : (
                <div className="space-y-6">
                    <div className="flex items-center gap-4">
                        <img src={template.company_logo_url || 'https://via.placeholder.com/100'} alt="Logo" className="w-24 h-24 object-contain border rounded-md" />
                        <Button type="button" onClick={() => fileInputRef.current.click()}>
                            <Camera className="w-4 h-4 mr-2" /> Alterar Logo
                        </Button>
                        <Input type="file" ref={fileInputRef} onChange={handleLogoUpload} accept="image/*" className="hidden" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><Label>Nome da Empresa</Label><Input id="name" value={template.company_info.name || ''} onChange={handleInfoChange} /></div>
                        <div><Label>CNPJ</Label><Input id="cnpj" value={template.company_info.cnpj || ''} onChange={handleInfoChange} /></div>
                        <div><Label>Endereço</Label><Input id="address" value={template.company_info.address || ''} onChange={handleInfoChange} /></div>
                        <div><Label>Telefone</Label><Input id="phone" value={template.company_info.phone || ''} onChange={handleInfoChange} /></div>
                        <div><Label>Email</Label><Input id="email" value={template.company_info.email || ''} onChange={handleInfoChange} /></div>
                        <div><Label>Website</Label><Input id="website" value={template.company_info.website || ''} onChange={handleInfoChange} /></div>
                    </div>
                    <div className="flex justify-end">
                        <Button onClick={handleSave} disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ConfigEmpresa;
