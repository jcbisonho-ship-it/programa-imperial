
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { List, CheckSquare, Camera, History } from 'lucide-react';

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const statusMap = {
  in_progress: { label: 'Em Andamento', color: 'bg-blue-500' },
  completed: { label: 'Finalizada', color: 'bg-green-500' },
  delivered: { label: 'Entregue', color: 'bg-purple-500' },
  canceled: { label: 'Cancelada', color: 'bg-red-500' },
};

const OSViewer = ({ isOpen, onClose, orderId }) => {
  const [order, setOrder] = useState(null);
  const [items, setItems] = useState([]);
  const [checklists, setChecklists] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchData = useCallback(async () => {
    if (!orderId) return;
    setLoading(true);
    try {
      const [orderRes, itemsRes, checklistsRes, photosRes, historyRes] = await Promise.all([
        supabase.rpc('get_work_order_summary').eq('id', orderId).single(),
        supabase.from('work_order_items').select('*').eq('work_order_id', orderId),
        supabase.from('work_order_checklists').select('*').eq('work_order_id', orderId),
        supabase.from('work_order_photos').select('*').eq('work_order_id', orderId),
        supabase.from('audit_log').select('*, user:users_data(full_name)').or(`details->>orderId.eq.${orderId}`).order('created_at', { ascending: false }),
      ]);

      if (orderRes.error) throw orderRes.error;
      setOrder(orderRes.data);
      setItems(itemsRes.data || []);
      setChecklists(checklistsRes.data || []);
      setPhotos(photosRes.data || []);
      setHistory(historyRes.data || []);

    } catch (error) {
      toast({ title: 'Erro ao carregar dados da OS', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [orderId, toast]);

  useEffect(() => {
    if (isOpen) fetchData();
  }, [isOpen, fetchData]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Detalhes da Ordem de Serviço</DialogTitle>
          {order && <DialogDescription>OS #{order.id.substring(0, 8)}</DialogDescription>}
        </DialogHeader>
        {loading ? (
          <div className="flex justify-center items-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>
        ) : order ? (
          <div className="flex-grow overflow-y-auto pr-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm p-4 bg-gray-50 rounded-lg">
              <div><p className="font-semibold">Cliente:</p><p>{order.customer_name}</p></div>
              <div><p className="font-semibold">Veículo:</p><p>{order.vehicle_model} ({order.vehicle_plate})</p></div>
              <div><p className="font-semibold">Data:</p><p>{format(new Date(order.order_date), 'dd/MM/yyyy')}</p></div>
              <div><p className="font-semibold">Status:</p><Badge className={`${statusMap[order.status]?.color || 'bg-gray-400'} text-white`}>{statusMap[order.status]?.label || 'Desconhecido'}</Badge></div>
              <div><p className="font-semibold">Técnico:</p><p>{order.technician_name || 'N/A'}</p></div>
              <div><p className="font-semibold">Total:</p><p className="text-lg font-bold">{formatCurrency(order.total_cost)}</p></div>
            </div>

            <Tabs defaultValue="items">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="items"><List className="w-4 h-4 mr-2"/>Itens</TabsTrigger>
                <TabsTrigger value="checklist"><CheckSquare className="w-4 h-4 mr-2"/>Checklist</TabsTrigger>
                <TabsTrigger value="photos"><Camera className="w-4 h-4 mr-2"/>Fotos</TabsTrigger>
                <TabsTrigger value="history"><History className="w-4 h-4 mr-2"/>Histórico</TabsTrigger>
              </TabsList>
              <TabsContent value="items" className="pt-4">
                <div className="border rounded-lg"><table className="w-full text-sm">
                  <thead className="bg-gray-50"><tr><th className="p-2 text-left">Descrição</th><th className="p-2">Qtd.</th><th className="p-2">Preço Unit.</th><th className="p-2 text-right">Total</th></tr></thead>
                  <tbody>{items.map(item => (<tr key={item.id} className="border-t"><td className="p-2">{item.description}</td><td className="p-2">{item.quantity}</td><td className="p-2">{formatCurrency(item.unit_price)}</td><td className="p-2 text-right">{formatCurrency(item.total_price)}</td></tr>))}</tbody>
                </table></div>
              </TabsContent>
              <TabsContent value="checklist" className="pt-4 space-y-2">
                {checklists.map(c => <div key={c.id} className="flex items-center gap-2 text-sm"><Badge variant={c.is_completed ? 'default' : 'outline'}>{c.is_completed ? 'Feito' : 'Pendente'}</Badge><span>{c.task}</span></div>)}
              </TabsContent>
              <TabsContent value="photos" className="pt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {photos.map(p => <a key={p.id} href={p.photo_url} target="_blank" rel="noreferrer" className="relative group"><img src={p.photo_url} className="w-full h-32 object-cover rounded-lg" alt={p.photo_type}/><div className="absolute bottom-0 left-0 bg-black/50 text-white text-xs w-full p-1 rounded-b-lg capitalize">{p.photo_type}</div></a>)}
              </TabsContent>
              <TabsContent value="history" className="pt-4 space-y-3">
                {history.map(h => (<div key={h.id} className="text-xs p-3 bg-gray-50 rounded-md border"><p className="font-semibold capitalize">{h.action.replace(/_/g, ' ')}</p><p className="text-gray-500">Por {h.user?.full_name || 'Sistema'} em {format(new Date(h.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</p></div>))}
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <p className="text-center text-gray-500 py-10">Não foi possível carregar os dados da OS.</p>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default OSViewer;
