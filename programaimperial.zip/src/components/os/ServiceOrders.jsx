
import React, { useState, useEffect, useCallback } from 'react';
import { useDebounce } from '@/hooks/useDebounce';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, MoreVertical, FileDown, MessageSquare, Printer, XCircle, FileText } from 'lucide-react'; // Added FileText icon
import { useAuth } from '@/contexts/SupabaseAuthContext';
import ServiceOrderDialog from '@/components/os/ServiceOrderDialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import OSViewer from '@/components/os/OSViewer'; // Import OSViewer to display details

const ServiceOrders = ({ setActiveTab }) => {
  const [serviceOrders, setServiceOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false); // Renamed for clarity
  const [isViewerOpen, setIsViewerOpen] = useState(false); // State for the viewer
  const [selectedOrderForView, setSelectedOrderForView] = useState(null); // State for the order to view
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  const { toast } = useToast();
  const { user } = useAuth();
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const loadServiceOrders = useCallback(async () => {
    setLoading(true);
    try {
      let query = supabase.rpc('get_work_order_summary');
      
      if (debouncedSearchTerm) {
        query = query.or(`customer_name.ilike.%${debouncedSearchTerm}%,vehicle_plate.ilike.%${debouncedSearchTerm}%,title.ilike.%${debouncedSearchTerm}%`);
      }
      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data, error } = await query.order('order_date', { ascending: false });

      if (error) throw error;
      setServiceOrders(data || []);
    } catch (error) {
      toast({ title: "Erro ao carregar Ordens de Serviço", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast, debouncedSearchTerm, statusFilter]);
  
  useEffect(() => {
    loadServiceOrders();
  }, [loadServiceOrders]);

  const handleCancelOrder = async (orderId) => {
    try {
        const { data, error } = await supabase.rpc('revert_work_order_to_budget', { p_work_order_id: orderId });
        if(error) throw error;
        toast({ title: "Ordem de Serviço Cancelada", description: `A OS foi revertida para o orçamento #${data.substring(0,5)}.` });
        if (setActiveTab) setActiveTab('orcamentos');
        loadServiceOrders();
    } catch (error) {
        toast({ title: "Erro ao cancelar OS", description: error.message, variant: "destructive" });
    }
  };

  const showNotImplementedToast = () => {
    toast({ title: "🚧 Recurso em desenvolvimento", description: "Esta funcionalidade ainda não foi implementada." });
  };

  // getStatusChip is no longer needed if status is not displayed in this view.
  // Keeping it as a placeholder for now, but it can be removed if not used elsewhere.
  const getStatusChip = (status) => {
    const styles = {
      in_progress: 'bg-blue-100 text-blue-800 border-blue-200',
      completed: 'bg-green-100 text-green-800 border-green-200',
      canceled: 'bg-red-100 text-red-800 border-red-200',
      delivered: 'bg-purple-100 text-purple-800 border-purple-200', // Added delivered status
    };
    return `px-2 py-0.5 text-xs font-medium rounded-full border ${styles[status] || 'bg-gray-100 text-gray-800'}`;
  };

  const openServiceOrderViewer = (order) => {
    setSelectedOrderForView(order);
    setIsViewerOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Ordens de Serviço</h2>
          <p className="text-gray-600">Gerencie todas as ordens de serviço da oficina.</p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)} className="bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900">
          <Search className="w-4 h-4 mr-2" /> Nova Ordem de Serviço
        </Button> {/* Changed icon from Plus to Search as per ServiceOrders.jsx current structure for consistency and for adding a new OS */}
      </div>

      <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="relative md:col-span-2">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input placeholder="Buscar por cliente, placa ou título da OS..." className="pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger><SelectValue placeholder="Filtrar por status..." /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todos os Status</SelectItem>
                    <SelectItem value="in_progress">Em Andamento</SelectItem>
                    <SelectItem value="completed">Concluída</SelectItem>
                    <SelectItem value="delivered">Entregue</SelectItem>
                    <SelectItem value="canceled">Cancelada</SelectItem>
                </SelectContent>
            </Select>
        </div>
        
        <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>OS</TableHead>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Veículo</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead className="text-right">Valor</TableHead>
                        <TableHead className="text-center">Ações</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {loading ? (
                        <TableRow><TableCell colSpan="6" className="text-center py-10">Carregando...</TableCell></TableRow>
                    ) : serviceOrders.length === 0 ? (
                        <TableRow><TableCell colSpan="6" className="text-center py-10"><FileText className="w-12 h-12 text-gray-300 mx-auto mb-2" /><p>Nenhuma ordem de serviço encontrada.</p></TableCell></TableRow>
                    ) : (
                        serviceOrders.map(order => (
                            <TableRow key={order.id}>
                                <TableCell className="font-medium">
                                    <div className="flex flex-col">
                                        {/* Removed the '#' symbol from the title */}
                                        <span>{order.title.replace('#', '')}</span>
                                        {/* Removed the status display as requested */}
                                    </div>
                                </TableCell>
                                <TableCell>{order.customer_name}</TableCell>
                                <TableCell>{`${order.vehicle_model} (${order.vehicle_plate})`}</TableCell>
                                <TableCell>{new Date(order.order_date).toLocaleDateString('pt-BR')}</TableCell>
                                <TableCell className="text-right font-bold">R$ {Number(order.total_cost).toFixed(2)}</TableCell>
                                <TableCell className="text-center">
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" size="icon"><MoreVertical className="w-5 h-5" /></Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                            <DropdownMenuItem onClick={() => openServiceOrderViewer(order)}>
                                                Visualizar Detalhes
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={showNotImplementedToast}>
                                                <FileDown className="w-4 h-4 mr-2" /> Salvar como PDF
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={showNotImplementedToast}>
                                                <MessageSquare className="w-4 h-4 mr-2" /> Enviar via WhatsApp
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={showNotImplementedToast}>
                                                <Printer className="w-4 h-4 mr-2" /> Imprimir
                                            </DropdownMenuItem>
                                            <DropdownMenuItem className="text-red-600" onClick={() => handleCancelOrder(order.id)}>
                                                <XCircle className="w-4 h-4 mr-2" /> Cancelar OS
                                            </DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))
                    )}
                </TableBody>
            </Table>
        </div>
      </div>

      {isCreateDialogOpen && (
        <ServiceOrderDialog
          isOpen={isCreateDialogOpen}
          onClose={() => { setIsCreateDialogOpen(false); }}
          onSaveSuccess={loadServiceOrders}
          serviceOrder={null} // Ensure it's for creation
          user={user}
        />
      )}

      {isViewerOpen && (
        <OSViewer
          isOpen={isViewerOpen}
          onClose={() => { setIsViewerOpen(false); setSelectedOrderForView(null); }}
          orderId={selectedOrderForView?.id}
        />
      )}
    </div>
  );
};

export default ServiceOrders;
