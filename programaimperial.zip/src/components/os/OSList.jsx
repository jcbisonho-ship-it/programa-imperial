
import React, { useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuPortal, DropdownMenuSubTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Eye, CheckCircle, XCircle, Truck, Wrench, Circle, Trash2 } from 'lucide-react'; // Added Trash2 icon
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import OSViewer from '@/components/os/OSViewer';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { logAuditEvent } from '@/lib/audit';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const statusMap = {
  in_progress: { label: 'Em Andamento', color: 'bg-blue-500', icon: <Wrench className="w-3 h-3" /> },
  completed: { label: 'Finalizada', color: 'bg-green-500', icon: <CheckCircle className="w-3 h-3" /> },
  delivered: { label: 'Entregue', color: 'bg-purple-500', icon: <Truck className="w-3 h-3" /> },
  canceled: { label: 'Cancelada', color: 'bg-red-500', icon: <XCircle className="w-3 h-3" /> },
};

const OSList = ({ serviceOrders, loading, onRefresh }) => { // Removed onEdit prop
  const { toast } = useToast();
  const { user } = useAuth();
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);

  const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      const { error } = await supabase.from('work_orders').update({ status: newStatus }).eq('id', orderId);
      if (error) throw error;
      await logAuditEvent(user.id, 'update_os_status', { orderId, newStatus });
      toast({ title: 'Status atualizado com sucesso!' });
      onRefresh();
    } catch (error) {
      toast({ title: 'Erro ao atualizar status', description: error.message, variant: 'destructive' });
    }
  };

  const handleDelete = async () => {
    if (!selectedOrder) return;
    try {
      await supabase.rpc('delete_work_order_and_related', { p_work_order_id: selectedOrder.id });
      await logAuditEvent(user.id, 'delete_work_order', { orderId: selectedOrder.id });
      toast({ title: 'Ordem de Serviço removida com sucesso!' });
      onRefresh();
    } catch (error) {
      toast({ title: 'Erro ao remover Ordem de Serviço', description: error.message, variant: 'destructive' });
    } finally {
      setIsDeleteOpen(false);
      setSelectedOrder(null);
    }
  };

  const openViewer = (order) => {
    setSelectedOrder(order);
    setIsViewerOpen(true);
  };

  const openDeleteDialog = (order) => {
    setSelectedOrder(order);
    setIsDeleteOpen(true);
  };

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-500">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th scope="col" className="px-4 py-3">Cliente / Veículo</th>
              <th scope="col" className="px-4 py-3 hidden lg:table-cell">Data</th>
              <th scope="col" className="px-4 py-3 hidden md:table-cell">Técnico</th>
              <th scope="col" className="px-4 py-3 text-center">Total</th>
              <th scope="col" className="px-4 py-3 text-center">Status</th>
              <th scope="col" className="px-4 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i} className="bg-white border-b"><td colSpan="6" className="p-4"><div className="h-8 bg-gray-200 rounded animate-pulse"></div></td></tr>
              ))
            ) : serviceOrders.length > 0 ? (
              serviceOrders.map(order => (
                <tr key={order.id} className="bg-white border-b hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{order.customer_name}</p>
                    <p className="text-xs text-gray-600">{order.vehicle_model} ({order.vehicle_plate})</p>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">{format(new Date(order.order_date), "dd/MM/yyyy", { locale: ptBR })}</td>
                  <td className="px-4 py-3 hidden md:table-cell">{order.technician_name || 'N/A'}</td>
                  <td className="px-4 py-3 text-center font-medium">{formatCurrency(order.total_cost)}</td>
                  <td className="px-4 py-3 text-center">
                    <Badge className={`${statusMap[order.status]?.color || 'bg-gray-400'} text-white flex items-center justify-center gap-1`}>
                      {statusMap[order.status]?.icon}
                      {statusMap[order.status]?.label || 'Desconhecido'}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="w-4 h-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openViewer(order)}><Eye className="w-4 h-4 mr-2" /> Ver Detalhes</DropdownMenuItem>
                        {/* Removed Edit Option */}
                        <DropdownMenuSub>
                            <DropdownMenuSubTrigger>Mudar Status</DropdownMenuSubTrigger>
                            <DropdownMenuPortal>
                                <DropdownMenuSubContent>
                                    {Object.entries(statusMap).map(([key, {label}]) => (
                                        <DropdownMenuItem key={key} onClick={() => handleStatusChange(order.id, key)}>{label}</DropdownMenuItem>
                                    ))}
                                </DropdownMenuSubContent>
                            </DropdownMenuPortal>
                        </DropdownMenuSub>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600" onClick={() => openDeleteDialog(order)}><Trash2 className="w-4 h-4 mr-2" /> Excluir</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan="6" className="text-center py-12 text-gray-500">Nenhuma Ordem de Serviço encontrada.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      {isViewerOpen && <OSViewer isOpen={isViewerOpen} onClose={() => setIsViewerOpen(false)} orderId={selectedOrder?.id} />}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>Esta ação é irreversível e excluirá a OS, seus itens, checklists e fotos. O estoque não será estornado automaticamente se a OS já estiver em andamento.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive hover:bg-destructive/90" onClick={handleDelete}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default OSList;
