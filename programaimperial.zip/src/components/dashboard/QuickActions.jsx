
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Wrench, FileText, UserPlus } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

const actions = [
    { label: "Criar OS", icon: Wrench, action: "os" },
    { label: "Criar Orçamento", icon: FileText, action: "budget" },
    { label: "Cadastrar Cliente", icon: UserPlus, action: "customer" },
];

const ActionCard = ({ label, icon: Icon, action }) => {
    const { toast } = useToast();
    const handleNotImplemented = () => {
        toast({
            title: "🚧 Funcionalidade em construção!",
            description: `A ação rápida para "${label}" será implementada em breve.`,
        });
    }

    return (
        <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleNotImplemented}
        >
            <Card className="cursor-pointer hover:bg-accent transition-colors">
                <CardContent className="flex flex-col items-center justify-center p-4 sm:p-6 gap-2">
                    <Icon className="h-6 w-6 text-primary" />
                    <span className="text-sm font-medium text-center">{label}</span>
                </CardContent>
            </Card>
        </motion.div>
    );
};

const QuickActions = () => {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-3 gap-2 sm:gap-4">
            {actions.map(action => (
                <ActionCard key={action.action} {...action} />
            ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;
