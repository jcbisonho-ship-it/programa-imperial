
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Users, Car, FileText, Wrench, MoreHorizontal, Clock, CheckCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import QuickActions from '@/components/dashboard/QuickActions';
import Charts from '@/components/dashboard/Charts';
import { Button } from '@/components/ui/button';

const mockStats = {
  totalCustomers: 125,
  totalVehicles: 189,
  pendingBudgets: 12,
  inProgressOS: 8,
};

const mockRecentActivities = [
  { id: 'act1', type: 'os', description: 'Nova OS #a1b2c3 para João Silva', time: '2 min ago', status: 'pending' },
  { id: 'act2', type: 'customer', description: 'Novo cliente cadastrado: Maria Oliveira', time: '15 min ago', status: 'completed' },
  { id: 'act3', type: 'budget', description: 'Orçamento #d4e5f6 aprovado', time: '1 hour ago', status: 'completed' },
  { id: 'act4', type: 'vehicle', description: 'Novo veículo adicionado: Honda Civic (ABC1D23)', time: '3 hours ago', status: 'completed' },
  { id: 'act5', 'type': 'os', description: 'OS #g7h8i9 concluída', time: '5 hours ago', status: 'completed' },
  { id: 'act6', 'type': 'budget', description: 'Novo orçamento #j1k2l3 criado', time: '1 day ago', status: 'pending' },
];

const StatCard = ({ title, value, icon: Icon, description }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      <p className="text-xs text-muted-foreground">{description}</p>
    </CardContent>
  </Card>
);

const ActivityItem = ({ activity }) => {
  const ICONS = {
    os: Wrench,
    customer: Users,
    budget: FileText,
    vehicle: Car,
  };
  const Icon = ICONS[activity.type] || MoreHorizontal;

  return (
    <div className="flex items-center">
      <div className="w-8 h-8 bg-primary/10 text-primary flex items-center justify-center rounded-full mr-4">
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-grow">
        <p className="text-sm text-gray-800">{activity.description}</p>
        <p className="text-xs text-gray-500 flex items-center">
          {activity.status === 'pending' ? <Clock className="w-3 h-3 mr-1 text-yellow-500" /> : <CheckCircle className="w-3 h-3 mr-1 text-green-500" />}
          {activity.time}
        </p>
      </div>
      <Badge variant={activity.status === 'pending' ? 'warning' : 'success'} className="capitalize">
        {activity.status}
      </Badge>
    </div>
  );
};


const DashboardHome = () => {
  const [stats] = useState(mockStats);
  const [activities] = useState(mockRecentActivities);

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total de Clientes" value={stats.totalCustomers} icon={Users} description="+2 este mês" />
        <StatCard title="Total de Veículos" value={stats.totalVehicles} icon={Car} description="+5 este mês" />
        <StatCard title="Orçamentos Pendentes" value={stats.pendingBudgets} icon={FileText} description="Aguardando aprovação" />
        <StatCard title="OS em Andamento" value={stats.inProgressOS} icon={Wrench} description="Na oficina" />
      </div>
      
      <QuickActions />

      <div className="grid gap-6 md:grid-cols-5">
        <div className="md:col-span-3">
            <Charts />
        </div>
        <div className="md:col-span-2">
            <Card>
                <CardHeader>
                    <CardTitle>Atividade Recente</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    {activities.map(activity => (
                        <ActivityItem key={activity.id} activity={activity} />
                    ))}
                    <Button variant="outline" className="w-full">Ver todas as atividades</Button>
                </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
