
import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Wrench, DollarSign, Package, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

const KPICard = ({ title, value, icon: Icon, color, loading }) => {
  return (
    <motion.div 
      className="bg-white p-4 sm:p-6 rounded-lg shadow-sm flex items-center justify-between"
      whileHover={{ y: -5, boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.05)" }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <div>
        <p className="text-sm font-medium text-gray-500">{title}</p>
        {loading ? (
           <div className="h-8 w-24 bg-gray-200 rounded-md animate-pulse mt-1"></div>
        ) : (
          <p className="text-2xl md:text-3xl font-bold text-gray-800">{value}</p>
        )}
      </div>
      <div className={`p-3 rounded-full ${color}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
    </motion.div>
  );
};

const KPICards = ({ dateRange }) => {
  const [kpiData, setKpiData] = useState({
    pendingOS: 0,
    revenue: 0,
    lowStock: 0,
    profit: 0,
  });
  const [loading, setLoading] = useState(true);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);
  };
  
  const fetchKpiData = useCallback(async () => {
    setLoading(true);
    try {
      const from = dateRange.from.toISOString();
      const to = dateRange.to.toISOString();

      // 1. Pending OS
      const { count: pendingOS, error: osError } = await supabase
        .from('work_orders')
        .select('*', { count: 'exact', head: true })
        .in('status', ['in_progress', 'awaiting_payment', 'pending']);
      if(osError) throw osError;

      // 2. Period Revenue & Profit
      const { data: revenueData, error: rpcError } = await supabase.rpc('get_financial_report', { p_start_date: from, p_end_date: to });

      if (rpcError) throw rpcError;
      
      const totalRevenue = revenueData.revenue_trend.reduce((sum, day) => sum + day.revenue, 0);
      const totalProfit = revenueData.revenue_trend.reduce((sum, day) => sum + day.profit, 0);

      // 3. Low Stock Items
      const { data: products, error: stockError } = await supabase
        .from('products')
        .select('stock, min_stock');
      if(stockError) throw stockError;

      const lowStockCount = products.filter(p => p.min_stock !== null && p.stock <= p.min_stock).length;

      setKpiData({
        pendingOS: pendingOS || 0,
        revenue: totalRevenue,
        lowStock: lowStockCount,
        profit: totalProfit,
      });

    } catch (error) {
      console.error("Error fetching KPI data:", error);
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    fetchKpiData();
  }, [fetchKpiData]);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <KPICard title="OS Pendentes" value={kpiData.pendingOS} icon={Wrench} color="bg-orange-500" loading={loading} />
      <KPICard title="Receita (Período)" value={formatCurrency(kpiData.revenue)} icon={DollarSign} color="bg-green-500" loading={loading} />
      <KPICard title="Estoque Baixo" value={kpiData.lowStock} icon={Package} color="bg-red-500" loading={loading} />
      <KPICard title="Lucro (Período)" value={formatCurrency(kpiData.profit)} icon={TrendingUp} color="bg-blue-500" loading={loading} />
    </div>
  );
};

export default KPICards;
