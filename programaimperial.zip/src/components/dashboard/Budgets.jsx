
import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, Search, Check, X, FileText, RefreshCw, MoreVertical, FileDown, MessageSquare, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import BudgetDialog from '@/components/dialogs/BudgetDialog';
import { sendBudgetNotification } from '@/lib/whatsapp';
import { generateBudgetPDF } from '@/services/pdfService';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useDebounce } from '@/hooks/useDebounce';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const Budgets = ({ setActiveTab }) => {
  const [budgets, setBudgets] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const loadBudgets = useCallback(async () => {
    try {
      setLoading(true);
      let query = supabase.rpc('get_budget_summary');

      if (debouncedSearchTerm) {
        query = query.or(`customer_name.ilike.%${debouncedSearchTerm}%,vehicle_description.ilike.%${debouncedSearchTerm}%`);
      }
      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }
      
      // Do not show converted budgets in the list
      query = query.neq('status', 'converted');

      const { data, error } = await query.order('created_at', { ascending: false });
      
      if (error) throw error;
      setBudgets(data || []);
    } catch (error) {
      toast({ title: "Erro ao carregar orçamentos", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast, debouncedSearchTerm, statusFilter]);

  useEffect(() => {
    loadBudgets();
  }, [loadBudgets]);
  
  const handleDeleteBudget = async (id) => {
    try {
      const { error: itemsError } = await supabase.from('budget_items').delete().eq('budget_id', id);
      if (itemsError) throw itemsError;
      const { error: budgetError } = await supabase.from('budgets').delete().eq('id', id);
      if (budgetError) throw budgetError;
      loadBudgets();
      toast({ title: "Orçamento removido!", description: "O orçamento foi removido do sistema." });
    } catch (error) {
      toast({ title: "Erro ao remover orçamento", description: error.message, variant: "destructive" });
    }
  };
  
  const handleStatusChange = async (budget, newStatus) => {
    try {
      if (newStatus === 'approved') {
        await convertToWorkOrder(budget);
      } else {
        const { error } = await supabase.from('budgets').update({ status: newStatus }).eq('id', budget.id);
        if (error) throw error;
        toast({ title: `Status do orçamento atualizado!`, description: "O status foi atualizado." });
      }
      loadBudgets();
    } catch (error) {
      toast({ title: "Erro ao atualizar status", description: error.message, variant: "destructive" });
    }
  };

  const convertToWorkOrder = async (budget) => {
    const { data: budgetWithItems, error: budgetError } = await supabase
      .from('budgets')
      .select('*, budget_items(*)')
      .eq('id', budget.id)
      .single();
    
    if (budgetError || !budgetWithItems) {
      throw new Error(budgetError?.message || "Orçamento não encontrado.");
    }
    
    const { data: existingOS, error: existingOSError } = await supabase
      .from('work_orders')
      .select('id')
      .eq('title', `OS do Orçamento #${budget.id.substring(0, 5)}`);

    if (existingOSError) throw existingOSError;
    if (existingOS && existingOS.length > 0) {
      toast({ title: "OS já existe", description: "Uma OS para este orçamento já foi criada.", variant: "destructive" });
      return;
    }
    
    const { data: workOrder, error: osError } = await supabase.from('work_orders').insert({
        customer_id: budget.customer_id, vehicle_id: budget.vehicle_id,
        title: `OS do Orçamento #${budget.id.substring(0, 5)}`,
        description: `Serviços e peças conforme orçamento #${budget.id}. Status inicial: pendente.`,
        status: 'pending', order_date: new Date().toISOString().split('T')[0],
        km: budget.km,
    }).select().single();
    if (osError) throw osError;
    
    const itemsToInsert = (budgetWithItems.budget_items || []).map(item => {
        const { id, budget_id, created_at, ...rest } = item;
        return {
          ...rest,
          work_order_id: workOrder.id
        };
      });

    if (itemsToInsert.length > 0) {
      const { error: itemsError } = await supabase.from('work_order_items').insert(itemsToInsert);
      if (itemsError) {
          await supabase.from('work_orders').delete().eq('id', workOrder.id);
          throw itemsError;
      }
    }

    // Update budget status to 'converted'
    const { error: updateBudgetError } = await supabase
      .from('budgets')
      .update({ status: 'converted' }) // `converted_to_os_id` does not exist
      .eq('id', budget.id);

    if (updateBudgetError) {
        // Log this error, but the main action (OS creation) was successful
        console.error("Error updating budget status to converted:", updateBudgetError);
        toast({ title: "Aviso", description: "OS criada, mas houve um erro ao atualizar o status do orçamento.", variant: "default" });
    }
    
    toast({ title: "Ordem de Serviço Criada!", description: "O orçamento foi convertido em OS." });
    if(setActiveTab) setActiveTab('os');
  };

  const handleGeneratePdf = async (budgetId) => {
    try {
        const { data: budgetData, error } = await supabase.rpc('get_budget_summary', {id_param: budgetId}).single();
        if (error || !budgetData) throw error || new Error('Budget not found');
        const {data: itemsData, error: itemsError} = await supabase.from('budget_items').select('*').eq('budget_id', budgetId);
        if(itemsError) throw itemsError;

        budgetData.items = itemsData;
        
        const doc = await generateBudgetPDF(budgetData);
        doc.save(`orcamento_${budgetId.substring(0,8)}.pdf`);
        toast({ title: 'PDF gerado com sucesso!' });
    } catch(err) {
        toast({ title: 'Erro ao gerar PDF', description: err.message, variant: 'destructive' });
    }
  };

  const getStatusChip = (status) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      approved: 'bg-green-100 text-green-800 border-green-200',
      rejected: 'bg-red-100 text-red-800 border-red-200',
    };
    return `px-2 py-0.5 text-xs font-medium rounded-full border ${styles[status] || 'bg-gray-100 text-gray-800'}`;
  };

  return (
    <div className="space-y-6 relative h-full">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Orçamentos</h2>
          <p className="text-gray-600">Crie e gerencie os orçamentos para seus clientes.</p>
        </div>
        <Button onClick={() => { setEditingBudget(null); setIsDialogOpen(true); }}><Plus className="w-4 h-4 mr-2" /> Novo Orçamento</Button>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="relative md:col-span-2">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input placeholder="Buscar por cliente ou veículo..." className="pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger><SelectValue placeholder="Filtrar por status..." /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todos os Status</SelectItem>
                    <SelectItem value="pending">Pendente</SelectItem>
                    <SelectItem value="approved">Aprovado</SelectItem>
                    <SelectItem value="rejected">Rejeitado</SelectItem>
                </SelectContent>
            </Select>
        </div>

        <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Orçamento</TableHead>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Veículo</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead className="text-right">Valor</TableHead>
                        <TableHead className="text-center">Ações</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {loading ? (
                        <TableRow><TableCell colSpan={6} className="text-center py-10">Carregando...</TableCell></TableRow>
                    ) : budgets.length === 0 ? (
                        <TableRow><TableCell colSpan={6} className="text-center py-10"><FileText className="w-12 h-12 text-gray-300 mx-auto mb-2" /><p>Nenhum orçamento encontrado.</p></TableCell></TableRow>
                    ) : (
                        budgets.map((budget) => (
                            <TableRow key={budget.id}>
                                <TableCell className="font-medium">
                                    <div className="flex flex-col">
                                        <span>#{budget.id.substring(0, 5)}</span>
                                        <span className={getStatusChip(budget.status)}>{budget.status}</span>
                                    </div>
                                </TableCell>
                                <TableCell>{budget.customer_name}</TableCell>
                                <TableCell>{budget.vehicle_description}</TableCell>
                                <TableCell>{new Date(budget.created_at).toLocaleDateString('pt-BR')}</TableCell>
                                <TableCell className="text-right font-bold">R$ {Number(budget.total_cost).toFixed(2)}</TableCell>
                                <TableCell className="text-center">
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreVertical className="w-5 h-5" /></Button></DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                            <DropdownMenuItem onClick={() => { setEditingBudget(budget); setIsDialogOpen(true); }}><Edit className="w-4 h-4 mr-2"/>Visualizar/Editar</DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => handleGeneratePdf(budget.id)}><FileDown className="w-4 h-4 mr-2"/>Gerar PDF</DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => sendBudgetNotification(budget.id, budget.status)}><MessageSquare className="w-4 h-4 mr-2"/>Enviar WhatsApp</DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => toast({ title: "🚧 Recurso em desenvolvimento" })}><Printer className="w-4 h-4 mr-2"/>Imprimir</DropdownMenuItem>
                                            <DropdownMenuSeparator />
                                            {budget.status === 'pending' && <>
                                                <DropdownMenuItem onClick={() => handleStatusChange(budget, 'approved')}><Check className="w-4 h-4 mr-2 text-green-600"/>Aprovar e Converter em OS</DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleStatusChange(budget, 'rejected')}><X className="w-4 h-4 mr-2 text-red-600"/>Rejeitar</DropdownMenuItem>
                                            </>}
                                            {budget.status === 'rejected' && <DropdownMenuItem onClick={() => handleStatusChange(budget, 'pending')}><RefreshCw className="w-4 h-4 mr-2"/>Reabrir</DropdownMenuItem>}
                                            {budget.status === 'approved' && <DropdownMenuItem onClick={() => convertToWorkOrder(budget)}><RefreshCw className="w-4 h-4 mr-2"/>Converter em OS</DropdownMenuItem>}
                                            <DropdownMenuSeparator />
                                            <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteBudget(budget.id)}><Trash2 className="w-4 h-4 mr-2"/>Excluir</DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))
                    )}
                </TableBody>
            </Table>
        </div>
      </div>

      {isDialogOpen && <BudgetDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} onSave={loadBudgets} budget={editingBudget} user={user} />}
    </div>
  );
};

export default Budgets;
