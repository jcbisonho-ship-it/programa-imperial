
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

const MechanicDialog = ({ isOpen, onClose, onSave, mechanic }) => {
  const [formData, setFormData] = useState({
    name: '',
    cpf: '',
    rg: '',
    phone: '',
    email: '',
    specialty: '',
    hourly_rate: '',
  });

  useEffect(() => {
    if (mechanic) {
      setFormData({
        name: mechanic.name || '',
        cpf: mechanic.cpf || '',
        rg: mechanic.rg || '',
        phone: mechanic.phone || '',
        email: mechanic.email || '',
        specialty: mechanic.specialty || '',
        hourly_rate: mechanic.hourly_rate || '',
      });
    } else {
      setFormData({
        name: '', cpf: '', rg: '', phone: '', email: '', specialty: '', hourly_rate: '',
      });
    }
  }, [mechanic, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mechanic ? 'Editar Mecânico' : 'Novo Mecânico'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="name">Nome Completo *</Label>
              <Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required />
            </div>
            <div>
              <Label htmlFor="cpf">CPF *</Label>
              <Input id="cpf" value={formData.cpf} onChange={(e) => setFormData({ ...formData, cpf: e.target.value })} required />
            </div>
            <div>
              <Label htmlFor="rg">RG</Label>
              <Input id="rg" value={formData.rg} onChange={(e) => setFormData({ ...formData, rg: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="phone">Telefone</Label>
              <Input id="phone" type="tel" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input id="email" type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} required />
            </div>
            <div>
              <Label htmlFor="specialty">Especialidade</Label>
              <Input id="specialty" value={formData.specialty} onChange={(e) => setFormData({ ...formData, specialty: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="hourly_rate">Valor por Hora</Label>
              <Input id="hourly_rate" type="number" step="0.01" placeholder="Deixe em branco se não aplicável" value={formData.hourly_rate} onChange={(e) => setFormData({ ...formData, hourly_rate: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit">{mechanic ? 'Atualizar' : 'Cadastrar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default MechanicDialog;
