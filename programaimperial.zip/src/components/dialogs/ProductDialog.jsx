
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

const ProductDialog = ({ isOpen, onClose, onSave, product }) => {
  const getInitialFormData = () => ({
    name: '',
    sku: '',
    cost_price: '',
    sale_price: '',
    stock: '',
    min_stock: '',
  });
  
  const [formData, setFormData] = useState(getInitialFormData());

  useEffect(() => {
    if (isOpen) {
        if (product) {
            setFormData({
                name: product.name || '',
                sku: product.sku || '',
                cost_price: product.cost_price || '',
                sale_price: product.sale_price || '',
                stock: product.stock || '',
                min_stock: product.min_stock || '',
            });
        } else {
            setFormData(getInitialFormData());
        }
    }
  }, [product, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };
  
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{product ? 'Editar Produto' : 'Novo Produto'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="name">Nome do Produto *</Label>
              <Input id="name" value={formData.name} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="sku">SKU (Código)</Label>
              <Input id="sku" value={formData.sku} onChange={handleChange} />
            </div>
            <div>
              <Label htmlFor="stock">Estoque Atual *</Label>
              <Input id="stock" type="number" value={formData.stock} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="cost_price">Preço de Custo *</Label>
              <Input id="cost_price" type="number" step="0.01" value={formData.cost_price} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="sale_price">Preço de Venda *</Label>
              <Input id="sale_price" type="number" step="0.01" value={formData.sale_price} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="min_stock">Estoque Mínimo</Label>
              <Input id="min_stock" type="number" value={formData.min_stock} onChange={handleChange} />
            </div>
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit">{product ? 'Atualizar' : 'Cadastrar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ProductDialog;
