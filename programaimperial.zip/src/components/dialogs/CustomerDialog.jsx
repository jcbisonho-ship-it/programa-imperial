
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { logAudit } from '@/lib/audit';

const CustomerDialog = ({ isOpen, onClose, onSaveSuccess, customer }) => {
  const [formData, setFormData] = useState({ name: '', cpf: '', phone: '', email: '', observations: '', cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '' });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    if (customer) {
      setFormData({
        name: customer.name || '', cpf: customer.cpf || '', phone: customer.phone || '', email: customer.email || '', observations: customer.observations || '', cep: customer.cep || '', street: customer.street || '', number: customer.number || '', complement: customer.complement || '', neighborhood: customer.neighborhood || '', city: customer.city || '', state: customer.state || ''
      });
    } else {
      setFormData({ name: '', cpf: '', phone: '', email: '', observations: '', cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '' });
    }
  }, [customer, isOpen]);

  const validateCPF = async (cpf) => {
    const { data, error } = await supabase.from('customers').select('id').eq('cpf', cpf).neq('id', customer?.id || '00000000-0000-0000-0000-000000000000');
    if (error) {
      toast({ title: 'Erro ao validar CPF', description: error.message, variant: 'destructive' });
      return false;
    }
    if (data.length > 0) {
      toast({ title: 'CPF já cadastrado', description: 'Este CPF já pertence a outro cliente.', variant: 'destructive' });
      return false;
    }
    return true;
  };

  const handleCepLookup = useCallback(async () => {
    const cep = formData.cep.replace(/\D/g, '');
    if (cep.length !== 8) return;
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      if (data.erro) { toast({ title: 'CEP não encontrado', variant: 'destructive' }); return; }
      setFormData(prev => ({ ...prev, street: data.logradouro, neighborhood: data.bairro, city: data.localidade, state: data.uf }));
      toast({ title: 'Endereço preenchido!' });
    } catch (error) { toast({ title: 'Erro ao buscar CEP', description: error.message, variant: 'destructive' }); }
  }, [formData.cep, toast]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (!(await validateCPF(formData.cpf))) {
      setLoading(false);
      return;
    }
    
    try {
      if (customer) {
        const { data, error } = await supabase.from('customers').update(formData).eq('id', customer.id).select().single();
        if (error) throw error;
        await logAudit(user.id, 'update_customer', { customerId: data.id, changes: formData });
        toast({ title: 'Cliente atualizado com sucesso!' });
      } else {
        const { data, error } = await supabase.from('customers').insert(formData).select().single();
        if (error) throw error;
        await logAudit(user.id, 'create_customer', { customerId: data.id, name: data.name });
        toast({ title: 'Cliente cadastrado com sucesso!' });
      }
      onSaveSuccess();
      onClose();
    } catch (error) {
      toast({ title: 'Erro ao salvar cliente', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{customer ? 'Editar Cliente' : 'Novo Cliente'}</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1"><Label htmlFor="name">Nome Completo *</Label><Input id="name" required value={formData.name} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="cpf">CPF *</Label><Input id="cpf" required value={formData.cpf} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="phone">Telefone *</Label><Input id="phone" type="tel" required value={formData.phone} onChange={handleChange} /></div>
            <div className="space-y-1"><Label htmlFor="email">Email</Label><Input id="email" type="email" value={formData.email} onChange={handleChange} /></div>
            <div className="md:col-span-2 space-y-1"><Label htmlFor="observations">Observações</Label><Textarea id="observations" value={formData.observations} onChange={handleChange} /></div>
          </div>
          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-medium text-gray-800">Endereço</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1"><Label htmlFor="cep">CEP</Label>
                <div className="flex gap-2"><Input id="cep" value={formData.cep} onChange={handleChange} /><Button type="button" variant="outline" onClick={handleCepLookup}>Buscar</Button></div>
              </div>
              <div className="md:col-span-2 space-y-1"><Label htmlFor="street">Rua</Label><Input id="street" value={formData.street} onChange={handleChange} /></div>
              <div className="space-y-1"><Label htmlFor="number">Número</Label><Input id="number" value={formData.number} onChange={handleChange} /></div>
              <div className="space-y-1"><Label htmlFor="neighborhood">Bairro</Label><Input id="neighborhood" value={formData.neighborhood} onChange={handleChange} /></div>
              <div className="space-y-1"><Label htmlFor="city">Cidade</Label><Input id="city" value={formData.city} onChange={handleChange} /></div>
            </div>
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CustomerDialog;
