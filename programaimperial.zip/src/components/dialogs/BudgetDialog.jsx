
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/customSupabaseClient';
import { PlusCircle, Trash2, Search } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const BudgetDialog = ({ isOpen, onClose, onSave, budget }) => {
  const emptyForm = {
    customer_id: '',
    vehicle_id: '',
    customer_name: '',
    vehicle_description: '',
    status: 'pending',
    km: '',
  };
  const [formData, setFormData] = useState(emptyForm);
  const [items, setItems] = useState([]);
  const [plate, setPlate] = useState('');
  const [products, setProducts] = useState([]);
  const [collaborators, setCollaborators] = useState([]);
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);

  const loadInitialData = useCallback(async () => {
    const { data: productsData } = await supabase.from('products').select('*').order('name');
    setProducts(productsData || []);
    const { data: collaboratorsData } = await supabase.from('collaborators').select('id, name').order('name');
    setCollaborators(collaboratorsData || []);
  }, []);

  const loadBudgetItems = useCallback(async (budgetId) => {
    if (!budgetId) {
      setItems([]);
      return;
    }
    const { data, error } = await supabase
      .from('budget_items')
      .select('*')
      .eq('budget_id', budgetId);

    if (error) {
      toast({ title: 'Erro ao carregar itens do orçamento', description: error.message, variant: 'destructive' });
      setItems([]);
    } else {
      setItems(data || []);
    }
  }, [toast]);

  useEffect(() => {
    if (isOpen) {
      loadInitialData();
      if (budget) {
        setFormData({
          id: budget.id,
          customer_id: budget.customer_id || '',
          vehicle_id: budget.vehicle_id || '',
          customer_name: budget.customer_name || '',
          vehicle_description: budget.vehicle_description || '',
          status: budget.status || 'pending',
          km: budget.km || '',
        });
        if (budget.vehicle_id) {
          supabase.from('vehicles').select('plate').eq('id', budget.vehicle_id).single().then(({ data }) => setPlate(data?.plate || ''));
        }
        loadBudgetItems(budget.id);
      } else {
        setFormData(emptyForm);
        setItems([]);
        setPlate('');
      }
    }
  }, [budget, isOpen, loadInitialData, loadBudgetItems]);

  const handlePlateLookup = async () => {
    if (!plate) return;
    const { data, error } = await supabase.rpc('get_vehicle_summary').eq('plate', plate.toUpperCase()).single();

    if (error || !data) {
      toast({ title: "Veículo não encontrado", description: "Verifique a placa ou cadastre o veículo primeiro.", variant: "destructive" });
      setFormData(prev => ({ ...prev, vehicle_id: '', customer_id: '', customer_name: '', vehicle_description: '' }));
      return;
    }

    const vehicle = data;
    setFormData(prev => ({
      ...prev,
      customer_id: vehicle.customer_id,
      vehicle_id: vehicle.id,
      customer_name: vehicle.customer_name,
      vehicle_description: `${vehicle.brand} ${vehicle.model} (${vehicle.year})`,
    }));
    toast({ title: "Veículo encontrado!" });
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...items];
    const currentItem = { ...newItems[index] };
    currentItem[field] = value;

    if (field === 'product_id' && currentItem.item_type === 'product') {
        const product = products.find(p => p.id === value);
        if (product) {
            currentItem.description = product.name;
            currentItem.unit_price = product.sale_price;
            currentItem.cost_price = product.cost_price;
        }
    }

    if (field === 'quantity' || field === 'unit_price') {
      currentItem.total_price = (Number(currentItem.quantity) || 0) * (Number(currentItem.unit_price) || 0);
    }
    
    newItems[index] = currentItem;
    setItems(newItems);
  };
  
  const addItem = (itemType) => {
    const newItem = {
      id: `new-${Date.now()}-${Math.random()}`,
      budget_id: formData.id || null,
      item_type: itemType,
      description: '',
      quantity: 1,
      unit_price: 0,
      cost_price: 0,
      total_price: 0,
      product_id: null,
      collaborator_id: null,
    };
    setItems([...items, newItem]);
  };

  const removeItem = (index) => setItems(items.filter((_, i) => i !== index));

  const calculateTotal = () => items.reduce((acc, item) => acc + (Number(item.total_price) || 0), 0);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.vehicle_id) {
      toast({ title: 'Veículo não selecionado', description: 'Por favor, busque e selecione um veículo válido.', variant: 'destructive' });
      return;
    }
    
    setIsSaving(true);
    const total_cost = calculateTotal();
    
    let budgetResponse;
    const dbPayload = {
      customer_id: formData.customer_id,
      vehicle_id: formData.vehicle_id,
      status: formData.status,
      total_cost: total_cost,
      customer_name: formData.customer_name,
      vehicle_description: formData.vehicle_description,
      km: formData.km ? parseInt(formData.km, 10) : null,
    };
    
    if (formData.id) {
      budgetResponse = await supabase.from('budgets').update(dbPayload).eq('id', formData.id).select().single();
    } else {
      budgetResponse = await supabase.from('budgets').insert(dbPayload).select().single();
    }
    
    if (budgetResponse.error) {
      toast({ title: 'Erro ao salvar orçamento', description: budgetResponse.error.message, variant: 'destructive' });
      setIsSaving(false);
      return;
    }
    
    const budgetId = budgetResponse.data.id;
    
    const itemsToUpsert = items.map(item => {
      const { id, total_price, ...rest } = item;
      const isNew = typeof id === 'string' && id.startsWith('new-');
      const itemPayload = {
          ...rest,
          budget_id: budgetId,
      };
      if (!isNew) {
        itemPayload.id = id;
      }
      return itemPayload;
    });

    const { data: existingItems } = await supabase.from('budget_items').select('id').eq('budget_id', budgetId);
    const existingItemIds = existingItems?.map(i => i.id) || [];
    const currentItemIds = itemsToUpsert.map(i => i.id).filter(id => !(typeof id === 'string' && id.startsWith('new-')));
    const itemsToDelete = existingItemIds.filter(id => !currentItemIds.includes(id));
    
    if (itemsToDelete.length > 0) {
      await supabase.from('budget_items').delete().in('id', itemsToDelete);
    }
    
    if (itemsToUpsert.length > 0) {
      const { error: itemsError } = await supabase.from('budget_items').upsert(itemsToUpsert);
      if (itemsError) {
        toast({ title: 'Erro ao salvar itens', description: itemsError.message, variant: 'destructive' });
        setIsSaving(false);
        return;
      }
    }
    
    onSave();
    onClose();
    toast({ title: `Orçamento ${formData.id ? 'atualizado' : 'criado'}!`, description: "A operação foi concluída com sucesso." });
    setIsSaving(false);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{budget ? 'Editar Orçamento' : 'Novo Orçamento'}</DialogTitle>
          <DialogDescription>Preencha os dados para criar ou editar um orçamento.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 flex-grow overflow-hidden flex flex-col">
          <div className="flex-shrink-0 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="plate">Placa do Veículo</Label>
                    <div className="flex gap-2">
                        <Input id="plate" value={plate} onChange={e => setPlate(e.target.value.toUpperCase())} placeholder="ABC1234" />
                        <Button type="button" onClick={handlePlateLookup}><Search className="w-4 h-4 mr-2" /> Buscar</Button>
                    </div>
                </div>
                <div>
                    <Label htmlFor="km">KM</Label>
                    <Input id="km" type="number" placeholder="Ex: 50000" value={formData.km} onChange={e => setFormData({...formData, km: e.target.value})} />
                </div>
            </div>

            {formData.vehicle_id && (
              <div className="mt-2 p-3 bg-blue-50 rounded-lg border border-blue-200 text-sm">
                <p><strong>Cliente:</strong> {formData.customer_name}</p>
                <p><strong>Veículo:</strong> {formData.vehicle_description}</p>
              </div>
            )}
          </div>
          
          <div className="space-y-2 flex-grow overflow-y-auto pr-3">
            <Label>Itens e Serviços</Label>
            {items.map((item, index) => (
              <div key={item.id} className="grid grid-cols-[1fr,1fr,90px,120px,auto] items-center gap-2">
                {item.item_type === 'product' ? (
                  <Select value={item.product_id || ''} onValueChange={v => handleItemChange(index, 'product_id', v)}>
                    <SelectTrigger><SelectValue placeholder="Selecione um produto..." /></SelectTrigger>
                    <SelectContent>{products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                  </Select>
                ) : (
                  <Input placeholder="Descrição do serviço" value={item.description} onChange={e => handleItemChange(index, 'description', e.target.value)} />
                )}
                <Select value={item.collaborator_id || ''} onValueChange={v => handleItemChange(index, 'collaborator_id', v)}>
                    <SelectTrigger><SelectValue placeholder="Mecânico..." /></SelectTrigger>
                    <SelectContent>{collaborators.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
                <Input type="number" placeholder="Qtd" value={item.quantity} onChange={e => handleItemChange(index, 'quantity', e.target.value)} className="w-full" min="1" />
                <Input type="number" placeholder="Preço" value={item.unit_price} onChange={e => handleItemChange(index, 'unit_price', e.target.value)} className="w-full" step="0.01" />
                <Button type="button" size="icon" variant="ghost" onClick={() => removeItem(index)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
              </div>
            ))}
            <div className="flex gap-2">
              <Button type="button" size="sm" variant="outline" onClick={() => addItem('product')}><PlusCircle className="w-4 h-4 mr-2" /> Adicionar Peça</Button>
              <Button type="button" size="sm" variant="outline" onClick={() => addItem('service')}><PlusCircle className="w-4 h-4 mr-2" /> Adicionar Serviço</Button>
            </div>
          </div>
          
          <div className="pt-4 border-t flex-shrink-0">
            <div className="text-right font-bold text-xl">Total: R$ {calculateTotal().toFixed(2)}</div>
          </div>
          
          <DialogFooter className="flex-shrink-0">
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={!formData.vehicle_id || isSaving}>
              {isSaving ? 'Salvando...' : 'Salvar Orçamento'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default BudgetDialog;
