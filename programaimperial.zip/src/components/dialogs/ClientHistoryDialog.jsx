
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Car, Activity, DollarSign } from 'lucide-react';
import VehicleHistoryDialog from './VehicleHistoryDialog';
import { Badge } from '../ui/badge';
import { Button } from '@/components/ui/button';

const ClientHistoryDialog = ({ isOpen, onClose, customer }) => {
  const [vehicles, setVehicles] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [isVehicleHistoryOpen, setIsVehicleHistoryOpen] = useState(false);
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    if (!customer) return;
    setLoading(true);
    try {
      const [vehiclesRes, auditRes] = await Promise.all([
        supabase.from('get_vehicle_summary').select('*').eq('customer_id', customer.id),
        supabase.from('audit_log').select('*').or(`details->>customerId.eq.${customer.id},details->>customer_id.eq.${customer.id}`).order('created_at', { ascending: false })
      ]);
      if (vehiclesRes.error) throw vehiclesRes.error;
      if (auditRes.error) throw auditRes.error;

      setVehicles(vehiclesRes.data || []);
      setAuditLogs(auditRes.data || []);
    } catch (error) {
      toast({ title: 'Erro ao carregar dados do cliente', description: error.message, variant: 'destructive' });
    } finally { setLoading(false); }
  }, [customer, toast]);

  useEffect(() => {
    if (isOpen) loadData();
  }, [isOpen, loadData]);

  const openVehicleHistory = (vehicle) => {
    setSelectedVehicle(vehicle);
    setIsVehicleHistoryOpen(true);
  };
  
  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Histórico do Cliente: {customer?.name}</DialogTitle>
            <DialogDescription>Visualize veículos, ordens de serviço e atividades.</DialogDescription>
          </DialogHeader>
          {loading ? (
             <div className="flex justify-center items-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>
          ) : (
            <Tabs defaultValue="vehicles" className="w-full mt-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="vehicles"><Car className="w-4 h-4 mr-2" />Veículos ({vehicles.length})</TabsTrigger>
                <TabsTrigger value="activity"><Activity className="w-4 h-4 mr-2" />Atividade do Cliente</TabsTrigger>
              </TabsList>
              <TabsContent value="vehicles" className="pt-4">
                <div className="space-y-4">
                  {vehicles.map(vehicle => (
                    <div key={vehicle.id} className="border rounded-lg p-4 flex items-center justify-between hover:bg-gray-50">
                      <div className="flex items-center gap-4">
                        {vehicle.photo_url ? (
                            <img src={vehicle.photo_url} alt={`Foto de ${vehicle.model}`} className="w-16 h-16 object-cover rounded-md"/>
                        ) : (
                            <div className="w-16 h-16 bg-gray-100 rounded-md flex items-center justify-center">
                                <Car className="w-8 h-8 text-gray-400"/>
                            </div>
                        )}
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">{vehicle.brand} {vehicle.model} ({vehicle.year})</h4>
                            <Badge variant="secondary">{vehicle.plate}</Badge>
                          </div>
                          <p className="text-sm text-gray-500">{vehicle.color}</p>
                          {vehicle.has_pending_os && <Badge variant="warning" className="mt-2">OS Pendente</Badge>}
                        </div>
                      </div>
                      <Button onClick={() => openVehicleHistory(vehicle)} size="sm">Ver Histórico</Button>
                    </div>
                  ))}
                  {vehicles.length === 0 && <p className="text-center text-gray-500 py-8">Nenhum veículo cadastrado.</p>}
                </div>
              </TabsContent>
              <TabsContent value="activity" className="pt-4">
                <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-2">
                  {auditLogs.map(log => (
                    <div key={log.id} className="text-xs p-3 bg-gray-50 rounded-md border">
                      <p className="font-semibold capitalize">{log.action.replace(/_/g, ' ')}</p>
                      <p className="text-gray-500">
                        Em {new Date(log.created_at).toLocaleString('pt-BR')}
                      </p>
                    </div>
                  ))}
                  {auditLogs.length === 0 && <p className="text-center text-gray-500 py-8">Nenhuma atividade registrada.</p>}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
      {isVehicleHistoryOpen && <VehicleHistoryDialog isOpen={isVehicleHistoryOpen} onClose={() => setIsVehicleHistoryOpen(false)} vehicle={selectedVehicle} customer={customer}/>}
    </>
  );
};

export default ClientHistoryDialog;
