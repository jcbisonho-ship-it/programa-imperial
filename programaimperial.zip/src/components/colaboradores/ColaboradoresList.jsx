
import React, { useState, useEffect, useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { useDebounce } from '@/hooks/useDebounce';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { PlusCircle, MoreHorizontal, Edit, Trash2, BarChart2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import ColaboradorDialog from './ColaboradorDialog';
import ColaboradorDashboard from './ColaboradorDashboard';
import { v4 as uuidv4 } from 'uuid';

const sampleCollaborators = [
    { id: 'c1', name: 'Roberto Carlos', cpf: '123.456.789-01', phone: '(11) 91111-1111', commission_mo_pct: 10, commission_parts_pct: 5, status: 'ativo', completed_os_count: 15, total_profit: 7500.00 },
    { id: 'c2', name: 'Fernanda Lima', cpf: '987.654.321-02', phone: '(21) 92222-2222', commission_mo_pct: 12, commission_parts_pct: 3, status: 'ativo', completed_os_count: 25, total_profit: 12500.00 },
    { id: 'c3', name: 'Marcos Andrade', cpf: '456.789.123-03', phone: '(31) 93333-3333', commission_mo_pct: 8, commission_parts_pct: 2, status: 'inativo', completed_os_count: 5, total_profit: 2500.00 },
];

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const statusMap = {
  ativo: { label: 'Ativo', variant: 'success' },
  inativo: { label: 'Inativo', variant: 'destructive' },
};

const ColaboradoresList = () => {
  const { toast } = useToast();
  const [allCollaborators, setAllCollaborators] = useState(sampleCollaborators);
  const [filteredCollaborators, setFilteredCollaborators] = useState(sampleCollaborators);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({ page: 0, pageSize: 10 });

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const [selectedCollaborator, setSelectedCollaborator] = useState(null);
  const [dialogMode, setDialogMode] = useState('create');

  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const filterAndPaginateCollaborators = useCallback(() => {
    setLoading(true);
    let filtered = allCollaborators;
    if (debouncedSearchTerm) {
        filtered = allCollaborators.filter(c =>
            c.name.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
            (c.cpf && c.cpf.includes(debouncedSearchTerm))
        );
    }
    
    const { page, pageSize } = pagination;
    const start = page * pageSize;
    const end = start + pageSize;

    setFilteredCollaborators(filtered.slice(start, end));
    setLoading(false);
  }, [allCollaborators, debouncedSearchTerm, pagination]);

  useEffect(() => {
    filterAndPaginateCollaborators();
  }, [filterAndPaginateCollaborators]);
  
  const handleSaveCollaborator = (collaboratorData) => {
    if (dialogMode === 'edit' && selectedCollaborator) {
      setAllCollaborators(prev => prev.map(c => c.id === selectedCollaborator.id ? { ...c, ...collaboratorData } : c));
      toast({ title: 'Colaborador atualizado com sucesso!' });
    } else {
      const newCollaborator = {
        ...collaboratorData,
        id: uuidv4(),
        completed_os_count: 0,
        total_profit: 0,
      };
      setAllCollaborators(prev => [newCollaborator, ...prev]);
      toast({ title: 'Colaborador criado com sucesso!' });
    }
    setIsDialogOpen(false);
    setSelectedCollaborator(null);
  };

  const openDialog = (mode, collaborator = null) => {
    setDialogMode(mode);
    setSelectedCollaborator(collaborator);
    setIsDialogOpen(true);
  };

  const openDashboard = (collaborator) => {
    setSelectedCollaborator(collaborator);
    setIsDashboardOpen(true);
  };

  const openDeleteDialog = (collaborator) => {
    setSelectedCollaborator(collaborator);
    setIsDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedCollaborator) return;
    setAllCollaborators(prev => prev.filter(c => c.id !== selectedCollaborator.id));
    toast({ title: 'Colaborador deletado com sucesso!' });
    setIsDeleteDialogOpen(false);
  };

  const totalPages = Math.ceil(allCollaborators.filter(c => debouncedSearchTerm ? (c.name.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) || (c.cpf && c.cpf.includes(debouncedSearchTerm))) : true).length / pagination.pageSize);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Colaboradores</h1>
        <Button onClick={() => openDialog('create')}>
          <PlusCircle className="w-4 h-4 mr-2" /> Novo Colaborador
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow p-4">
        <div className="mb-4">
          <Input placeholder="Buscar por nome ou CPF..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Comissão</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">OS Concluídas</TableHead>
              <TableHead className="hidden md:table-cell">Lucro Gerado</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan="6" className="text-center">Carregando...</TableCell></TableRow>
            ) : filteredCollaborators.length > 0 ? (
              filteredCollaborators.map(col => {
                const statusInfo = statusMap[col.status] || { label: col.status, variant: 'secondary' };
                return (
                  <TableRow key={col.id}>
                    <TableCell>{col.name}</TableCell>
                    <TableCell>{`MO: ${col.commission_mo_pct || 0}% / Peças: ${col.commission_parts_pct || 0}%`}</TableCell>
                    <TableCell><Badge variant={statusInfo.variant} className="capitalize">{statusInfo.label}</Badge></TableCell>
                    <TableCell className="hidden sm:table-cell">{col.completed_os_count}</TableCell>
                    <TableCell className="hidden md:table-cell">{formatCurrency(col.total_profit)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="w-4 h-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openDashboard(col)}><BarChart2 className="w-4 h-4 mr-2" /> Dashboard</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openDialog('edit', col)}><Edit className="w-4 h-4 mr-2" /> Editar</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600" onClick={() => openDeleteDialog(col)}><Trash2 className="w-4 h-4 mr-2" /> Excluir</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })
            ) : (
              <TableRow><TableCell colSpan="6" className="text-center">Nenhum colaborador encontrado.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
        <div className="flex items-center justify-between pt-4">
          <span className="text-sm text-muted-foreground">Página {pagination.page + 1} de {totalPages || 1}</span>
          <div className="flex gap-2">
            <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))} disabled={pagination.page === 0}>Anterior</Button>
            <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))} disabled={pagination.page >= totalPages - 1}>Próximo</Button>
          </div>
        </div>
      </div>

      {isDialogOpen && <ColaboradorDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} onSaveSuccess={handleSaveCollaborator} collaborator={selectedCollaborator} mode={dialogMode} />}
      {isDashboardOpen && <ColaboradorDashboard isOpen={isDashboardOpen} onClose={() => setIsDashboardOpen(false)} collaboratorId={selectedCollaborator?.id} />}

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle><AlertDialogDescription>Tem certeza que deseja excluir este colaborador? Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete}>Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ColaboradoresList;
