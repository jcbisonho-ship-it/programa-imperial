
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const ColaboradorDialog = ({ isOpen, onClose, onSaveSuccess, collaborator, mode }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const getInitialState = () => ({
    name: '', cpf: '', phone: '', email: '',
    commission_mo_pct: '', commission_parts_pct: '',
    observations: '', status: 'ativo'
  });
  const [formData, setFormData] = useState(getInitialState());
  const [cpfError, setCpfError] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (mode === 'edit' && collaborator) {
        setFormData({
          name: collaborator.name || '',
          cpf: collaborator.cpf || '',
          phone: collaborator.phone || '',
          email: collaborator.email || '',
          commission_mo_pct: collaborator.commission_mo_pct || '',
          commission_parts_pct: collaborator.commission_parts_pct || '',
          observations: collaborator.observations || '',
          status: collaborator.status || 'ativo',
        });
      } else {
        setFormData(getInitialState());
      }
      setCpfError('');
    }
  }, [collaborator, isOpen, mode]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    if (id === 'cpf') setCpfError('');
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id, value) => {
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const validateCPF = async (cpf) => {
    if (!cpf) return true;
    let query = supabase.from('collaborators').select('id').eq('cpf', cpf);
    if (collaborator?.id) {
      query = query.not('id', 'eq', collaborator.id);
    }
    const { data, error } = await query;
    if (error) {
      toast({ title: "Erro de Validação", description: "Não foi possível validar o CPF.", variant: "destructive" });
      return false;
    }
    if (data.length > 0) {
      setCpfError("Este CPF já está cadastrado.");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (!(await validateCPF(formData.cpf))) {
      setLoading(false);
      return;
    }

    const payload = {
      ...formData,
      commission_mo_pct: formData.commission_mo_pct ? parseFloat(formData.commission_mo_pct) : null,
      commission_parts_pct: formData.commission_parts_pct ? parseFloat(formData.commission_parts_pct) : null,
    };

    try {
      let result;
      if (mode === 'edit') {
        result = await supabase.from('collaborators').update(payload).eq('id', collaborator.id);
      } else {
        result = await supabase.from('collaborators').insert(payload);
      }
      if (result.error) throw result.error;
      toast({ title: `Colaborador ${mode === 'edit' ? 'atualizado' : 'criado'} com sucesso!` });
      onSaveSuccess();
      onClose();
    } catch (error) {
      toast({ title: 'Erro ao salvar colaborador', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{mode === 'edit' ? 'Editar' : 'Novo'} Colaborador</DialogTitle>
          <DialogDescription>Preencha os dados do colaborador.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto space-y-4 pr-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label htmlFor="name">Nome Completo *</Label><Input id="name" value={formData.name} onChange={handleChange} required /></div>
            <div><Label htmlFor="email">Email</Label><Input id="email" type="email" value={formData.email} onChange={handleChange} /></div>
            <div>
                <Label htmlFor="cpf">CPF</Label>
                <Input id="cpf" value={formData.cpf} onChange={handleChange} />
                {cpfError && <p className="text-red-500 text-xs mt-1">{cpfError}</p>}
            </div>
            <div><Label htmlFor="phone">Telefone</Label><Input id="phone" type="tel" value={formData.phone} onChange={handleChange} /></div>
            <div>
              <Label htmlFor="commission_mo_pct">Comissão M.O. (%)</Label>
              <Input id="commission_mo_pct" type="number" step="0.1" min="0" max="20" value={formData.commission_mo_pct} onChange={handleChange} placeholder="0-20" />
            </div>
            <div>
              <Label htmlFor="commission_parts_pct">Comissão Peças (%)</Label>
              <Input id="commission_parts_pct" type="number" step="0.1" min="0" max="20" value={formData.commission_parts_pct} onChange={handleChange} placeholder="0-20" />
            </div>
            <div className="md:col-span-2"><Label htmlFor="observations">Observações</Label><Textarea id="observations" value={formData.observations} onChange={handleChange} /></div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(v) => handleSelectChange('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="pt-4 border-t mt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? 'Salvando...' : 'Salvar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ColaboradorDialog;
