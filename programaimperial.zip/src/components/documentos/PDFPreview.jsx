
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

const PDFPreview = ({ isOpen, onClose, fileUrl }) => {
    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-4xl h-[90vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle>Visualizar Documento</DialogTitle>
                </DialogHeader>
                <div className="flex-grow border rounded-md overflow-hidden">
                    <iframe
                        src={fileUrl}
                        title="PDF Preview"
                        className="w-full h-full"
                        frameBorder="0"
                    />
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Fechar</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default PDFPreview;
