
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import {
  LayoutDashboard, Users, Car, FileText, Wrench, Package, UserCog, Banknote, Percent, BarChart3, Settings, LogOut
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

const navLinks = [
  { to: '/', icon: LayoutDashboard, text: 'Dashboard' },
  { to: '/clientes', icon: Users, text: 'Clientes' },
  { to: '/veiculos', icon: Car, text: 'Veículos' },
  { to: '/orcamentos', icon: FileText, text: 'Orçamentos' },
  { to: '/os', icon: Wrench, text: 'Ordens de Serviço' },
  { to: '/produtos', icon: Package, text: 'Produtos/Estoque' },
  { to: '/colaboradores', icon: UserCog, text: 'Colaboradores' },
  { to: '/financeiro', icon: Banknote, text: 'Financeiro' },
  { to: '/comissoes', icon: Percent, text: 'Comissões' },
  { to: '/relatorios', icon: BarChart3, text: 'Relatórios' },
];

const Sidebar = ({ isCollapsed }) => {
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };
  
  const NavItem = ({ link }) => (
    <NavLink
      to={link.to}
      end={link.to === '/'}
      className={({ isActive }) =>
        `flex items-center p-3 my-1 rounded-lg transition-colors ${ isCollapsed ? 'justify-center' : '' } ${
          isActive
            ? 'bg-blue-700 text-white'
            : 'text-blue-100 hover:bg-blue-500 hover:text-white'
        }`
      }
    >
      <link.icon className={`h-5 w-5 ${!isCollapsed ? 'mr-4' : ''}`} />
      {!isCollapsed && <span>{link.text}</span>}
    </NavLink>
  );

  return (
    <TooltipProvider>
      <aside className={`relative bg-blue-600 text-white flex flex-col transition-all duration-300 ease-in-out ${ isCollapsed ? 'w-20' : 'w-64' }`}>
        <div className={`flex items-center border-b border-blue-700 transition-all ${ isCollapsed ? 'h-16 justify-center' : 'h-16 px-6' }`}>
            <Car className={`h-8 w-8 text-white transition-transform duration-300 ${!isCollapsed ? 'mr-2' : ''}`} />
            {!isCollapsed && <h1 className="text-xl font-bold text-white">Imperial</h1>}
        </div>
        
        <nav className="flex-1 px-2 py-4 space-y-1">
          {navLinks.map((link) => 
            isCollapsed ? (
                <Tooltip key={link.to} delayDuration={0}>
                    <TooltipTrigger asChild>
                        <div className='w-full'><NavItem link={link} /></div>
                    </TooltipTrigger>
                    <TooltipContent side="right">
                        <p>{link.text}</p>
                    </TooltipContent>
                </Tooltip>
            ) : (
                <NavItem key={link.to} link={link} />
            )
          )}
        </nav>

        <div className={`px-2 py-4 border-t border-blue-700`}>
             <Tooltip delayDuration={0}>
                <TooltipTrigger asChild>
                    <div className='w-full'>
                        <NavLink
                            to="/configuracoes"
                            className={({ isActive }) => `flex items-center p-3 my-1 rounded-lg transition-colors ${ isCollapsed ? 'justify-center' : '' } ${ isActive ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-500 hover:text-white' }`}
                        >
                            <Settings className={`h-5 w-5 ${!isCollapsed ? 'mr-4' : ''}`} />
                            {!isCollapsed && <span>Configurações</span>}
                        </NavLink>
                    </div>
                </TooltipTrigger>
                {isCollapsed && <TooltipContent side="right"><p>Configurações</p></TooltipContent>}
            </Tooltip>
            
            <Tooltip delayDuration={0}>
                <TooltipTrigger asChild>
                    <div className='w-full'>
                        <Button
                            variant="ghost"
                            className={`w-full p-3 h-auto justify-start text-blue-100 hover:bg-blue-700 hover:text-white ${isCollapsed ? 'justify-center' : ''}`}
                            onClick={handleLogout}
                        >
                            <LogOut className={`h-5 w-5 ${!isCollapsed ? 'mr-4' : ''}`} />
                            {!isCollapsed && <span>Sair</span>}
                        </Button>
                    </div>
                </TooltipTrigger>
                 {isCollapsed && <TooltipContent side="right"><p>Sair</p></TooltipContent>}
            </Tooltip>
        </div>
      </aside>
    </TooltipProvider>
  );
};

export default Sidebar;
