
import React, { useState, useEffect, useCallback } from 'react';
import { useDebounce } from '@/hooks/useDebounce';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Edit, Trash2, History, PlusCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import VeiculoDialog from '@/components/veiculos/VeiculoDialog';
import VehicleHistoryDialog from '@/components/dialogs/VehicleHistoryDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { v4 as uuidv4 } from 'uuid';

const sampleVehicles = [
  { id: 'v1', plate: 'BRA2E19', brand: 'Toyota', model: 'Corolla', year: '2022', color: 'Prata', customer_name: 'João Silva', has_pending_os: true },
  { id: 'v2', plate: 'ABC1D23', brand: 'Honda', model: 'Civic', year: '2021', color: 'Preto', customer_name: 'Maria Oliveira', has_pending_os: false },
  { id: 'v3', plate: 'DEF4E56', brand: 'Ford', model: 'Mustang', year: '2020', color: 'Vermelho', customer_name: 'Ana Costa', has_pending_os: false },
  { id: 'v4', plate: 'GHI7J89', brand: 'Volkswagen', model: 'Golf', year: '2023', color: 'Azul', customer_name: 'Rafael Souza', has_pending_os: true },
  { id: 'v5', plate: 'KLM0N12', brand: 'Chevrolet', model: 'Onix', year: '2022', color: 'Branco', customer_name: 'João Silva', has_pending_os: false },
];

const VeiculosList = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [allVehicles, setAllVehicles] = useState(sampleVehicles);
  const [filteredVehicles, setFilteredVehicles] = useState(sampleVehicles);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({ page: 0, pageSize: 10 });
  
  const [isVehicleDialogOpen, setIsVehicleDialogOpen] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  const [selectedVehicle, setSelectedVehicle] = useState(null);

  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const filterAndPaginateVehicles = useCallback(() => {
    setLoading(true);
    let filtered = allVehicles;
    if (debouncedSearchTerm) {
      filtered = allVehicles.filter(v =>
        v.plate.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
        v.brand.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
        v.model.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
        v.customer_name.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
      );
    }
    
    const { page, pageSize } = pagination;
    const start = page * pageSize;
    const end = start + pageSize;
    
    setFilteredVehicles(filtered.slice(start, end));
    setLoading(false);
  }, [allVehicles, debouncedSearchTerm, pagination]);

  useEffect(() => {
    filterAndPaginateVehicles();
  }, [filterAndPaginateVehicles]);

  const openVehicleDialog = (vehicle = null) => {
    setSelectedVehicle(vehicle);
    setIsVehicleDialogOpen(true);
  };
  
  const openHistoryDialog = (vehicle) => {
    setSelectedVehicle(vehicle);
    setIsHistoryDialogOpen(true);
  };

  const openDeleteDialog = (vehicle) => {
    setSelectedVehicle(vehicle);
    setIsDeleteDialogOpen(true);
  };

  const handleSaveVehicle = (vehicleData) => {
    if (vehicleData.id) { // Edit
      setAllVehicles(prev => prev.map(v => v.id === vehicleData.id ? { ...v, ...vehicleData } : v));
      toast({ title: 'Veículo atualizado com sucesso!' });
    } else { // Create
      const newVehicle = { ...vehicleData, id: uuidv4(), has_pending_os: false, customer_name: 'Novo Cliente' };
      setAllVehicles(prev => [newVehicle, ...prev]);
      toast({ title: 'Veículo criado com sucesso!' });
    }
    setIsVehicleDialogOpen(false);
    setSelectedVehicle(null);
  };

  const handleDeleteVehicle = async () => {
    if (!selectedVehicle) return;
    
    setAllVehicles(prev => prev.filter(v => v.id !== selectedVehicle.id));
    toast({ title: 'Veículo deletado com sucesso!' });
    
    setIsDeleteDialogOpen(false);
    setSelectedVehicle(null);
  };

  const totalPages = Math.ceil(allVehicles.filter(v => debouncedSearchTerm ? (v.plate.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) || v.brand.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) || v.model.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) || v.customer_name.toLowerCase().includes(debouncedSearchTerm.toLowerCase())) : true).length / pagination.pageSize);

  const handleDialogClose = () => {
    setIsVehicleDialogOpen(false);
    setSelectedVehicle(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Veículos</h1>
        <Button onClick={() => openVehicleDialog()}>
          <PlusCircle className="w-4 h-4 mr-2" /> Novo Veículo
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow p-4">
        <div className="mb-4">
          <Input placeholder="Buscar por placa, modelo ou cliente..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Placa</TableHead>
              <TableHead>Veículo</TableHead>
              <TableHead className="hidden md:table-cell">Cliente</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan="5" className="text-center">Carregando...</TableCell></TableRow>
            ) : filteredVehicles.length > 0 ? (
              filteredVehicles.map(vehicle => (
                <TableRow key={vehicle.id}>
                  <TableCell>{vehicle.plate}</TableCell>
                  <TableCell>{vehicle.brand} {vehicle.model} ({vehicle.year})</TableCell>
                  <TableCell className="hidden md:table-cell">{vehicle.customer_name}</TableCell>
                  <TableCell>
                    {vehicle.has_pending_os ? (
                      <Badge variant="warning">OS Pendente</Badge>
                    ) : (
                      <Badge variant="success">Ativo</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="w-4 h-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openVehicleDialog(vehicle)}><Edit className="w-4 h-4 mr-2" /> Editar</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => openHistoryDialog(vehicle)}><History className="w-4 h-4 mr-2" /> Histórico</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600" onClick={() => openDeleteDialog(vehicle)}><Trash2 className="w-4 h-4 mr-2" /> Excluir</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow><TableCell colSpan="5" className="text-center">Nenhum veículo encontrado.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
        
        <div className="flex items-center justify-between pt-4">
          <span className="text-sm text-muted-foreground">Página {pagination.page + 1} de {totalPages || 1}</span>
          <div className="flex gap-2">
            <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))} disabled={pagination.page === 0}>Anterior</Button>
            <Button size="sm" onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))} disabled={pagination.page >= totalPages - 1}>Próximo</Button>
          </div>
        </div>
      </div>

      {isVehicleDialogOpen && <VeiculoDialog isOpen={isVehicleDialogOpen} onClose={handleDialogClose} onSaveSuccess={handleSaveVehicle} vehicle={selectedVehicle} user={user} />}
      {isHistoryDialogOpen && <VehicleHistoryDialog isOpen={isHistoryDialogOpen} onClose={() => setIsHistoryDialogOpen(false)} vehicleId={selectedVehicle?.id} />}
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita. Isso excluirá permanentemente o veículo.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteVehicle}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default VeiculosList;
