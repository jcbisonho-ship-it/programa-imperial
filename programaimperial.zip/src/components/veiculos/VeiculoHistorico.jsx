
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { Car, User, Wrench, FileText, Camera, DollarSign, Gauge } from 'lucide-react';
import { format } from 'date-fns';

const VeiculoHistorico = ({ isOpen, onClose, vehicleId }) => {
  const [history, setHistory] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchHistory = useCallback(async () => {
    if (!vehicleId) return;
    setLoading(true);
    try {
      const { data: vehicleData, error: vehicleError } = await supabase
        .from('vehicles')
        .select(`
          *,
          customer:customers(*)
        `)
        .eq('id', vehicleId)
        .single();
      if (vehicleError) throw vehicleError;

      const { data: osData, error: osError } = await supabase
        .from('work_orders')
        .select(`*, technician:collaborators(name)`)
        .eq('vehicle_id', vehicleId)
        .order('order_date', { ascending: false });
      if (osError) throw osError;
      
      const workOrderIds = osData.map(os => os.id);
      let osItems = [];
      if (workOrderIds.length > 0) {
          const { data: itemsData, error: itemsError } = await supabase
            .from('work_order_items')
            .select('work_order_id, total_price')
            .in('work_order_id', workOrderIds);
          if (itemsError) throw itemsError;
          osItems = itemsData;
      }
      
      const osWithTotals = osData.map(os => {
          const total = osItems
            .filter(item => item.work_order_id === os.id)
            .reduce((sum, item) => sum + (item.total_price || 0), 0);
          return {...os, total};
      });

      const { data: budgetData, error: budgetError } = await supabase
        .from('budgets')
        .select('*')
        .eq('vehicle_id', vehicleId)
        .order('created_at', { ascending: false });
      if (budgetError) throw budgetError;
      
      const { data: photos, error: photosError } = await supabase
        .storage
        .from('vehicles')
        .list('vehicle-photos', {
            search: vehicleData.plate.replace(/[^a-zA-Z0-9]/g, '')
        });
      if (photosError) throw photosError;

      const photoUrls = photos.map(file => {
          return supabase.storage.from('vehicles').getPublicUrl(`vehicle-photos/${file.name}`).data.publicUrl;
      });

      setHistory({
        vehicle: vehicleData,
        work_orders: osWithTotals,
        budgets: budgetData,
        photos: photoUrls,
      });

    } catch (error) {
      toast({ title: 'Erro ao carregar histórico', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [vehicleId, toast]);

  useEffect(() => {
    if (isOpen) {
      fetchHistory();
    }
  }, [isOpen, fetchHistory]);

  const InfoCard = ({ icon: Icon, title, children }) => (
    <div className="bg-gray-50 p-4 rounded-lg">
      <h3 className="text-md font-semibold text-gray-700 flex items-center mb-2"><Icon className="w-5 h-5 mr-2 text-blue-600" />{title}</h3>
      <div className="text-sm text-gray-600 space-y-1">{children}</div>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Histórico do Veículo</DialogTitle>
          {history?.vehicle && <DialogDescription>{history.vehicle.brand} {history.vehicle.model} - {history.vehicle.plate}</DialogDescription>}
        </DialogHeader>
        <div className="py-4 space-y-6">
          {loading ? (
             <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-600"></div>
             </div>
          ) : history ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <InfoCard icon={Car} title="Detalhes do Veículo">
                      <p><strong>Placa:</strong> {history.vehicle.plate}</p>
                      <p><strong>Modelo:</strong> {history.vehicle.brand} {history.vehicle.model}</p>
                      <p><strong>Ano/Cor:</strong> {history.vehicle.year} / {history.vehicle.color}</p>
                      {history.vehicle.observations && <p><strong>Obs:</strong> {history.vehicle.observations}</p>}
                  </InfoCard>
                   <InfoCard icon={User} title="Proprietário">
                      <p><strong>Nome:</strong> {history.vehicle.customer.name}</p>
                      <p><strong>Telefone:</strong> {history.vehicle.customer.phone}</p>
                      <p><strong>Email:</strong> {history.vehicle.customer.email || 'N/A'}</p>
                  </InfoCard>
              </div>

               <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center"><Wrench className="w-5 h-5 mr-2 text-blue-600" /> Ordens de Serviço</h3>
                <div className="border rounded-lg max-h-60 overflow-y-auto">
                    {history.work_orders.length > 0 ? history.work_orders.map(os => (
                        <div key={os.id} className="p-3 border-b last:border-b-0 flex justify-between items-center">
                            <div>
                               <p className="font-medium">{os.title || 'Serviço sem título'}</p>
                               <p className="text-xs text-gray-500">
                                   {format(new Date(os.order_date), 'dd/MM/yyyy')} | Técnico: {os.technician?.name || 'N/A'}
                               </p>
                               {os.km && <p className="text-xs text-blue-600 flex items-center gap-1 mt-1"><Gauge className="w-3 h-3" /> {os.km.toLocaleString('pt-BR')} km</p>}
                            </div>
                            <div className="text-right">
                                <Badge variant={os.status === 'completed' ? 'default' : 'secondary'}>{os.status}</Badge>
                                <p className="font-bold text-gray-700">R$ {os.total.toFixed(2)}</p>
                            </div>
                        </div>
                    )) : <p className="p-4 text-center text-gray-500">Nenhuma ordem de serviço encontrada.</p>}
                </div>
              </div>

               <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center"><FileText className="w-5 h-5 mr-2 text-blue-600" /> Orçamentos</h3>
                 <div className="border rounded-lg max-h-60 overflow-y-auto">
                    {history.budgets.length > 0 ? history.budgets.map(b => (
                        <div key={b.id} className="p-3 border-b last:border-b-0 flex justify-between items-center">
                            <div>
                               <p className="font-medium">Orçamento de {format(new Date(b.created_at), 'dd/MM/yyyy')}</p>
                               {b.km && <p className="text-xs text-blue-600 flex items-center gap-1 mt-1"><Gauge className="w-3 h-3" /> {b.km.toLocaleString('pt-BR')} km</p>}
                            </div>
                             <div className="text-right">
                               <Badge variant={b.status === 'approved' ? 'default' : 'secondary'}>{b.status}</Badge>
                               <p className="font-bold text-gray-700">R$ {Number(b.total_cost).toFixed(2)}</p>
                            </div>
                        </div>
                    )) : <p className="p-4 text-center text-gray-500">Nenhum orçamento encontrado.</p>}
                </div>
              </div>
              
              <div>
                 <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center"><Camera className="w-5 h-5 mr-2 text-blue-600" /> Fotos</h3>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                     {history.photos.length > 0 ? history.photos.map((url, i) => (
                         <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                            <img src={url} alt={`Foto do veículo ${i + 1}`} className="rounded-lg object-cover aspect-square hover:opacity-80 transition-opacity" />
                         </a>
                     )) : <p className="p-4 text-center text-gray-500 col-span-full">Nenhuma foto encontrada.</p>}
                 </div>
              </div>
            </>
          ) : (
            <p className="text-center text-gray-500">Não foi possível carregar o histórico.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VeiculoHistorico;
