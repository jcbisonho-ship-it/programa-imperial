
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { PlusCircle, Trash2 } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

const OrcamentoDialog = ({ isOpen, onClose, onSaveSuccess, budget, mode, user }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [customers, setCustomers] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [collaborators, setCollaborators] = useState([]);
  
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [filteredVehicles, setFilteredVehicles] = useState([]);
  
  const [formData, setFormData] = useState({ customer_id: '', vehicle_id: '', status: 'draft', total_cost: 0 });
  const [items, setItems] = useState([]);
  const [comment, setComment] = useState('');

  const fetchInitialData = useCallback(async () => {
    try {
      const [customersRes, vehiclesRes, collaboratorsRes] = await Promise.all([
        supabase.from('customers').select('id, name').order('name'),
        supabase.from('vehicles').select('id, plate, model, customer_id'),
        supabase.from('collaborators').select('id, name').order('name'),
      ]);
      if (customersRes.error) throw customersRes.error;
      if (vehiclesRes.error) throw vehiclesRes.error;
      if (collaboratorsRes.error) throw collaboratorsRes.error;
      setCustomers(customersRes.data);
      setVehicles(vehiclesRes.data);
      setCollaborators(collaboratorsRes.data);
    } catch (error) {
      toast({ title: "Erro ao carregar dados", description: error.message, variant: "destructive" });
    }
  }, [toast]);

  useEffect(() => {
    fetchInitialData();
  }, [fetchInitialData]);

  useEffect(() => {
    const setup = async () => {
      if (budget && (mode === 'edit' || mode === 'duplicate')) {
        const { data: budgetItems, error } = await supabase.from('budget_items').select('*').eq('budget_id', budget.id);
        if (error) {
          toast({ title: 'Erro ao carregar itens do orçamento', description: error.message, variant: 'destructive' });
          return;
        }
        setFormData({ customer_id: budget.customer_id, vehicle_id: budget.vehicle_id, status: mode === 'duplicate' ? 'draft' : budget.status, total_cost: budget.total_cost });
        setItems(budgetItems.map(item => ({ ...item, client_id: uuidv4() })));
        setSelectedCustomerId(budget.customer_id);
      } else {
        setFormData({ customer_id: '', vehicle_id: '', status: 'draft', total_cost: 0 });
        setItems([]);
        setSelectedCustomerId('');
      }
    };
    if (isOpen) setup();
  }, [budget, mode, isOpen, toast]);

  useEffect(() => {
    if (selectedCustomerId) {
      setFilteredVehicles(vehicles.filter(v => v.customer_id === selectedCustomerId));
    } else {
      setFilteredVehicles([]);
    }
    if (mode === 'create') {
        setFormData(f => ({ ...f, vehicle_id: '' }));
    }
  }, [selectedCustomerId, vehicles, mode]);

  useEffect(() => {
    const total = items.reduce((acc, item) => acc + (item.quantity * item.unit_price), 0);
    setFormData(f => ({ ...f, total_cost: total }));
  }, [items]);

  const handleItemChange = (id, field, value) => {
    setItems(items.map(item => item.client_id === id ? { ...item, [field]: value } : item));
  };

  const addItem = () => {
    setItems([...items, { client_id: uuidv4(), description: '', quantity: 1, unit_price: 0, cost_price: 0, collaborator_id: null }]);
  };

  const removeItem = (id) => {
    setItems(items.filter(item => item.client_id !== id));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let budgetId;
      const isEditing = mode === 'edit' && budget?.id;

      // 1. Upsert Budget
      const budgetPayload = { ...formData };
      if (isEditing) {
        const { data, error } = await supabase.from('budgets').update(budgetPayload).eq('id', budget.id).select().single();
        if (error) throw error;
        budgetId = data.id;
      } else {
        const { data, error } = await supabase.from('budgets').insert(budgetPayload).select().single();
        if (error) throw error;
        budgetId = data.id;
      }

      // 2. Handle Items
      const itemsToUpsert = items.map(({ client_id, ...dbItem }) => ({ ...dbItem, budget_id: budgetId }));
      if (isEditing) {
        // Simple approach: delete old items and insert new ones
        await supabase.from('budget_items').delete().eq('budget_id', budgetId);
      }
      const { error: itemsError } = await supabase.from('budget_items').insert(itemsToUpsert);
      if (itemsError) throw itemsError;

      // 3. Log History
      if (comment || (isEditing && budget.status !== formData.status)) {
        await supabase.from('budget_history').insert({
          budget_id: budgetId,
          user_id: user.id,
          status_from: isEditing ? budget.status : null,
          status_to: formData.status,
          comment: comment || `Status alterado para ${formData.status}`,
        });
      }

      toast({ title: `Orçamento ${isEditing ? 'atualizado' : 'criado'} com sucesso!` });
      onSaveSuccess();
      onClose();
    } catch (error) {
      toast({ title: 'Erro ao salvar orçamento', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{mode === 'edit' ? 'Editar' : mode === 'duplicate' ? 'Duplicar' : 'Novo'} Orçamento</DialogTitle>
          <DialogDescription>Preencha os detalhes do orçamento.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto space-y-4 pr-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Cliente</Label>
              <Select value={selectedCustomerId} onValueChange={v => { setSelectedCustomerId(v); setFormData({ ...formData, customer_id: v }); }}>
                <SelectTrigger><SelectValue placeholder="Selecione um cliente" /></SelectTrigger>
                <SelectContent>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Veículo</Label>
              <Select value={formData.vehicle_id} onValueChange={v => setFormData({ ...formData, vehicle_id: v })} disabled={!selectedCustomerId}>
                <SelectTrigger><SelectValue placeholder="Selecione um veículo" /></SelectTrigger>
                <SelectContent>{filteredVehicles.map(v => <SelectItem key={v.id} value={v.id}>{v.model} ({v.plate})</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Itens / Serviços</Label>
            {items.map((item, index) => (
              <div key={item.client_id} className="grid grid-cols-12 gap-2 items-center p-2 border rounded-md">
                <Input className="col-span-12 md:col-span-4" placeholder="Descrição" value={item.description} onChange={e => handleItemChange(item.client_id, 'description', e.target.value)} />
                <Input className="col-span-3 md:col-span-1" type="number" placeholder="Qtd" value={item.quantity} onChange={e => handleItemChange(item.client_id, 'quantity', parseFloat(e.target.value) || 0)} />
                <Input className="col-span-4 md:col-span-2" type="number" placeholder="Preço Unit." value={item.unit_price} onChange={e => handleItemChange(item.client_id, 'unit_price', parseFloat(e.target.value) || 0)} />
                <div className="col-span-5 md:col-span-2 font-medium text-sm text-right pr-2">{formatCurrency(item.quantity * item.unit_price)}</div>
                <div className="col-span-10 md:col-span-2">
                    <Select value={item.collaborator_id || ''} onValueChange={v => handleItemChange(item.client_id, 'collaborator_id', v)}>
                        <SelectTrigger><SelectValue placeholder="Mecânico" /></SelectTrigger>
                        <SelectContent>{collaborators.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
                <Button variant="ghost" size="icon" className="col-span-2 md:col-span-1 text-red-500" onClick={() => removeItem(item.client_id)}><Trash2 className="w-4 h-4" /></Button>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={addItem}><PlusCircle className="w-4 h-4 mr-2" /> Adicionar Item</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Rascunho</SelectItem>
                  <SelectItem value="pending_approval">Pendente Aprovação</SelectItem>
                  <SelectItem value="approved">Aprovado</SelectItem>
                  <SelectItem value="rejected">Rejeitado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="text-right">
              <Label>Total do Orçamento</Label>
              <p className="text-2xl font-bold">{formatCurrency(formData.total_cost)}</p>
            </div>
          </div>
          
          <div>
            <Label>Adicionar Comentário (Opcional)</Label>
            <Textarea placeholder="Deixe um comentário sobre a alteração de status ou outra observação..." value={comment} onChange={e => setComment(e.target.value)} />
          </div>
        </form>
        <DialogFooter className="pt-4">
          <Button type="button" variant="outline" onClick={onClose} disabled={loading}>Cancelar</Button>
          <Button type="submit" onClick={handleSubmit} disabled={loading}>{loading ? 'Salvando...' : 'Salvar Orçamento'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default OrcamentoDialog;
