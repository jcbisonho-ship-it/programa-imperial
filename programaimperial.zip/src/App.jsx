
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import { Toaster } from '@/components/ui/toaster';

import DashboardLayout from '@/components/layout/DashboardLayout';
import PrivateRoute from '@/components/auth/PrivateRoute';

import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import Clientes from '@/pages/Clientes';
import Veiculos from '@/pages/Veiculos';
import Produtos from '@/pages/Produtos';
import Orcamentos from '@/pages/Orcamentos';
import OS from '@/pages/OS';
import Colaboradores from '@/pages/Colaboradores';
import Financeiro from '@/pages/Financeiro';
import Comissoes from '@/pages/Comissoes';
import Relatorios from '@/pages/Relatorios';
import Configuracoes from '@/pages/Configuracoes';
import Documentos from '@/pages/Documentos';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route 
            path="/" 
            element={
              <PrivateRoute>
                <DashboardLayout />
              </PrivateRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="clientes" element={<Clientes />} />
            <Route path="veiculos" element={<Veiculos />} />
            <Route path="produtos" element={<Produtos />} />
            <Route path="orcamentos" element={<Orcamentos />} />
            <Route path="os" element={<OS />} />
            <Route path="colaboradores" element={<Colaboradores />} />
            <Route path="financeiro" element={<Financeiro />} />
            <Route path="comissoes" element={<Comissoes />} />
            <Route path="relatorios" element={<Relatorios />} />
            <Route path="documentos" element={<Documentos />} />
            <Route path="configuracoes" element={<Configuracoes />} />
          </Route>
        </Routes>
      </BrowserRouter>
      <Toaster />
    </AuthProvider>
  );
}

export default App;
