
import { supabase } from '@/lib/customSupabaseClient';

export const sendEmailWithAttachment = async ({ to, subject, html, attachmentUrl }) => {
    const { data, error } = await supabase.functions.invoke('send-email-with-attachment', {
        body: { to, subject, html, attachmentUrl },
    });

    if (error) {
        throw new Error(`Email sending failed: ${error.message}`);
    }
    
    if (data.error) {
        throw new Error(`Email sending failed: ${data.error.message || JSON.stringify(data.error)}`);
    }

    return data;
};

export const resendEmail = async (document) => {
    const subject = `Reenvio: ${document.document_type.replace('_', ' ')} #${document.related_id.substring(0, 8)}`;
    const html = `
        <h1>Documento Reenviado</h1>
        <p>Olá, ${document.customer?.name || 'Cliente'},</p>
        <p>Segue em anexo o documento solicitado: ${document.document_type.replace('_', ' ')}.</p>
        <p>Atenciosamente,<br>Equipe Imperial Serviços Automotivos</p>
    `;

    const { error: emailError } = await sendEmailWithAttachment({
        to: document.recipient_email,
        subject,
        html,
        attachmentUrl: document.file_url,
    });

    if (emailError) {
        return { error: emailError };
    }

    // Update sent_at timestamp
    const { error: dbError } = await supabase
        .from('documents')
        .update({ sent_at: new Date().toISOString() })
        .eq('id', document.id);
    
    return { error: dbError };
};
