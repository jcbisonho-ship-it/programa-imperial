
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { supabase } from '@/lib/customSupabaseClient';
import { format } from 'date-fns';

const formatCurrency = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);

async function getTemplate() {
    const { data, error } = await supabase.from('document_templates').select('*').eq('id', 1).single();
    if (error) {
        console.error("Error fetching template:", error);
        // Return a default template on error
        return {
            primary_color: '#3b82f6',
            company_info: { name: 'Sua Empresa', address: 'Seu Endereço', phone: 'Seu Telefone', email: 'seu@email.com' },
            footer_text: 'Obrigado!',
            terms_and_conditions: 'Termos padrão.'
        };
    }
    return data;
}

function addHeader(doc, template) {
    if (template.company_logo_url) {
        try {
            // Note: jsPDF has CORS issues with images. This might require proxying or ensuring public access.
            // For this implementation, we assume the URL is publicly accessible.
            // doc.addImage(template.company_logo_url, 'PNG', 14, 10, 30, 30);
        } catch (e) {
            console.error("Could not add logo to PDF:", e);
        }
    }
    doc.setFontSize(20);
    doc.setTextColor(template.primary_color);
    doc.text(template.company_info.name, 105, 20, { align: 'center' });
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`${template.company_info.address} | ${template.company_info.phone} | ${template.company_info.email}`, 105, 28, { align: 'center' });
    doc.setLineWidth(0.5);
    doc.setDrawColor(template.primary_color);
    doc.line(14, 35, 196, 35);
}

function addFooter(doc, template) {
    const pageCount = doc.internal.getNumberOfPages();
    doc.setFontSize(8);
    doc.setTextColor(100);
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.text(template.footer_text, 105, 285, { align: 'center' });
        doc.text(`Página ${i} de ${pageCount}`, 196, 290, { align: 'right' });
    }
}

export const generateBudgetPDF = async (budgetData) => {
    const template = await getTemplate();
    const doc = new jsPDF();

    addHeader(doc, template);

    // Document Title
    doc.setFontSize(16);
    doc.setTextColor(40);
    doc.text(`Orçamento #${budgetData.id.substring(0, 8)}`, 14, 45);
    doc.setFontSize(10);
    doc.text(`Data: ${format(new Date(budgetData.created_at), 'dd/MM/yyyy')}`, 196, 45, { align: 'right' });
    doc.text(`Validade: 15 dias`, 196, 50, { align: 'right' });

    // Client and Vehicle Info
    doc.setFontSize(12);
    doc.setTextColor(template.primary_color);
    doc.text('Informações do Cliente e Veículo', 14, 60);
    doc.setFontSize(10);
    doc.setTextColor(80);
    doc.text(`Cliente: ${budgetData.customer_name}`, 14, 68);
    doc.text(`Veículo: ${budgetData.vehicle_description}`, 14, 74);

    // Items Table
    const head = [['Item', 'Qtd.', 'Preço Unit.', 'Total']];
    const body = budgetData.items.map(item => [
        item.description,
        item.quantity,
        formatCurrency(item.unit_price),
        formatCurrency((item.quantity || 0) * (item.unit_price || 0))
    ]);

    doc.autoTable({
        startY: 80,
        head: head,
        body: body,
        theme: 'striped',
        headStyles: { fillColor: template.primary_color },
    });

    // Total
    const finalY = doc.lastAutoTable.finalY;
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Total Geral:', 140, finalY + 10, { align: 'right' });
    doc.text(formatCurrency(budgetData.total_cost), 196, finalY + 10, { align: 'right' });

    // Terms and Signature
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text('Termos e Condições:', 14, finalY + 25);
    doc.setFont('helvetica', 'normal');
    const splitTerms = doc.splitTextToSize(template.terms_and_conditions, 182);
    doc.text(splitTerms, 14, finalY + 30);

    doc.line(40, 250, 170, 250);
    doc.text('Assinatura do Cliente', 105, 255, { align: 'center' });

    addFooter(doc, template);
    return doc;
};

export const generateWorkOrderPDF = async (workOrderData) => {
    // This is a placeholder. In a real scenario, you'd fetch full work order data.
    const template = await getTemplate();
    const doc = new jsPDF();
    addHeader(doc, template);
    doc.text(`Ordem de Serviço (Em desenvolvimento)`, 14, 45);
    addFooter(doc, template);
    return doc;
};

export const generateReceiptPDF = async (receiptData) => {
    // This is a placeholder.
    const template = await getTemplate();
    const doc = new jsPDF();
    addHeader(doc, template);
    doc.text(`Recibo (Em desenvolvimento)`, 14, 45);
    doc.text(`Valor: ${formatCurrency(receiptData.amount)}`, 14, 55);
    addFooter(doc, template);
    return doc;
};

export const uploadPDF = async (pdf, fileName) => {
    const pdfBlob = pdf.output('blob');
    const filePath = `generated/${fileName}`;
    const { error } = await supabase.storage.from('documents').upload(filePath, pdfBlob, {
        cacheControl: '3600',
        upsert: true,
    });

    if (error) {
        throw new Error(`PDF Upload Error: ${error.message}`);
    }

    const { data: urlData } = supabase.storage.from('documents').getPublicUrl(filePath);
    return urlData.publicUrl;
};

export const logDocument = async (documentInfo) => {
    const { error } = await supabase.from('documents').insert(documentInfo);
    if (error) {
        throw new Error(`Document Logging Error: ${error.message}`);
    }
};
