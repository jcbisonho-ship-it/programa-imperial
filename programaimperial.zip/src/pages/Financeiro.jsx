
import React from 'react';
import FinancialManagement from '@/components/dashboard/FinancialManagement';

const Financeiro = () => {
  return (
    <FinancialManagement />
  );
};

export default Financeiro;
