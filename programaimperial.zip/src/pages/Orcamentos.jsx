
import React from 'react';
import Budgets from '@/components/dashboard/Budgets';

const Orcamentos = () => {
  return (
    <div className="p-4 sm:p-6 lg:p-8 h-full">
      <Budgets />
    </div>
  );
};

export default Orcamentos;
