
import React from 'react';
import CollaboratorManagement from '@/components/dashboard/CollaboratorManagement';

const Colaboradores = () => {
    return (
        <CollaboratorManagement />
    );
};

export default Colaboradores;
