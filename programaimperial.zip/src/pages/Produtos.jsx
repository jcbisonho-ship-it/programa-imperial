
import React from 'react';
import ProdutosList from '@/components/produtos/ProdutosList';

const Produtos = () => {
    return (
        <div className="p-4 sm:p-6 lg:p-8">
            <ProdutosList />
        </div>
    );
};

export default Produtos;
