
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ConfigGeral from '@/components/configuracoes/ConfigGeral';
import ConfigEmpresa from '@/components/configuracoes/ConfigEmpresa';
import ConfigBackup from '@/components/configuracoes/ConfigBackup';
import ConfigTemas from '@/components/configuracoes/ConfigTemas';
import ConfigPermissoes from '@/components/configuracoes/ConfigPermissoes';
import ConfigIntegracoes from '@/components/configuracoes/ConfigIntegracoes';
import LogsAtividades from '@/components/configuracoes/LogsAtividades';

const Configuracoes = () => {
    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-bold text-gray-800">Configurações</h2>
                <p className="text-gray-600">Gerencie as configurações gerais da aplicação.</p>
            </div>
            <Tabs defaultValue="geral" className="w-full" orientation="vertical">
                <TabsList className="w-full md:w-48">
                    <TabsTrigger value="geral">Geral</TabsTrigger>
                    <TabsTrigger value="empresa">Empresa</TabsTrigger>
                    <TabsTrigger value="temas">Temas</TabsTrigger>
                    <TabsTrigger value="permissoes">Permissões</TabsTrigger>
                    <TabsTrigger value="integracoes">Integrações</TabsTrigger>
                    <TabsTrigger value="backup">Backup</TabsTrigger>
                    <TabsTrigger value="logs">Logs de Atividades</TabsTrigger>
                </TabsList>
                <div className="flex-1 pl-6">
                    <TabsContent value="geral"><ConfigGeral /></TabsContent>
                    <TabsContent value="empresa"><ConfigEmpresa /></TabsContent>
                    <TabsContent value="temas"><ConfigTemas /></TabsContent>
                    <TabsContent value="permissoes"><ConfigPermissoes /></TabsContent>
                    <TabsContent value="integracoes"><ConfigIntegracoes /></TabsContent>
                    <TabsContent value="backup"><ConfigBackup /></TabsContent>
                    <TabsContent value="logs"><LogsAtividades /></TabsContent>
                </div>
            </Tabs>
        </div>
    );
};

export default Configuracoes;
