
import React from 'react';
import ServiceOrders from '@/components/os/ServiceOrders';

const OS = () => {
  return (
    <ServiceOrders />
  );
};

export default OS;
